# 图定向单边翻转重配置研究记录
## 项目总档案｜2026-10-02 全面增补版（保留 2026-10-01 及更早历史层）

> 本版在 `graph_orientation_reconfiguration_progress_2026-10-01.md` **之前新增一层完整 current-status 前页**，旧正文原则上不删除，只降格为历史层。
>
> **冲突规则：**若本页与后附 2026-10-01 / 2026-09-30 / 2026-09-28 历史内容冲突，以本页为准；后附旧结论仍保留用于追踪路线、反例、证明失败史和计算 provenance。
>
> **状态标签：**
> - **LOCKED**：当前协调层允许后续模型直接使用；
> - **DEAD / FALSE**：已有严格反例或严格不可能性证明，不得复活；
> - **TERMINAL-REALIZABLE**：在 true-critical terminal residual system 中可实现，但不等于 component-separating；
> - **CONNECTED CONTROL**：局部/terminal obstruction 存在，但 full legal fiber 已 exact 验证连通；
> - **OPEN**：当前真正 frontier。
>
> 本轮大方向更新：**static two-extra obstruction 已全部关闭；three-extra 只剩一个 pure directed 3-cycle primitive；动态一侧 generic starvation 可以存在，但目前最小历史化实例仍通过 history rewind / temporal buffer 逃逸。**

---

# Definitions / Scope / Status Audit｜2026-10-02 用户补充

本页补入统一定义、适用范围和状态更正；与下方摘要或历史层冲突时，本页优先。来源为本次用户提供的[审计回复](C:/Users/HUAWEI/.codex-gui-anyrouter/attachments/bd46ec1a-ec7a-4c3c-a036-0adae9cdd2c0/已粘贴的文本.txt)。本次归档采用其中明确给出的定义与状态更正，未重新验证所引用但尚未交付的原模型证明、反例或计算数据。

补充中的 Pasted text 标识、时间戳及截断的 graph_orientation_reconfigurati… 仅是原始材料的检索线索，不表示本档已含原文。以下区分“定义已补齐”“按用户更正的研究状态”“原始证明／数据待归档”“外部定理适用域待审计”。主连通性问题仍 OPEN；缺少原始材料不自动改变相关数学结论的状态。

## DS1. Initial true-critical residual system 与 signed descendant

当前静态分类默认在 **initial true-critical residual system** 中：\(G\) 为有限无自环多重图，\(\lambda(G)\ge2k+1\)，\(\varnothing\ne A\subsetneq V(G)\)，\(|\delta_G(A)|=2k+1\)。固定 \(E(G)\setminus E(G[A])\) 的 outside orientation \(\sigma\)，且 \(\sigma\) 有 global \(k\)-arc-strong extension。记 \(H=G[A]\)，\(D\) 为完整内部定向，\(K_\sigma\) 为去掉 \(H\) 内部边后的固定有向图。

对所有 \(\varnothing\ne Y\subsetneq A\)，使用
\[
q(Y)=\min_{Z\subseteq V-A}d^+_{K_\sigma}(Y\cup Z)
=\min\{R(Y),S(A-Y)\},\qquad p(Y)=k-q(Y),
\]
\[
s_D(Y)=d_D^+(Y)-p(Y)\ge0,\qquad
\mu(Y)=|\delta_H(Y)|-p(Y)-p(A-Y)\ge1.
\]
其中 \(d_D^+\) 只计内部定向 \(D\) 的出割；\(R,S\) 为固定边界的出、入计数，总量为 \((k,k+1)\) 或 \((k+1,k)\)。actual-tight 指同一个完整内部定向中 \(s_D(Y)=0\)。

另行固定有向内部物理边集 \(J\) 时，remaining graph 为 \(K=H-J\)，需求变为
\[
p_J(Y)=p(Y)-d_J^+(Y),\qquad
s_L^J(Y)=s_{J\cup L}(Y),\qquad \mu_J(Y)=\mu(Y).
\]
\(p_J\) 允许负值。不能仅凭 \(\mu_J=\mu\)，把 initial endpoint formula、非负需求的定向定理或其他 initial 论证递归用于任意 signed descendant；需逐项证明继承条件。后续定理必须显式注明 initial residual 或 fixed-\(J\) descendant。

## DS2. Relative source 与 source-free

给定当前 actual-tight row family \(\mathcal P\) 和当前方向的内部 physical edge \(g=u\to v\)，定义翻转的 slack 增量
\[
\delta_g(X)=1_{v\in X}-1_{u\in X}.
\]
令 \(N(g)\) 为 \(\delta_g(X)=-1\) 的 rows，\(P(g)\) 为 \(\delta_g(X)=+1\) 的 rows。若模型另有 MAIN coordinates，\(M^+(g)\in\{0,1\}\) 表示有 MAIN positive target；没有单列 MAIN coordinates 时不使用这一附加项。

strict source 的条件为
\[
N(g)\cap\mathcal P=\varnothing,\qquad
\bigl(P(g)\cap\mathcal P\ne\varnothing\ \text{或}\ M^+(g)=1\bigr).
\]
source-free 指不存在这样的 physical edge。检查范围为当前 residual system 的全部相关内部物理边，包括 \(K\) 与 ancestral \(J\)，不只检查其中一类；不包括固定 outside edges。

这是相对于指定 rows／coordinates 的符号定义，不要求 source 已经对 full cut system globally legal。未纳入的 cut rows 仍可能阻塞 relative source。具体模型若使用单列 MAIN coordinates，须同时给出其坐标及 \(M^+\) 的判定，不能凭名称省略。

来源线索：Pasted text (3)(20261002-044134)。

## DS3. zero-extreme

对明确指定的 full family \(\mathcal P\)，定义
\[
O=A-\bigcup_{X\in\mathcal P}X,\qquad
C=\bigcap_{X\in\mathcal P}X.
\]
zero-extreme 精确指 \(O=C=\varnothing\)：每个顶点至少属于一行，并且至少不属于一行，即不存在全零或全一 membership atom。

full-family 的 \(O,C\) 与某个 dependency cycle 的 remainder \(R_0\)、common core \(C_0\) 是不同对象。E0.3 中两条覆盖关系只表达 all-zero atom 消失；该 ALL-D normal form 中三个 extra rows 两两不交，所以 full-family 的交集为空另由该结构保证。不能把“覆盖 \(A\)”单独当成一般 zero-extreme 定义。

来源线索：Pasted text(20261001-122804)。

## DS4. Private witness、closure 与 minimality 的界限

采用 relative private definition：相对于 retained row set \(\mathcal S\)，\(g\) 是 \(Z_i\)-private，当且仅当
\[
N(g)\cap\mathcal S=\{Z_i\},
\]
并且具有 retained extra positive target 或 MAIN positive target。后续称为 **support-capable private witness**，并显式注明 \(\mathcal S\) 与 retained targets。

旧 essential private witness 尚无统一定义；不能自动解释为 deletion-essential、minimal-support-essential 或 chosen dependency witness，也不能未经核对直接替换成新定义。

closure 历史上混用 source-closed blocker family、actual-tight closure、FULL-SUPPORTABLE core，目前没有统一定义。inclusion-minimal 必须写出删除一行后需要保持的全部性质。用户补充报告：FULL-SUPPORTABLE minimality 不保证 source-free；该结论的原证明待归档，二者不得合并为同一条件。

来源线索：Pasted text (3)(20261002-044134)。

## DS5. MAIN dependency cycle、cross-free 与 signed duality

\(X_1\to\cdots\to X_r\to X_1\) 是 row/service dependency cycle：每条 chosen private physical edge 在 \(X_i\) 上为负、在 \(X_{i+1}\) 上为正，对其余 cycle rows neutral。物理边的 head/tail 顶点不要求彼此首尾相接。extra dependency cycle 使用相同解释。

ALL-D homogeneous cycle 的 \(X_i\) 两两不交，\(R_0=A-\bigcup_iX_i\)，且 \(R_0\) 不是 cycle row。\(R_0\ne\varnothing\) 是 true-critical no-tight-partition 等条件下导出的结论，不属于 cycle 的定义。

crossing 始终相对于内部 ground set \(A\)：\(X\cap Y,X-Y,Y-X,A-(X\cup Y)\) 四块全非空；cross-free 指没有这样的 pair。

用户补充报告 exact cross-free dependency cycle 的 arbitrary-\(r\) homogeneity theorem 给 ALL-D / ALL-C；完整 theorem statement 与证明待分类附录归档。signed reroot dual 需要 complement 与 edge/sign reversal 的联合变换；本档尚缺 \(R,S,p,D\) 和 tightness 的完整变换公式。保持 \(D\) 不变仅取补时，actual-tight 的补集 slack 为 \(\mu\ge1\)，不能据此自行完成 ALL-C reduction。

## DS6. Balanced completion、temporal width 与 full fiber

以完整内部参考定向 \(R\) 为起点；目标 \(\bar R\) 保留 ancestral \(J\) 的原方向并反转 designated \(K\)-edges。对 \(B\subseteq J\)，balanced certificate 是三阶段的合法单物理边路径：

1. 从 \(R\) monotone reverse \(B\)，每条 \(B\)-edge 一次；
2. 保持 \(B\) 当前方向，serialize 全部 designated \(K\)-edges，每条一次；
3. monotone restore \(B\)，每条 \(B\)-edge 再一次。

其余 \(J-B\) 保持原方向；全部中间状态都对 full residual cut system 合法。定义
\[
\beta_{\rm bal}=\min\{|B|:B\text{ 有上述 certificate}\},
\]
不存在则为 \(\infty\)。

对任意完整合法路径 \(\gamma:R\leadsto\bar R\)，令
\[
\operatorname{occ}_J(D)=|\{g\in J:D(g)\ne R(g)\}|,\qquad
w=\min_\gamma\max_{D\in\gamma}\operatorname{occ}_J(D).
\]
这里计同时偏离原方向的 physical copies，允许任意 interleaving、重复翻转和先还后借；不计“累计用过多少条不同边”。无完整路径时 \(w=\infty\)。\(\beta_{\rm first}\) 只看第一次 \(K\)-progress 之前的 ancestral occupancy，使用时注明终止在第一次 \(K\)-flip。

这批实验的 full fiber 固定 outside \(\sigma\)，允许 \(J\cup K\) 全部内部物理边运动；frozen-\(J\) descendant 则要求 \(J\) 始终不动。旧 quotient auxiliary width \(\operatorname{aw}\) 有另一套坐标与目标定义，不能直接与 \(w,\beta_{\rm bal}\) 等同。

来源线索：Pasted text(20261001-175935)。

## DS7. Petri 分支改名与尚缺的动态接口

当前 Petri switch 的 H1/H2/H3 统一改名为 **PH1/PH2/PH3**，旧 global H1（fixed-outside fiber connectivity）等名称保留原义。first source \(f:B_0\to A_0\) 后，second source 分别为 PH1：\(A_0\to C_0\)，PH2：\(D_0\to B_0\)，PH3：\(D_0\to C_0\)。

D3 为 \(k\)-created blocker，slack trace \(1\to1\to0\)；D1 为 \(h\)-created、later \(k\)-neutral，trace \(1\to0\to0\)。这里 \(h,k,l\) 是边名，边名 \(k\) 应与连通度参数按上下文区分。

reverse last flip 合法源于它返回已知合法前驱；随后 \(l\) 合法仍需额外条件。D3 所用 unique blocker + handoff-overlap，以及 SAME-C、\(\eta\)、N0 的完整定义和步骤假设尚待原输出回填，不能从 slack trace 单独推导。

## DS8. LEVEL2 C2 与 endpoint-essential 的范围

falsifier 线的参数 \(m=2\) 指 \(|K|=2\)，规范化为 directed physical path \(0\to1\to2\)。LEVEL2 C2 指该 two-edge antipodal frozen setting 中的指定 first-failure/launch pattern：有 launch edge（原输出边名 \(m\)），cut \(Y\) 在 \(R\) slack 为 1，沿 \(m,k_1,k_2\) 的指定 signature 为 \((1;1,0,1)\)，slack 依次 \(1\to0\to0\to-1\)，而目标 \(\bar R\) feasible。此 signature 含失败步骤，不能称整个三步序列均合法；完整模板待原输出归档。

ancestral physical copy \(g\) 为 endpoint-essential：删除 \(g\) 后，给定 \(R\) 或 \(\bar R\) 至少一个 endpoint 失去 feasibility，由该 endpoint 的 tight cut 认证。用户补充报告旧 MU-only、C2-only essentiality 已在 minimum-disconnected necessary class 中排除；原证明待归档。

\(20\) ordered types 与 \(|J|\le40\) 只适用于 \(|A|=5\)、每 ordered type \(n_{uv}\le2\) 的模型。\(\min|J|=8\) 只指指定 \(k=2,|A|=5,|K|=2\)、endpoint-essential LEVEL2 C2 / pair-antichain 搜索域，不能提升成所有系统的最小值。

## DS9. Deletion-cost dual 的已补定义与证明依赖

以 \(R\) 中当前方向计数，删除 \(e\in K\)，cut weights \(y_X\ge0\)，记 \([a]_+=\max(a,0)\)：
\[
D_e(y)=\sum_{X:e\text{ leaves }X}y_X,\qquad
S_R(y)=\sum_Xs_R(X)y_X,
\]
\[
\phi_y(v)=\sum_{X\ni v}y_X,\qquad
\Delta_y(u\to v)=\phi_y(v)-\phi_y(u),
\]
\[
L_K(y)=\sum_{f\in K-\{e\}}[\Delta_y(f)]_+,\qquad
L_J(y)=\sum_{g\in J}[\Delta_y(g)-1]_+,
\]
\[
\operatorname{Debt}_e(y)=D_e(y)-S_R(y)-L_K(y)-L_J(y).
\]
这些是用户补充给出的 exact LP dual terms；完整 primal、five-atom LP、interior/support-minimal 判定及相关 theorem hypotheses 待原输出归档。对相应原问题，dual 值给 lower bound；把最小整数 ancestral cost \(c^*(e)\) 写为
\[
c^*(e)=\max_{y\ge0}\operatorname{Debt}_e(y)
\]
仍须核定所调用 box-integrality / crossing-submodular-flow theorem 的适用域。

历史 weighted-siphon 中的 demand vector 原名 \(q\)，今改为 \(b_{\rm req}\)，与 terminal residual function \(q(Y)\) 无关；其完整需求定义仍须回填。

来源线索：Pasted text (3)(20261001-144801)。

## DS10. Ambient distance 与 legal flip distance

对 quotient multiplicity coordinates \(x,y\)，统一写
\[
d_{\rm amb}(x,y)=\sum_C|x_C-y_C|,
\qquad
d_{\rm flip}(x,y)=\operatorname{dist}_{Q(G,k)}(x,y).
\]
barrier 为
\[
\beta_Q(x,y)=
\min_{\gamma:x\leadsto y}
\left[\max_{z\in\gamma}d_{\rm amb}(z,y)-d_{\rm amb}(x,y)\right],
\]
其中 \(\gamma\) 为 legal quotient paths。不能用 \(d_{\rm flip}\) 代替 \(d_{\rm amb}\)：对连通点对沿最短路计算，替换后的 barrier 恒为 0。用于 labelled physical states 时，另注明所取的 physical flip graph。

Slack-Token 旧式 “\(d_Q=3,\beta_Q=t\)” 中 3 指 \(d_{\rm amb}\)，不是 legal shortest-path length；旧 auxiliary-width 2 witness 中 \(d_Q(x,y)=7\) 则指 \(d_{\rm flip}\)。正文相应记号已分别更正。\(d_Q^+(X)\) 是定向 \(Q\) 的出割记号，不是距离，不作替换。

来源线索：Pasted text(20260926-175612)。

## DS11. 状态审计与待归档材料

| 条目 | 当前状态与适用范围 |
| --- | --- |
| Critical endpoint \(q\) formula、\(\mu_J=\mu\)、two-state antipodality、remaining edges endpoint-illegal | 用户补充确认为稳定输入；本次归档不新增证明。 |
| Initial unfixed terminal deletion theorem | 保留；不能推广为任意固定 \(J\) 的版本。 |
| Arbitrary-\(J\) strengthened RCD | **SUPERSEDED / FALSE**。用户确认 2026-10-01 15:09 更新已有 genuine \(k=2,\lambda=5\) global counterexample；原 witness／证明待归档。历史 OPEN 标签以下均已就地更正。 |
| B+ common-completion／quotient-boundary package | **LOCK-CANDIDATE**；准备正式证明时逐条核定假设与 lifting。 |
| Long-edge 与 mincost 中的 Edmonds–Giles box-integrality | 外部定理的 exact scope 待审计；依赖它的步骤保留条件性。 |
| Lovász／Schrijver adjacency 与 circuit／vertex-disjoint-path support | **CONDITIONAL ON EXTERNAL THEOREM SCOPE AUDIT**；不是无条件 LOCKED。 |
| Two-extra NF1–NF6 与 three-extra pure-cycle reduction | 沿用项目结果 ledger；完整 normal-form statements、sign tables、exhaustiveness proof 未并入，需 Classification Appendix。 |
| TTS 的 genuine terminal projection | **SCOPE AUDIT REQUIRED**。与当前 no-tight-copartition theorem 的适用范围尚未核清，不能猜测它缺少哪个假设。 |
| essential private witness、统一 closure／minimality、signed reroot formulas、Petri 完整动态接口 | 定义／原始证明待回填；不另立数学 OPEN。 |
| D1 gadget、16 first-hit controls、minimum-\(\lvert J\rvert\) census | 目前只有摘要及本页给出的搜索域限制；完整 edge tables、boundary counts、筛选器、原始结果待归档，未重新运行计算。 |
| 9月28日历史层的损坏公式 | 保留原字节；须从原始输出、旧 Markdown 或对应对话恢复，禁止凭上下文猜修。 |

当前主问题的 global necessity / temporal bridge 仍未闭合。本页不把原始证明缺失解释成新反例，也不把用户报告的局部结果提升成主连通性定理。

---

# A0. 核心问题与 2026-10-02 总判断

设 \(G=(V,E)\) 为 finite loopless undirected multigraph，parallel physical edges 保留身份。orientation \(D\) 为 \(k\)-arc-strong 当且仅当

\[
d_D^+(X)\ge k
\qquad
\forall\emptyset\ne X\subsetneq V.
\]

legal move = reverse **one physical edge**，且翻转后仍保持 \(k\)-arc-strong。

核心 open threshold：

\[
\boxed{
\lambda(G)\ge 2k+1,\quad k\ge2
\Longrightarrow
\Omega_k(G)\text{ 在 legal single-edge flips 下 connected?}
}
\]

已知 \(\lambda(G)\ge2k+2\) 时 YES；临界层 \(2k+1\) 仍 OPEN。

## A0.1 当前协调判断

截至 2026-10-02，证据方向仍明显偏向 **TRUE / positive theorem**，但最终证明语言已经从 static obstruction elimination 明确转向 **temporal serialization / balanced buffer / history-certified escape**。

当前最准确的描述不是“马上证明”，而是：

\[
\boxed{
\text{反例空间继续收缩，正面 proof architecture 更清楚；}
\text{但一般 dynamic theorem 仍未闭合。}
}
\]

尤其：

- two-extra static normal forms 已经 **全部 DEAD**；
- three-extra minimal closure 不再出现组合爆炸，而是压到唯一 pure directed 3-cycle primitive；
- generic unique-blocker starvation 确实存在，甚至可 true-critical terminal realize；
- 但 N0 k-created history 会自动提供 reverse-k service；
- D1 h-created starvation 也可 true-critical realize，但最小 3-atom / 5-edge gadget 的 full fiber 仍 connected；
- static pair-exchange 甚至 natural size-3 exchange 都可以完全失败，而 full fiber 仍通过 temporal two/three-buffer excursion 连通；
- 因此 “static redundancy / packet exchange” 不再被视为 connectivity 的正确普适语言。

---

# B0. 当前 master architecture

## B0.1 Critical-shore residualization

本节及当前静态分类默认采用 DS1 的 initial true-critical residual system；所有 actual-tight rows 属于同一个完整内部定向。固定 \(|\delta_G(A)|=2k+1\) 的非空真 shore \(A\)，outside orientation \(\sigma\) 须有 global legal extension。令 \(H=G[A]\)。对 \(\varnothing\ne Y\subsetneq A\)，

\[
q(Y)=\min_{Z\subseteq V-A} d^+_{K_\sigma}(Y\cup Z),
\qquad
p(Y)=k-q(Y).
\]

true-critical endpoint formula：

\[
\boxed{
q(Y)=\min\{R(Y),S(A-Y)\}
}
\]

其中 \(R(Y)\) 是 \(Y\to(V-A)\) boundary arcs 数，\(S(Y)\) 是 \((V-A)\to Y\) boundary arcs 数。

定义 residual slack：

\[
s_D(Y)=d_D^+(Y)-p(Y)\ge0.
\]

定义 symmetric margin：

\[
\mu(Y)=|\delta_H(Y)|-p(Y)-p(A-Y)\ge1
\]

以上为 initial residual 的公式；fixed-\(J\) signed descendant 使用 \(p_J=p-d_J^+\)，其他性质的继承须按 DS1 分别核定。

## B0.2 Minimum component-separating descendant

若主命题失败，取 minimum component-separating descendant。当前稳定结构：

- remaining \(K\)-edges 在所有 surviving endpoint states 中 individually illegal；
- antipodal endpoint states恰为 \(R,\bar R\)；
- \(\bar R\) 反转所有 remaining \(K\)-edges；
- reversal-feasibility polytope 是一条 integral long edge：

\[
P_R=\operatorname{conv}\{\mathbf0,\mathbf1\}=[\mathbf0,\mathbf1].
\]

对应 common-tight dangerous family与 weighted potential \(w(v)\) 仍是长期基础工具。上面的 polytope segment 结论依赖 box-integrality 适用域；进一步使用 circuit／vertex-disjoint-path support 还依赖 Lovász／Schrijver adjacency scope audit，见 DS11。

## B0.3 当前真正 global bridge

目前尚缺的不是“某个 blocker 是否存在”，而是：

\[
\boxed{
\text{minimum component separation}
\Longrightarrow
\text{closed temporal obstruction / no balanced completion}
\Longrightarrow
\text{terminal geometry contradiction}.
}
\]

这条 dynamic bridge 是当前总项目的最核心未闭合层。

---

# C0. Critical Boundary Skew 与 terminal geometry（继续 LOCKED）

对 nontrivial partition

\[
A=P_1\dot\cup\cdots\dot\cup P_t
\]

定义

\[
\Phi=\sum_i\bigl(q(A-P_i)-q(P_i)\bigr).
\]

true-critical boundary totals 为 \((k,k+1)\) 或 \((k+1,k)\)，并有：

\[
|\Phi|\le1.
\]

更精确：

- 若 \(R(A)=k,S(A)=k+1\)，则 \(\Phi\in\{0,1\}\)；
- 若 \(R(A)=k+1,S(A)=k\)，则 \(\Phi\in\{-1,0\}\)。

这给出当前最频繁使用的两个 terminal 禁止：

\[
\boxed{\text{NO NONTRIVIAL ACTUAL-TIGHT PARTITION}}
\]

以及其 co-partition dual。

另有 chain quasi-concavity：若 \(E\subset F\subset G\)，则

\[
q(F)\ge\min\{q(E),q(G)\}.
\]

因此 strict \(q\)-valley 是 terminal contradiction 的稳定模板。

---

# D0. Static source-free closure：TWO-EXTRA LAYER 已完全关闭

本节采用 DS1–DS5 的 initial scope、relative source-free 与 full-family zero-extreme。NF 的完整定义与分类穷尽性证明尚待 Classification Appendix；以下保留项目结论 ledger。

## D0.1 两-extra exact classification

之前 two-extra normal forms 记为 NF1--NF6。到 2026-10-02 为止，所有 fork / chain / second-cycle 分支均已 terminally closed。

### NF1

- feeder fork：DEAD。
- decisive input：true-critical terminal pressure，而非仅 source-free geometry。

### NF2

- second-cycle：DEAD；
- splice：DEAD by one-extra reduction；
- CHAIN-P：DEAD；
- CHAIN-H：DEAD。

关键 hidden-capacity mechanism：AUX co-cover pair + source-free direction forcing + critical boundary budget 强迫 remainder atom \(Q\) actual-tight，补成 forbidden actual-tight partition。

### NF3

CORE-NESTED second-cycle：DEAD。

核心：core nesting + source-free 强迫所有 \(R_0\to X_i\) 方向消失，进而 \(R_0\) actual-tight，补成 forbidden tight partition。

### NF4

- NF4a second-cycle：DEAD；
- NF4b second-cycle：DEAD；
- NF4a chain：DEAD；
- NF4b chain：DEAD。

NF4a decisive pressure来自 sibling slack；NF4b 中 external feeder精确替代 reciprocal slot，local \(q\)-surplus不减。

### NF5

Different-block double co-split fork：DEAD。

### NF6

- same-block fork：DEAD；
- double-hole second-cycle：DEAD；
- chain：DEAD。

branch-independent double-hole accounting：若

\[
X=W_1\dot\cup W_2\dot\cup V,
\qquad
Z_1=A-W_1,
\qquad
Z_2=A-W_2
\]

actual-tight，并且 source-free 禁止 \(W_1\to V,W_2\to V\)，令

\[
o_a=\#((A-X)\to W_a),
\]

则

\[
\Delta:=q(W_1)+q(W_2)+q(V)-q(X)-q(Z_1)-q(Z_2)
\ge \mu(W_1)+\mu(W_2)+o_1+o_2.
\]

由此得到 exact hierarchy：

\[
\boxed{
\text{SECOND-CYCLE: }\Delta\ge2,
\quad
\text{CHAIN: }\Delta\ge3,
\quad
\text{FORK: }\Delta\ge4.
}
\]

NF6 chain 最终由 RIGHT \(q\)-pressure + main predecessor LEFT pressure + chain quasi-concavity + Critical Boundary Skew equality 杀掉。

因此：

\[
\boxed{
\textbf{ALL TWO-EXTRA STATIC NORMAL FORMS ARE DEAD.}
}
\]

## D0.2 重要 methodological correction

模型一对 NF6 CHAIN 的 pure source-free / automatic-tight test曾得到 OPEN：\(W_1,W_2\) 实际上是 positive-slack reservoirs，而不是自动 tight。

这不是与最终 DEAD 冲突，而是说明：

\[
\boxed{
\text{source-free geometry alone strictly weaker than terminal }q\text{ geometry.}
}
\]

以后不要把 source-free coarse orientation closure 当成 terminal impossibility 的充分语言。

---

# E0. THREE-EXTRA：组合爆炸已压到唯一 pure 3-cycle primitive

## E0.1 Reduction theorem

考虑 inclusion-minimal、source-free、actual-tight、zero-extreme family，包含 homogeneous MAIN cycle \(X_1,\dots,X_r\) 和恰好三个 extra rows \(Z_1,Z_2,Z_3\)。cycle 是 DS5 的 row/service dependency cycle；inclusion-minimal 所保持的条件与旧 essential private witness 的含义仍须原始分类定理补齐。

若删除某个 \(Z_c\) 后，另外两 rows 可以重新选择 essential private witnesses 并形成 genuine two-extra subsystem，则由 D0 直接 DEAD。

pairwise-irreducible survivor 被强迫成：

\[
\boxed{
Z_1\to Z_2\to Z_3\to Z_1
}
\]

up to reversal。

而且是 **PURE 3-CYCLE**：每个 \(Z_i\) 的所有 essential private witnesses 只能 service 唯一 next extra；不能同时 service MAIN、第三个 extra 或携带 overlay。

selected sign matrix：

\[
\begin{array}{c|ccc}
 & h_1 & h_2 & h_3\\\hline
Z_1&-1&0&+1\\
Z_2&+1&-1&0\\
Z_3&0&+1&-1\\
X_m&0&0&0
\end{array}
\]

for every MAIN row \(X_m\)。

## E0.2 Cross-free geometry

三对 extra rows 必须 homogeneous：

- ALL-D：\(Z_1,Z_2,Z_3\) pairwise disjoint；
- ALL-C：complements \(A-Z_1,A-Z_2,A-Z_3\) pairwise disjoint。

mixed D/C triangle 不可能。

项目原 reduction 使用 signed reroot dual 将 ALL-C 交由 ALL-D 处理。完整 complement + edge/sign reversal 及 \(R,S,p\) 变换公式未归档，见 DS5；不能仅取补就认定保留 actual-tight。

## E0.3 Minimal ALL-D normal form

\[
A=Z_1\dot\cup Z_2\dot\cup Z_3\dot\cup Q,
\qquad Q\ne\emptyset,
\]

其中前三个 rows 在同一完整内部定向中 actual-tight，由 private physical edges 见证的 row/service dependency cycle：

\[
h_1:Z_1\to Z_2,
\qquad
h_2:Z_2\to Z_3,
\qquad
h_3:Z_3\to Z_1.
\]

所有 \(h_i\) 对 MAIN rows neutral，所以每个 \(h_i\) 的 endpoints 必须位于同一个 MAIN fiber \(R_0\) 或某个 \(X_j\)。

full-family zero-extreme 采用 DS3 的 \(O=C=\varnothing\)。本 ALL-D normal form 中 extra rows 两两不交已保证 \(C=\varnothing\)；\(O=\varnothing\) 表达为以下等价的覆盖关系：

\[
Q\subseteq\bigcup_j X_j,
\qquad
R_0\subseteq Z_1\cup Z_2\cup Z_3.
\]

四块 partition skew 已经强迫必要条件：

\[
\boxed{s(Q)\ge2.}
\]

### 当前 static frontier

\[
\boxed{
\text{PURE THREE-EXTRA ALL-D 3-CYCLE — TRUE-CRITICAL TERMINAL TEST.}
}
\]

当前尚未证明 terminal-realizable，也尚未证明 impossible。

---

# F0. PETRI / dynamic serialization：depth-3 created-blocker 状态

## F0.1 Four-atom switch

标准 four-atom geometry：

\[
Z_1=A_0\cup C_0,
\qquad
Z_2=B_0\cup C_0,
\]

四 atoms \(A_0,B_0,C_0,D_0\) nonempty。

forward source \(f:B_0\to A_0\) 后，tracked slack 从 \((0,1)\) 迁移到 \((1,0)\)。

最小 second-source atom types曾分类为：

- PH1：\(A_0\to C_0\)；
- PH2：\(D_0\to B_0\)；
- PH3：\(D_0\to C_0\)。

## F0.2 PH3 negative endpoint branch — DEAD

若 PH3 导致某 initial-tight row \(Z_1\) 的 TYPE-II endpoint net \(\eta(Z_1)=-1\)，则所有 temporary preparation edges restored 后 final slack 必为 \(-1\)。

因此 SAME-C balanced completion 不可能。

## F0.3 PH2 — 更强：forward serialization 本身 DEAD

PH2 中 after \(f,h\)：

\[
s(Z_1)=s(Z_2)=1.
\]

令

\[
I=Z_1\cap Z_2=C_0,
\qquad
U=Z_1\cup Z_2=A_{\rm tot}-D_0.
\]

exact crossing slack identity：

\[
s(I)+s(U)
=2-m_H(A_0,B_0)-\theta,
\qquad \theta\ge0.
\]

而 physical petal edge \(f\) 给 \(m_H(A_0,B_0)\ge1\)，所以

\[
s(I)+s(U)\le1.
\]

下一条 desired \(g:C_0\to D_0\) 同时 leaves \(I\) 与 \(U\)，其合法性却要求二者 slack 都至少 1，矛盾。

永久 lemma：

\[
\boxed{
\text{TWO-PETAL SERVICE LEMMA}
}
\]

crossing \(X,Y\) 若 \(s(X)=s(Y)=1\)，且 exclusive petals 间存在 physical edge，则不能 legal flip 一条 \(X\cap Y\to V-(X\cup Y)\) 的 edge。

因此 PH2 从 project-level candidate list 完全删除。

## F0.4 当前 dynamic frontier

仍需：

- audit PH1 是否同样被 TWO-PETAL SERVICE 直接杀死；
- audit PH3 with nonnegative endpoint net \(\eta\ge0\)；
- 若还有 survivor，再研究 restoration / moving blocker。

---

# G0. POLYTOPE-CIRCUIT / starvation：generic obstruction 可以存在，但 history 继续提供 escape

## G0.1 Generic unique-blocker starvation — REALIZABLE

true-critical terminal level存在 3 atoms / 5 internal edges 的 smallest starvation witness：target \(l\) 有唯一 tight blocker \(Z\)，且所有 entering-\(Z\) service edges均 illegal。

因此 generic theorem

\[
\text{UNIQUE BLOCKER}\Rightarrow\text{LEGAL ONE-EDGE SERVICE}
\]

FALSE。

## G0.2 D3 / k-created history — UNIQUE blocker branch DEAD

在 N0 nested / k-created D3 中：

\[
s_Z:1\xrightarrow{h}1\xrightarrow{k}0.
\]

最后的 \(k\) 正是创建 tight \(Z\) 的 flip。blocked state 中 reverse-\(k\) 当前方向 enters \(Z\)，且必 legal，因为它返回已知 feasible predecessor。

若 \(Z\) 是 target \(l\) 的 unique blocker，handoff-overlap 进一步给 universal two-flip escape：

\[
D^*\xrightarrow{\bar k}D^h\xrightarrow{l}\cdots.
\]

所以 D3 unique-blocker branch universally dead in full fiber。

## G0.3 D1 / h-created history — TERMINAL-REALIZABLE-CONNECTED

D1 signature：

\[
s_Z:1\xrightarrow{h}0\xrightarrow{k}0,
\]

其中后来的 \(k\) 对 \(Z\) neutral。

smallest generic starvation witness 本身就携带完整 D1 history；earlier creating edge \(h\) 可以在 later neutral \(k\) 后变 illegal。

但 exact full-fiber census：

- 32 total labeled orientations；
- 8 feasible states；
- 7 legal-flip edges；
- 1 component；
- diameter 4；
- final blocked starvation state为 leaf；
- shortest target escape：

\[
\boxed{\bar k,\ \bar h,\ l}
\]

长度 3。

所以：terminal-realizable starvation \(\not\Rightarrow\) component barrier。

### 当前 D1 frontier

真正问题不是“undo \(k\) 后有没有 service edge”（historical \(\bar h\) 在 predecessor 中自动 legal），而是：

\[
\boxed{
\text{complete history rewind }\bar k,\bar h\text{ 后，target }l\text{ 是否必 legal？}
}
\]

也就是 two-flip same-target blocker handoff / persistent blocker 问题。

---

# H0. RESIDUAL-FALSIFIER：static exchange hierarchy 不是 connectivity language

## H0.1 Endpoint-essential pair-antichain

定义与量词范围见 DS8；本线 \(m=|K|=2\)，remaining physical path 为 \(0\to1\to2\)。

在 \(k=2,|A|=5,m=2\) 的 LEVEL2 C2 setting，存在 genuine pair-exchange antichain：

- every ancestral physical copy endpoint-essential；
- \(n_{uv}\le2\)；
- 任意 distinct physical copies \(g,h\)，DELETE \(g\)+REVERSE/REFIX \(h\) 都不能同时保持 \(R,\bar R\) endpoint feasibility。

在本节指定 \(k=2,|A|=5,|K|=2\)、endpoint-essential LEVEL2 C2 / pair-antichain 搜索域内，minimum \(|J|=8\)；原始完整枚举材料待归档。

但 full fiber仍 connected。

natural static size-3 packets DELETE \(g\)+REVERSE \(h_1,h_2\) 也可以 0/168 feasible，仍不妨碍 temporal connectivity。

因此：

\[
\boxed{
\text{STATIC PACKET EXCHANGE HIERARCHY IS NOT A NECESSARY CONNECTIVITY LANGUAGE.}
}
\]

## H0.2 First-hit temporal widths

balanced certificate、\(\beta_{\rm bal}\)、physical occupancy width \(w\) 及 full fiber 的严格含义见 DS6；16 个 first-hit controls 的完整筛选器与数据待归档。

对 16 个 exact first-hit pair-antichain controls：

\[
\begin{array}{c|c}
\text{temporal width }w & \#\\\hline
2&12\\
3&4
\end{array}
\]

minimum \(|J|\) with \(w=3\) is 9。

所以 universal two-buffer FALSE even on first-hit controls。

但所有 16 个 controls 都有：

- first K progress width = 1；
- monotone balanced K-completing support \(B\)；
- open \(B\) monotonically；
- 固定 \(B\) 后连续 serialize both K edges；
- 再 monotonically restore \(B\)。

定义 \(\beta_{\rm bal}\) 为最小 balanced completing support size，则对这 16 个 controls：

\[
\boxed{\beta_{\rm bal}=w\in\{2,3\}.}
\]

standard set-system axioms中只有 accessibility 在 16/16 成立；down-set / union closure / antimatroid augmentation / greedoid exchange / interval property 全部 0/16。

### 当前 falsifier frontier

搜索：

\[
\boxed{\beta_{\rm bal}=\infty}
\]

的 first true-terminal endpoint-essential pair-antichain C2 system。

- 若 \(\beta_{\rm bal}=\infty\) 但 full fiber connected：说明需要 genuinely interleaved temporal dynamics；
- 若同时 disconnected：将成为最接近 necessity-bridge counterexample 的 global obstruction。

## H0.3 Current no-loss bound

在本线 \(|A|=5\) 的 minimum-disconnected necessary class 中，项目结论为 every ancestral physical copy 必须 endpoint-essential，MU-only 与 C2-only essentiality均 DEAD；因此每 ordered type \(n_{uv}\le2\)。\(5\cdot4=20\) ordered types 给该模型内的 no-loss bound（原证明待归档）：

\[
\boxed{|J|\le40.}
\]

这替代旧 \(|J|\le100\) bound。

---

# I0. MINCOST-SERVICE-DUAL：positive-\(S_R\) certificate 继续被压缩

## I0.1 Stable dual

各 dual 项定义、reference orientation 与 integrality 依赖见 DS9。对 deletion completion 的 minimum ancestral cost，dual 形式：

\[
\operatorname{Debt}_e(y)
=D_e(y)-S_R(y)-L_K(y)-L_J(y).
\]

extremal value-2 certificate 可 regularize 为 cross-free / support-minimal / minimum-total-weight。

## I0.2 已死 normal forms

- three-row positive-\(S_R\) atom：DEAD；
- four-row homogeneous chain：DEAD；
- arbitrary-length homogeneous deletion-chain extension：DEAD。

因此 genuine survivor必须含 transverse side-row / leak-control geometry。

## I0.3 D-C transverse correction

此前候选 five-membership splitter：

\[
A=P\dot\cup Q_1\dot\cup Q_0\dot\cup T\dot\cup U,
\]

\[
X=T\cup U,
\quad Y_D=P,
\quad Y_C=P\cup Q_1\cup Q_0\cup T,
\quad Z=P\cup Q_1.
\]

原先错误地要求 D-shield 同时满足

\[
\delta_{Y_D}=+1,
\qquad
\delta_Z=-1.
\]

但 \(Y_D\subset Z\)，nested incidence 使这组 signs set-theoretically impossible。

正确 physical D-shield endpoints只能为

\[
T\to P
\quad\text{或}\quad
U\to P,
\]

并且自动

\[
\delta_Z=+1.
\]

所以 \(Z\) 不是 “shield consumer + counter-hinge producer”，而是 **DOUBLE PRODUCER**。

正确 designated gradients：

- 若 \(f_D:T\to P\)：\(\Delta_D=d+z-x\)；
- 若 \(f_D:U\to P\)：\(\Delta_D=d+c+z-x\)；
- canonical C-shield \(f_C:U\to Q_0\)：\(\Delta_C=c-x\)；
- counter-hinge \(h:T\to Q_1\)：\(\Delta_h=z-x\)。

### 当前 dual frontier

\[
\boxed{
\text{CORRECTED FIVE-ATOM DOUBLE-PRODUCER PIECEWISE-LINEAR LP.}
}
\]

目标仍是决定是否存在 interior support-minimal exact \(\operatorname{Debt}=2\) witness。若不存在，则 D-C transverse 四-row splitter继续死亡；若存在，只能先标 abstract dual realization，不能自动升级到 genuine minimum-descendant。

---

# J0. 最新 FALSE / DEAD / DO-NOT-REVIVE ledger（增量）

以下路线不得复活为 universal theorem：

1. TTS / “\(\mu\ge2\Rightarrow\) connectivity”；
2. inert-two-slack；
3. binary phase chamber connectivity；
4. broad / protected FDE / PFDE；
5. TGCE / TGCE-2；
6. critical signed-cover exclusion；
7. static positive-row Farkas contradiction；
8. blockers unsigned laminar；
9. universal one-buffer repair；
10. universal two-buffer repair；
11. \(\Delta_w>0\Rightarrow\) usable service；
12. ordinary M-convex / basis exchange \(\Rightarrow\) physical serialization；
13. recursive reuse of initial residual deletion theorem after fixing；
14. exact phase vector as complete state；
15. local blocker path \(\Rightarrow\) persistent component；
16. common blocker \(\Rightarrow\) unrestricted return stability；
17. local no-atom-drift；
18. full closure = one circuit；
19. universal UNIQUE-BLOCKER \(\Rightarrow\) one-edge service；
20. universal static size-2 joint removability；
21. natural static size-3 packet exchange as connectivity certificate；
22. D1 analogue “historical creating edge must remain legal”；
23. PH2 slack-1 restoration baton as genuine terminal trajectory；
24. old D-C five-atom “shield consumer” incidence normal form。
25. arbitrary fixed-\(J\) strengthened RCD：SUPERSEDED / FALSE；initial unfixed terminal deletion theorem 保留，见 DS11。

旧档中若出现以上命题的 OPEN / hopeful 版本，一律视为 historical superseded。

---

# K0. 2026-10-02 当前最高价值 OPEN QUESTIONS

## K0.1 Pure three-extra 3-cycle terminal test

当前 static 第一优先级：

\[
Z_1\to Z_2\to Z_3\to Z_1,
\qquad
A=Z_1\dot\cup Z_2\dot\cup Z_3\dot\cup Q,
\qquad s(Q)\ge2.
\]

要决定 true-critical endpoint formula 是否允许它。

## K0.2 PH1 / PH3 depth-3 created-blocker coverage

TWO-PETAL SERVICE 已杀 PH2。要 audit PH1 是否同型死亡，以及 PH3 with \(\eta\ge0\) 是否仍有 residual survivor。

## K0.3 D1 complete-rewind same-target handoff

terminal D1 starvation可存在，但最小 witness连通。目标是证明或杀掉 universal escape

\[
\bar k,\bar h,l.
\]

## K0.4 Corrected double-producer LP

决定 abstract dual value-2 D-C splitter是否存在。

## K0.5 Balanced completion falsification

寻找 \(\beta_{\rm bal}=\infty\) 的 endpoint-essential pair-antichain C2 system，并随后做 full-fiber verdict。

## K0.6 Global necessity bridge

最终仍需把：

\[
\text{minimum disconnected descendant}
\]

转化为某种无法 balanced-complete / 无法 history-rewind / static closure survivor 的 canonical global obstruction，再用 terminal geometry排除。

---

# L0. 六模型当前分工（2026-10-02）

## 模型一｜DEGREE-ZONOTOPE

当前负责 pure combinatorial incidence：three-extra pairwise-irreducible core 的 sign-matrix / D-C-nested classification，不与 terminal q 重复。

## 模型二｜PETRI-SERIALIZATION

当前负责 PH1 / PH3 depth-3 branches 与 TWO-PETAL SERVICE coverage；PH2 已永久关闭。

## 模型三｜MINCOST-SERVICE-DUAL

当前负责 corrected five-atom DOUBLE-PRODUCER LP；旧 shield-consumer splitter不得复活。

## 模型四｜INTERVAL-SUPPORT

当前负责 pure ALL-D three-extra directed 3-cycle 的 true-critical terminal test；two-extra static layer已完成。

## 模型五｜POLYTOPE-CIRCUIT

当前负责 D1 complete history rewind 后 target legality / two-flip same-target blocker transfer。

## 模型六｜RESIDUAL-FALSIFIER

当前负责 balanced-completion falsification：搜索 \(\beta_{\rm bal}=\infty\) 的 first control；不再机械升级 static packet size。

---

# M0. 当前正面 proof picture

现在最有希望的 proof skeleton 已从 2026-09-30 的 generic “service chain existence” 进一步具体化为：

1. **Minimum descendant reduction**：把 global failure 压到 antipodal \(R,\bar R\) + long-edge support；
2. **Static closure elimination**：source-free actual-tight closure 中 two-extra 全死；three-extra 只剩 pure cycle；
3. **Terminal rigidity**：Critical Boundary Skew / endpoint formula / quasi-concavity 对 homogeneous cycles 产生厚 remainder / heavy-block pressure；
4. **History-certified dynamics**：最后创建 blocker 的 edge 的 reverse 往往自动 legal；generic starvation 不等于 persistent barrier；
5. **Balanced buffer picture**：static delete/refix exchange可完全失败，但 reachable monotone support仍能打开 K；
6. **最终所需 theorem**：minimum disconnected witness 必须产生一个既不能静态 reduction、又不能 history rewind、又不存在 finite balanced completing support 的 closed temporal structure；然后证明 critical terminal geometry不允许该 structure。

因此当前项目已明显离开“找一个 universal local blocker lemma”的阶段。

---

# N0. 当前反例 picture

若原命题最终 FALSE，现有结果强迫 genuine counterexample 至少同时满足：

- 不是 two-extra source-free closure；
- three-extra 时必须避开所有 reducible motifs，最小 static primitive只能是 pure directed 3-cycle；
- 不能仅依赖 generic unique-blocker starvation；
- 不能仅依赖 D3 k-created starvation；
- 若走 D1，必须阻止完整 history rewind 后的 target release；
- 不能靠 static pair / natural triple exchange antichain本身造成 separation；
- 必须有 \(\beta_{\rm bal}=\infty\) 或更复杂 genuinely interleaved temporal obstruction；
- 仍需穿过 true-critical endpoint \(q\)-geometry 与 Critical Boundary Skew。

这比旧档案中“serial-lock gadget / high barrier”要求严格得多。

---

# O0. 当前整体评价

## O0.1 为什么比 2026-10-01 更偏正面

最重要的新结构性进展：

- two-extra static world 从“很多 branch”变成 **全部关闭**；
- three-extra world 从潜在组合爆炸变成 **唯一 pure directed 3-cycle**；
- PH2 dynamic survivor被更完整 crossing rows直接提前杀死；
- D1 genuine terminal starvation即使成为 leaf，也仍能沿 known history rewind逃出；
- pair-exchange antichain即使没有任何简单 static packet，也仍存在 width 2/3 balanced completion。

## O0.2 为什么仍不能写“接近完成”

- pure 3-cycle terminal status仍 OPEN；
- dynamic PH1/PH3 未闭合；
- D1 complete-rewind same-target transfer未闭合；
- corrected dual splitter未闭合；
- \(\beta_{\rm bal}\) 是否总 finite完全未知；
- 还没有一般 theorem 把 “minimum disconnected” 强制成上述任一已杀 canonical obstruction。

最稳妥结论：

\[
\boxed{
\text{比 2026-10-01 更接近正面证明；}
\text{但仍处于结构定理成形期，而非机械收尾期。}
}
\]

---

# P0. Soundness / anti-error rules（2026-10-02 增量）

1. **source-free OPEN 不等于 terminal OPEN。** NF6 chain 已证明这一点。
2. **terminal-realizable 不等于 component-separating。** D1 starvation 是当前最小明确 control。
3. **static exchange antichain 不等于 temporal obstruction。** pair-antichain width 2/3 controls均 connected。
4. **不能忽略 untracked uncrossed cuts。** PH2 local ledger正是被 \(I=X\cap Y\)、\(U=X\cup Y\) 杀死。
5. **physical incidence sign 必须先做 set-theoretic audit。** D-C old splitter因 nested sign incompatibility直接为空。
6. **历史边 reversibility 是信息，不是噪音。** 若某 state 来自已知 legal prefix，reverse last flip自动 legal。
7. **每个 computational statement必须注明 universe。** first-hit 16 controls / \(|J|=8,9\) 不能升级成一般 theorem。
8. **不要从 finite width 2/3 猜 uniform constant。** 当前正确 invariant 更可能是 finite balanced completion，而非 fixed width。
9. **不要复活 old ASCE / static Farkas / PFDE 作为已经成立的桥。** 这些最多是历史 motivation。
10. **若旧层与本页冲突，本页优先。** 旧层保留只为 provenance。

---

# Q0. 2026-10-01 及更早历史档案开始

> 从这里开始保留原 `graph_orientation_reconfiguration_progress_2026-10-01.md` 基本全文。
> 其中大量当时的 “CURRENT / OPEN / highest-value” 已被上面的 2026-10-02 current layer supersede；不要把历史页中的优先级直接恢复成当前任务。

---

# 图定向单边翻转重配置研究记录
## 项目总档案｜2026-10-01 六模型 + 三轮文献综合更新版

> 本版在 2026-09-30 主档案之前增加一层新的“当前状态页”，并完整保留旧档作为历史记录。若新页与后附旧档冲突，以新页为准。
>
> 本次更新吸收：模型 A（RELATIVE-FIBER / ANCESTRAL-BUFFER）、B（INTERFACE-EXIT / residual deletion）、C（RELATIVE-ITO / DIRECTIONAL-SLACK / POLYTOPE-LONG-EDGE）、D（TREE-GLUING）、E（ARCHITECTURE-AUDIT / ANCESTRAL-SERVICE），以及独立文献搜索 Round 1–3。
>
> **重要状态纪律：**本版不把“某一模型在单轮里写 PROVED”自动等同于项目级 LOCKED。下文使用：
> - **LOCKED**：2026-09-30 前已由项目独立审计，或本轮中已经成为多个后续模型明确允许使用的稳定输入且逻辑接口清楚；
> - **LOCK-CANDIDATE / CROSS-MODEL ACCEPTED**：已有完整证明文本、并被后续模型采用，但主档案尚未逐行独立复核所有外部 theorem hypothesis；
> - **EXACT REDUCTION**：逻辑 reduction 本身清楚，但目标 theorem 仍未闭合；
> - **FALSE / DEAD**：已有 genuine symbolic counterexample / construction 或严格逻辑反例，不得复活；
> - **OPEN**：当前真正未闭合的桥。
>
> 文献 ledger 中的 **FULL TEXT FOUND** 只表示搜索模型定位到了可读版本；不等价于项目已经 proof-audit。所有文献名都保留，避免后续重复搜索。

---

# A. 核心问题与 2026-10-01 当前总判断

设 \(G=(V,E)\) 为 finite loopless undirected multigraph，parallel physical edges 保留身份。orientation \(D\) 为 \(k\)-arc-strong 当且仅当

\[
d_D^+(X)\ge k
\qquad
\forall\varnothing\neq X\subsetneq V.
\]

legal move 是 reverse 一条 **physical edge**，且翻转后 orientation 仍 \(k\)-arc-strong。

核心问题仍为

\[
\boxed{
\lambda(G)\ge 2k+1,\ k\ge2
\Longrightarrow
\Omega_k(G)\text{ 在 legal single-physical-edge flips 下 connected?}
}
\]

\(\lambda\ge2k+2\) 的正结果仍是 baseline；真正临界层仍是 \(\lambda=2k+1\)。

但 2026-10-01 的 proof picture 已经与 2026-09-30 明显不同。当前最紧的全局压缩是：

\[
\boxed{
\text{MAIN THEOREM}
\quad\Longleftarrow\quad
\text{UNIVERSAL H1: critical-shore fixed-outside fiber connectivity}.
}
\]

也就是说，**如果 B+ 的 quotient-legal deletion/common-completion theorem 与 nonboundary quotient-lift theorem 经最终审计成立，那么 H2/H3/H3′ 不再是独立缺口；vertex-contraction induction 把主问题压到 H1。**

当前不建议继续维持旧的数值置信区间。新结果一方面显著缩小了全局缺口，另一方面 genuine frozen descendants、TTS/PFDE/TGCE 反例证明静态直觉比之前更不可靠。比较稳妥的表述是：

\[
\boxed{
\text{项目仍倾向 TRUE，}
\text{但现在真正押注的是“祖先 slack service 必然存在”，而不是“frozen state 不存在”。}
}
\]

---

# B. 当前最重要的全局 reduction：MAIN THEOREM \(\Leftarrow\) H1

## B1. H1 — CRITICAL-SHORE FIBER CONNECTIVITY

取 true critical shore

\[
|\delta_G(A)|=2k+1,
\]

固定所有 \(E(G)\setminus E(G[A])\) physical edges 的方向 \(\sigma\)。定义

\[
\mathcal F(A,\sigma)
=
\{D:\ D\text{ globally }k\text{-arc-strong and compatible with }\sigma\}.
\]

H1 是：

\[
\boxed{
\mathcal F(A,\sigma)\neq\varnothing
\Longrightarrow
\mathcal F(A,\sigma)
\text{ 在 }E(G[A])\text{ 的 legal single-edge flips 下 connected.}
}
\]

这是目前唯一真正值得称为“主 theorem 的内部桥”的 statement。

## B2. B+ — QUOTIENT-LEGAL DELETION / COMMON COMPLETION

**LOCK-CANDIDATE / CROSS-MODEL ACCEPTED.**

令 \(e\in\delta(A)\)，\(D\) global legal，\(\bar D=\pi_A(D)\)。若 quotient flip

\[
(\bar D)^e
\]

仍 \(k\)-arc-strong，则保持除 \(E(G[A])\cup\{e\}\) 外所有 physical directions 不变时，存在 internal orientation \(F^0\) 使

\[
\boxed{
\sigma^0\cup F^0
\text{ 已经是 }G-e\text{ 的 }k\text{-arc-strong orientation.}
}
\]

于是 \(e\) 的两个方向都可加回同一个 \(F^0\)：

\[
\sigma^0\cup e^+\cup F^0,
\qquad
\sigma^0\cup e^-\cup F^0
\]

都 global legal。

proof 的核心 balance 是：删掉 \(e\) 后 critical boundary 有 \(2k\) 条边；current global legality 给一个方向至少 \(k\)，quotient-flipped legality 给另一个方向至少 \(k\)，故恰为 \((k,k)\)。随后 contraction outside 到 degree-\(2k\) balanced root，使用 nonnegative crossing-supermodular orientation min-max theorem 完成 root-balanced extension，再用 quotient legality + submodularity lift 回 mixed cuts。

这比旧 H2 更强，也直接给：

\[
\boxed{
\text{H3′ — critical contraction extension-closure.}
}
\]

## B3. NONBOUNDARY QUOTIENT FLIPS LIFT

**LOCK-CANDIDATE / CROSS-MODEL ACCEPTED.**

对 critical shore \(A\)，若 quotient 中翻转的 surviving physical edge不 incident 于 contracted vertex，且 quotient flip legal，则该 physical flip 在任意当前 global extension 中直接 legal。

blocker 若 crossing \(A\)，可与 \(A\) 或 \(A^c\) 的 directed-tight side uncross 成 respecting-\(A\) 的 quotient blocker，矛盾。

## B4. CONTRACTION INDUCTION

在 B2+B3+universal H1 下，对 \(|V(G)|\) induction：

1. 若 \(\lambda\ge2k+2\)，用 Ito baseline；
2. 若 \(\lambda=2k+1\)，取含至少两个 vertices 的 global mincut shore \(A\)；
3. \(G/A\) 满足 \(\lambda(G/A)\ge2k+1\)，且 vertex number 下降；
4. induction 在 quotient 中给 source-to-target legal physical path；
5. nonboundary step 由 B3 直接 lift；boundary step 由 B2 给 common completion，再用 H1 在 current fiber 内走到该 state 后 flip 指定 physical edge；
6. quotient 到达 target 后，用 H1 做最后一次 internal repair。

parallel labelled edges 在 contraction 中不合并 physical identity；不需要 child-freezing。

因此当前全局 architecture 可以写成：

\[
\boxed{
\text{B+ deletion/common completion}
+
\text{nonboundary quotient lift}
+
\text{universal H1}
\Longrightarrow
\text{MAIN THEOREM}.
}
\]

**这使旧 H3 exact-signature quotient connectivity 成为历史中间层，而不是当前必要 hypothesis。**

---

# C. H1 的 exact residual formulation

## C1. Fixed-boundary residualization — LOCKED

令

\[
B=V-A,
\qquad
H=G[A],
\]

固定 outside digraph \(K_\sigma\)。对 \(\varnothing\neq Y\subsetneq A\) 定义

\[
\boxed{
q(Y)=\min_{Z\subseteq B}d^+_{K_\sigma}(Y\cup Z),
\qquad
p(Y)=k-q(Y).
}
\]

则 fiber 内部 orientations 精确为

\[
\boxed{
\mathcal O(H,p)
=
\{F:\ d_F^+(Y)\ge p(Y)\ \forall\varnothing\neq Y\subsetneq A\},
}
\]

再加 purely-fixed endpoint feasibility。mixed cuts 没有遗漏。

定义 terminal cut function

\[
\Phi_F(Y)
=
d_F^+(Y)+q(Y)
=
\min_{Z\subseteq B}d^+_{F\cup\sigma}(Y\cup Z).
\]

则 \(q\) submodular，\(\Phi_F\) submodular；residual tight trace 等价于 full tight minimizer lift。

## C2. Critical residual symmetric slack — LOCKED / STABLE

定义

\[
\boxed{
\mu(Y)
=
|\delta_H(Y)|-p(Y)-p(A-Y).
}
\]

true critical shore 中：

\[
\boxed{
\mu(Y)\ge1
\qquad
\forall\varnothing\neq Y\subsetneq A.
}
\]

且

\[
\boxed{
\mu(Y)=1
\Longrightarrow
Y\mid(A-Y)
\text{ 是某个 global }(2k+1)\text{-mincut 的 trace.}
}
\]

所以 \(\mu=1\) 是 permanent critical phase layer；\(\mu\ge2\) 并不意味着 connectivity 或可局部释放。

在 initial true-critical terminal system 中另有 useful budget：

\[
q(Y)+q(A-Y)\le k,
\]

故 initial \(p(Y)\ge0\)。这一 nonnegativity **不在 additional internal fixing 下保持**。

## C3. Descendant closure

固定 oriented internal set \(J\)，remaining graph \(K=H-J\)。定义

\[
\boxed{
p_J(X)=p(X)-d_J^+(X).
}
\]

则 descendant tightness 与 full internal orientation 的 original residual tightness一致，并且

\[
\boxed{
\mu_J(X)=\mu(X).
}
\]

这是非常重要的 hereditary identity。

但 \(p_J\) 可以为负；把负值截成 0 会破坏 strict \(\mu\)-invariance。因此 initial nonnegative Frank partition/co-partition proof 不能未经新 theorem 递归使用。

---

# D. 已被反例永久杀死的中间 architecture

本节 supersedes 2026-09-30 的若干 optimistic bridge。

## D1. TERMINAL TWO-SLACK CONNECTIVITY (TTS) — FALSE / DEAD

存在 arbitrary-size genuine terminal projection，满足

\[
\mu(Y)=2
\]

对所有 proper nonempty \(Y\)，但 legal internal single-edge flip graph 是 edgeless，且 feasible states 多于一个。

failure mechanism 是 **COMPLEMENT-TIGHT COVER**：在某个 state 中所有 \(A-\{v\}\) 同时 tight，每条 current arc \(u\to v\) 被 \(A-\{v\}\) 阻塞；complement 上的两单位 slack 对该方向 flip 无帮助。

因此：

\[
\boxed{
\mu\ge2\not\Rightarrow\text{connectivity}.
}
\]

ITS / inert-two-slack variants同样不能作为 black box。

## D2. Binary phase chamber connectivity — FALSE / DEAD

\(\mu=1\) traces 形成 rooted laminar critical family，phase

\[
\phi_F(Y)=d_F^+(Y)-p(Y)\in\{0,1\}
\]

是正确 coarse projection；一条 physical edge crossing 多个 nested critical cuts会 toggle 对应 laminar-tree path。

但固定 phase 不固定 interface physical labels。phase chamber 内不能翻 critical interface edge，因此 \(F|_I\) 是 chamber-path invariant。存在 arbitrary-size genuine family使同一 phase chamber disconnected。

所以：

\[
\boxed{
\text{binary phases are bookkeeping, not sufficient state.}
}
\]

## D3. Broad FDE / signed-cover exclusion / PFDE / TGCE — FALSE / DEAD

后续 genuine constructions 证明：

- multi-state、bi-extendable、totally frozen true-critical descendants真实存在；
- pure signed-cover exclusion FALSE；
- PFDE（固定所有 \(\mu=1\) critical interfaces 后 frozen descendant 不存在）FALSE；
- TGCE-2（two-blocker nonempty-gap cycle exclusion）FALSE；
- 甚至可以有 arbitrary-\(k\) terminal-realizable family，所有 proper nonempty \(U\subset A\) 都满足 \(\mu(U)\ge2\)，而 descendant 恰有两个 antipodal states，remaining flip graph edgeless。

所以 **H1 不可能通过“证明 frozen descendant 根本不存在”来完成。**

## D4. Static positive-row Farkas contradiction — FALSE / DEAD

blocker circulation可以给

\[
M_F r=0
\]

而 every column individually has a positive blocking entry。bi-extendability 也不杀这种 circulation。

正确的 Farkas 对象必须编码 **ancestor service closure**，而不是单一 frozen state 的静态 blocker matrix。

## D5. Initial RCD 保留；arbitrary-J extension 已被反驳

> 2026-10-02 状态更正：用户确认 2026-10-01 15:09 更新已给出 genuine \(k=2,\lambda=5\) counterexample。任意固定 \(J\) 的加强 RCD 为 SUPERSEDED / FALSE；原 witness 待归档，见 DS11。

initial true-critical terminal residual system 中，模型 B 得到更强的 deletion theorem：每一条 variable edge 都可删除一次而仍 \(p\)-orientable；因此 initial RCD 成立且不需要“两个方向各自 feasible”的 hypothesis。

但 fixing 一条 internal edge后 raw demand \(p_J\) 可能 negative。一般 signed crossing-supermodular orientation feasibility 的 dual obstruction不再只由 partition/co-partition描述，而可能需要 tree-composition / regular-family certificate。

因此：

\[
\boxed{
\text{ARBITRARY-J RCD: SUPERSEDED / FALSE.}
}
\]

该 arbitrary-\(J\) 加强命题已被反驳，不再作为待证明的 H1 路线；initial unfixed terminal deletion theorem 保留。

---

# E. 如果 H1 失败：最小 obstruction 已被压到一条 long polytope edge

## E1. Minimum component-separating descendant

**LOCK-CANDIDATE / CROSS-MODEL ACCEPTED.**

若 H1 false，从 original fiber 的不同 connected components 中取 states，固定尽可能多 internal physical edges，得到 variable-edge 数最小的 component-separating descendant。则：

1. every remaining physical edge is bi-extendable；
2. 对每条 remaining edge，其两个方向的 orientation classes落在两个不同 original components；
3. descendant 恰有两个 feasible states

\[
\boxed{S_J=\{R,\bar R\},}
\]

且 \(\bar R\) 反转 \(R\) 的每一条 remaining physical edge；
4. no remaining edge is legal at either endpoint。

因此最小 H1 obstruction 不是一个大 disconnected graph，而是一个 **two-state antipodal frozen descendant**。

## E2. Reversal polytope

以 \(R\) 为 reference orientation，对 remaining edge \(e\) 用 \(x_e\in[0,1]\) 表示 reversal。feasibility 可写成

\[
P_R
=
\left\{
x\in[0,1]^{E(K)}:
 x(\delta_R^+(X))-x(\delta_R^-(X))\le s_R^J(X)
\ \forall X
\right\}.
\]

模型 C 使用 Edmonds–Giles box-integrality，把“只有两个 integral points \(\mathbf0,\mathbf1\)”升级为

\[
\boxed{
P_R=\operatorname{conv}\{\mathbf0,\mathbf1\}
=\{t\mathbf1:0\le t\le1\}.
}
\]

固定 outside + J coordinates 是 full orientation polytope 的 box-face；因此该 segment 是 full polytope 的一条 edge。

## E3. LONG-EDGE SUPPORT THEOREM

**LOCK-CANDIDATE，外部 Lovász/Schrijver theorem 需最终核页码/适用域。**

Schrijver Chapter 61 报告的 Lovász adjacency theorem 给：两个 \(k\)-arc-connected orientations 在 orientation polytope 中 adjacent，当且仅当它们的 difference 是

- one directed circuit；或
- a collection of vertex-disjoint directed paths。

因此 minimum component-separating descendant 的 remaining support \(K\) 必为

\[
\boxed{
\text{one directed physical circuit}
\quad\text{or}\quad
\text{vertex-disjoint directed physical paths}.
}
\]

这把旧的“forest or one cycle”进一步 sharpen；branching tree、两个 cycle、paths 共享 vertex 都被排除。

## E4. Common-tight dangerous family

在 long edge midpoint \(x=\frac12\mathbf1\) 的 active cut equalities上，cut 在两个 antipodal endpoints 都 tight，且对应 normals \(n_X\) span \(\mathbf1^\perp\)。因此存在 positive dependence

\[
\boxed{
\sum_X\alpha_X n_X=0,
\qquad
\alpha_X>0.
}
\]

定义

\[
\boxed{
w(v)=\sum_{X\ni v}\alpha_X.}
\]

则 \(w\) 在每个 remaining \(K\)-component 上常数。

path support 上 common-tight normals 是 interval-boundary vectors；cycle support 上是 cyclic-interval-boundary vectors。这给下一层 service/token geometry 一个低复杂度 support。

---

# F. 当前真正的动态核心：ANCESTRAL SERVICE / BUFFER SERIALIZATION

static frozen descendants是真实的，因此要连接 \(R\) 与 \(\bar R\)，必须允许暂时“解冻”先前固定的 internal edges \(J\)。

## F1. Exact service vector

对 formerly-fixed arc

\[
g=u\to v\in J,
\]

定义 dangerous-cut membership vector \(\chi(v)=(1_{v\in X})_X\)，以及

\[
\boxed{
\partial(g)=\chi(v)-\chi(u).
}
\]

reverse \(g\) 对每个 dangerous cut 的 slack change 正是 \(\partial_X(g)\)。weighted projection 为

\[
\boxed{
\Delta_w(g)=w(v)-w(u)=\alpha\cdot\partial(g).
}
\]

\(\Delta_w>0\) 只是 aggregate slack injection；不保证 physical legality，也不保证所有 blockers 都被 service。

remaining \(K\)-edge在同一 \(w\)-component 内，故 weighted gradient 为 0；它们只负责 transport slack vector。

## F2. Telescoping token law

对 directed \(K\)-path

\[
v_0\to v_1\to\cdots\to v_m,
\]

顺序 reverse 前 \(t\) 条 remaining edges 的 cumulative service vector是

\[
\boxed{
\chi(v_t)-\chi(v_0).
}
\]

因此 path = slack transfer；directed cycle 的总向量和为 0，故 cycle = closed slack circulation，只需要 temporary buffer。

旧 E-cycle frozen family正是“one ancestral injection + zero-gradient cycle transport + restore ancestor”的 equality model。

## F3. Exact cutwise service margin

模型 A 定义

\[
\boxed{
\Lambda_R(a,b)
=
\min\{s_R(X):a\in X,\ b\notin X\}.
}
\]

并定义 tight-set preorder

\[
\boxed{
a\preceq_R b
\iff
\Lambda_R(a,b)\ge1.
}
\]

对 fixed edge \(g=a\to b\)，temporary reverse \(g\) legal iff \(a\preceq_R b\)。

若 service edge \(g=u\to v_0\)，而 long support 是 directed path/cycle \(v_0\to v_1\to\cdots\)，则显式 sequence

\[
g,e_1,e_2,\ldots,e_m,g
\]

能全程 legal 并恢复 \(g\) 的 exact one-buffer criterion 是

\[
\boxed{
u\preceq_R v_t\quad\forall t,}
\]

等价于

\[
\boxed{
\min_t\Lambda_R(u,v_t)\ge1.
}
\]

这一次性覆盖一条 remaining edge 的 **所有 blockers**，不是 one-blocker heuristic。

模型 A 进一步给出 directed ancestral \(J\)-chain 与 general multi-buffer packet 的 exact prefix / transport / restoration inequalities。结论是：

\[
\boxed{
\text{一旦 service chain / packet 存在，atomic physical serialization 已经有 exact theorem.}
}
\]

## F4. Vector-labelled ancestral service graph

模型 E 的更全局 formulation：contract undirected \(K\)-components；每条 \(J\)-edge成为 component 间的 directed service arc，保留 full vector label \(\partial(g)\) 与 scalar gradient \(\Delta_w(g)\)。gradient 0 的 loops不能丢，因为 full vector可非零。

定义 physical service width \(\beta_{phys}\)：使 target path/cycle能够被合法序列化并恢复 auxiliary edges所需的最小 simultaneous/ordered ancestral buffer complexity。不要假设 \(\beta=1\)。

## F5. Fractional service failure 的 exact dual

对 projected dangerous system，若连 fractional service都不存在，则 Farkas 给 weighted siphon \(y\ge0\)。原需求向量 \(q\) 更名为 \(b_{\rm req}\)，与 terminal residual \(q(Y)\) 不同；其完整定义仍待原输出回填：

\[
A_K^Ty=0,
\qquad
A_J^Ty\le0,
\qquad
y\cdot b_{\rm req}>0.
\]

vertex-potential 语言中：\(\phi_y\) 在每个 \(K\)-component 上常数，每个 ancestral service arc weakly downhill，而 required buffer有 positive charge。

这产生 closed service regions / weighted closed blocker family，正是 Szigeti-style dangerous-set regularization 应该攻击的对象。

但目前只有：

\[
\text{fractional no-service}
\Longrightarrow
\text{weighted siphon}.
\]

还没有：

\[
\text{physical/integral temporal no-service}
\Longrightarrow
\text{weighted siphon}.
\]

---

# G. 2026-10-01 唯一主 OPEN BRIDGE

当前最值得统一的 statement 可以写成两层。

## G1. ASCE — ANCESTRAL SERVICE-CHAIN EXISTENCE

**OPEN.**

对每个 minimum component-separating long-edge descendant（support 为 directed path(s) 或 one directed circuit），证明 previously-fixed internal edges \(J\) 中存在一个 finite preorder-compatible service chain / multi-buffer packet，满足 A 模型的 exact cutwise legality条件。

若 ASCE 成立，则 long edge可显式 atomic serialize，矛盾于 component separation；故 H1 成立，继而主 theorem 成立。

## G2. SPECIAL SIPHON COMPRESSION / ANCESTRAL SERVICE DICHOTOMY

更有希望的反证形式：

\[
\boxed{
\text{physical ancestral service 不存在}
\Longrightarrow
\text{regular weighted siphon certificate}.
}
\]

然后把 siphon support uncross / regularize 成：

1. forbidden global tight partition；或
2. forbidden global tight co-partition；或
3. terminal regular family；或
4. proper critical contraction。

其中 (1)(2) 应由 true-critical partition exclusion 杀死，(4) 应由 minimality/induction 杀死；关键是把 terminal regular case也压到这些结局之一，或从中直接抽出 admissible service edge。

这与 splitting-off 文献里

\[
\text{all local moves blocked}
\Rightarrow
\text{dangerous-set / admissible-pair obstruction}
\]

的 proof pattern高度一致，但不能直接套用 splitting theorem。

## G3. SUPERSEDED / FALSE：ARBITRARY-J STRENGTHENED RCD

历史上曾提出以下加强命题：对 arbitrary fixed internal signature \(J\)，若 remaining edge \(e\) 的两个方向各有 feasible completions，则 \(H_J-e\) 有 common completion。用户补充确认该命题已被 genuine \(k=2,\lambda=5\) counterexample 反驳；当前状态为 SUPERSEDED / FALSE（原 witness 待归档，见 DS11）。

旧路线原拟用该 strengthened RCD 对 variable edge 数归纳以证明 H1；反例出现后不能继续使用此归纳前提。

旧分析将困难定位为 \(p_J\) signed 后的 general Frank tree-composition / regular-family obstruction；此分析仅保留作历史背景，不能把已假命题恢复为 OPEN。

**历史研究设想（arbitrary-J RCD 目标现已停用）：这条 RCD route 与 E 的 weighted-siphon route 很可能不是两条完全独立的困难。两者都在问：additional fixing 以后，能否把 general signed / temporal obstruction 压成一个可 contraction 的 regular cut family。后续应尝试建立二者之间的 dictionary，而不是平行重复证明。**

---

# H. 六条工作线的最新状态

## H1. 模型 A｜RELATIVE-FIBER / ANCESTRAL-BUFFER

- residualization / \(\mu\) structure：稳定；
- phase-only / TS / PFDE / TGCE static routes：已死亡；
- exact buffer serialization：conditional theorem 已形成；
- **latest OPEN：ASCE / usable ancestral service packet existence.**

## H2. 模型 B｜INTERFACE-EXIT / RCD

- B+ quotient-legal deletion/common completion：LOCK-CANDIDATE；
- H3′：由 B+ 直接推出；
- universal H1 \(\Rightarrow\) main theorem：EXACT REDUCTION；
- initial terminal RCD：强正结果；
- **SUPERSEDED / FALSE：arbitrary-J partial-internal-signature RCD。** signed regular-family 的其他独立问题须另列假设，不能沿用该已假命题。

## H3. 模型 C｜RELATIVE-ITO / POLYTOPE-LONG-EDGE

- naive relative Ito reachability：FALSE；
- TTS / ITS：FALSE；
- descendant BTC / two-state antipodal reduction：LOCK-CANDIDATE；
- reversal polytope long-edge reduction：LOCK-CANDIDATE；
- support sharpened为 directed circuit / vertex-disjoint directed paths：LOCK-CANDIDATE；
- 当前角色主要是给 service theorem提供 path/circuit support geometry。

## H4. 模型 D｜TREE-GLUING

- H1+H2 不足的早期 H3 分析已被后续 supersede；
- H3′ 有一条 Frank-duality proof；
- B+ 又给更强、概念更短的 deletion proof；
- 当前 D 的 gluing 缺口基本消失，global induction只剩 H1。

## H5. 模型 E｜ARCHITECTURE-AUDIT / ANCESTRAL-SERVICE

- 成功杀掉多个静态 architecture；
- exact service vector、service graph、token conservation、service width formalization稳定；
- fractional no-service \(\Rightarrow\) weighted siphon已有 Farkas dual；
- **latest OPEN：integral temporal no-service \(\Rightarrow\) siphon，以及 siphon regularization.**

## H6. 文献搜索｜Round 1–3

没有发现直接解决主 theorem 的现成结果；但搜索把最有价值的外部 mechanism 明显集中到三条：

1. **serial / sequential exchange**：macro feasible exchange \(\to\) legal atomic prefixes；
2. **splitting-off / admissible edge / dangerous set**：all local operations blocked \(\to\) regular obstruction；
3. **submodular-flow polyhedral adjacency / augmentation**：long edge、residual graph、minimum-cost orientations与 tight cut geometry。

这三条恰好对应当前 ASCE / siphon compression 的三个面，不再是泛泛“相关文献”。

---

# I. 更新后的 FALSE / DEAD / DO-NOT-REVIVE ledger

除旧档 DEAD 列表外，新增永久禁止：

- TTS: \(\mu\ge2\Rightarrow\) fiber connected；
- ITS / inert-two-slack variants；
- binary phase chamber connectivity；
- exact phase vector作为完整 state；
- broad FDE；
- protected FDE / PFDE；
- TGCE / TGCE-2 gap-cycle exclusion；
- critical signed-cover exclusion；
- bi-extendability \(\Rightarrow\) frozen sign cycle contradiction；
- static Farkas positive-row contradiction；
- “all blockers can be unsigned laminarized”；正确只能先到 cross-free / signed laminar support；
- universal one-buffer / one-auxiliary repair；
- \(\Delta_w>0\Rightarrow\) usable service；
- ordinary M-convex / basis exchange \(\Rightarrow\) physical single-edge serialization；
- “initial residual deletion theorem在 fixing 后自动递归”；negative \(p_J\) / tree-composition gap禁止这个跳步；
- independent H3 exact-signature quotient connectivity作为主 theorem 必需桥（B+ + H1 contraction route 已 supersede）。

仍保留旧档全部 DEAD，包括 target-monotone descent、fixed-path universal serialization、one-interval/width1、static wall/phase cage、generic blocker monotonicity、macro reversal=atomic 等。

---

# J. 2026-10-01 最高价值 OPEN QUESTIONS

## J1. Proof-audit B+ 与 H1 \(\Rightarrow\) main reduction

这是当前最先值得人工逐行复核的链。重点核：

- Root-Balanced Extension Lemma 对所用 Frank theorem 的 exact hypotheses；
- nonnegative crossing-\(H\)-supermodular demand的 partition/co-partition sufficiency；
- lift \(K\to G-e\) 的 respecting/mixed cut exhaustive split；
- contraction induction在 \(\lambda(G/A)>2k+1\) 时调用 baseline/induction的边界。

若此链完全通过，主问题真正等价地集中到 universal H1。

## J2. Audit Lovász adjacency theorem 的 exact scope

需要把 Schrijver Chapter 61 的 theorem number / exact formulation核定：

- multigraph 是否无条件允许；
- polytope coordinate与本项目 reversal-vector formulation是否完全一致；
- fixed outside signature face上的 edge能否无缝用 full-polytope adjacency theorem。

## J3. ASCE / physical service packet existence

这是当前动态核心。

## J4. Special Siphon Compression Lemma

把 temporal integral failure压成 weighted siphon，再 regularize成 partition/co-partition/critical contraction。

## J5. SUPERSEDED / FALSE：arbitrary-J partial-internal-signature RCD

旧 H1 induction 候选已被反例否定，见 DS11 与本历史层 G3。Frank–Király *Tree-compositions and Orientations* 可作为 signed obstruction 背景保留；不能继续把 arbitrary-J RCD 列为当前待证目标。

## J6. 历史 dictionary 设想：partial RCD obstruction ↔ ancestral service siphon

这是旧路线的研究设想；arbitrary-J RCD 已为 FALSE，不得默认其与当前 temporal obstruction 等价。重新讨论时须另写准确命题与适用范围。

---

# K. 文献整合：当前最直接的 mechanism map

## K1. Direct orientation / reversal baseline

必须继续作为基线保留：

- Ito–Iwamasa–Kakimura–Kamiyama–Kobayashi–Maezawa–Nozaki–Okamoto–Ozeki, *Monotone Edge Flips to an Orientation of Maximum Edge-Connectivity à la Nash-Williams*.
- András Frank, *A note on k-strongly connected orientations of an undirected graph*.
- Blind–Knauer–Valicov, *Enumerating k-Arc-Connected Orientations*.
- Frank–Király–Király, *On the Orientation of Graphs and Hypergraphs*.
- Mühlenthaler–Peyrille–Szigeti, *Directed Hypergraph Connectivity Augmentation by Hyperarc Reorientations*.
- Hoppenot–Szigeti, *On Reversing Arcs to Improve Arc-Connectivity*.
- Bang-Jensen–Hörsch–Kriesell, *Complexity of (arc)-connectivity problems involving arc-reversals or deorientations*.
- Aichholzer–Cardinal–Huynh–Knauer–Mütze–Steiner–Vogtenhuber, *Flip Distances Between Graph Orientations*.

## K2. Reconfiguration / serial exchange

当前最值得挖 theorem/proof，而不是只做类比：

- Kobayashi–Mahara–Schwarcz, *Reconfiguration of the Union of Arborescences*.
- Bérczi–Mátravölgyi–Schwarcz, *Reconfiguration of Basis Pairs in Regular Matroids*.
- Gabow, *Decomposing symmetric exchanges in matroid bases*.
- Farber–Richter–Shank, *Edge-disjoint spanning trees: A connectedness theorem*.
- Kotlar–Ziv, *On Serial Symmetric Exchanges of Matroid Bases*.
- Kotlar, *On Circuits and Serial Symmetric Basis-Exchange in Matroids*.
- Kotlar–Roda–Ziv, *On Sequential Basis Exchange in Matroids*.
- McGuinness, *Serial Exchanges in Matroids*.

## K3. Splitting-off / dangerous-set / admissibility

当前与 E 的 siphon compression最贴：

- Gabow–Jordán, *Bipartition Constrained Edge-Splitting in Directed Graphs*.
- Szigeti, *On admissible edges*.
- Bernáth–Király, *A Unifying Approach to Splitting-Off*.
- Bernáth–Király–Végh, *Special skew-supermodular functions and a generalization of Mader's splitting-off theorem*.
- Frank, *Submodular Functions in Graph Theory*.
- Frank, *Augmenting Graphs to Meet Edge-Connectivity Requirements*.
- Mader directed splitting/minimal-connectivity papers.

## K4. Submodular flow / orientation polytope

当前与 long-edge + RCD 最贴：

- Edmonds–Giles submodular-flow integrality / orientation polytope framework.
- Frank, *Finding feasible vectors of Edmonds–Giles polyhedra*.
- Frank, *Orientations of Graphs and Submodular Flows*.
- Cunningham–Frank, *A Primal-Dual Algorithm for Submodular Flows*.
- Gabow, *Centroids, Representations, and Submodular Flows*.
- Iwata–Kobayashi, *An Algorithm for Minimum Cost Arc-Connectivity Orientations*.
- Schrijver, Chapter 61 orientation polytope / reported Lovász adjacency theorem.

## K5. Mixed / fixed-boundary completion

- Nash-Williams, *Strongly Connected Mixed Graphs and Connected Detachments of Graphs*.
- Chung–Garey–Tarjan, *Strongly Connected Orientations of Mixed Multigraphs*.
- Boesch–Tindell, *Robbins’s Theorem for Mixed Multigraphs*.
- Arkin–Hassin, *A note on orientations of mixed graphs*.
- Frank–Csaba Király, *Tree-compositions and Orientations*.

---

# L. 文献总 ledger 使用说明

下面附录把 **独立文献搜索 Round 1–3 的原始条目全文**纳入主档案，并另保留 packet 中已经进入项目地图但未必在三轮里重复列出的文献。这样后续模型可以先全文检索主档案，避免重复发现同一篇 paper。

注意：

- “FULL TEXT FOUND”不是“proof read”；
- “ABSTRACT ONLY / SECONDARY CITATION ONLY”必须继续保留；
- 原始出处未确定的 Lovász polyhedral-adjacency theorem仍标为 source audit item；
- 文献 theorem不得直接替代 physical single-edge adjacency proof。

## L1. Packet / seed literature（补充索引）

### Direct orientation / reorientation
- Ito et al., *Monotone Edge Flips to an Orientation of Maximum Edge-Connectivity à la Nash-Williams*.
- Mühlenthaler–Peyrille–Szigeti, *Directed Hypergraph Connectivity Augmentation by Hyperarc Reorientations*.
- Frank, *A Note on \(k\)-Strongly Connected Orientations of an Undirected Graph*.
- Blind–Knauer–Valicov, *Enumerating \(k\)-Arc-Connected Orientations*.
- Frank–Király–Király, *On the Orientation of Graphs and Hypergraphs*.
- Hoppenot–Szigeti, *On Reversing Arcs to Improve Arc-Connectivity*.
- Fukuda–Prodon–Sakuma, shelling / strong-orientation line.
- Bang-Jensen–Hörsch–Kriesell, *Complexity of (arc)-connectivity problems involving arc-reversals or deorientations*.
- Aichholzer et al., *Flip Distances Between Graph Orientations*.

### Reconfiguration / exchange
- Kobayashi–Mahara–Schwarcz, *Reconfiguration of the Union of Arborescences*.
- Bérczi–Mátravölgyi–Schwarcz, *Reconfiguration of Basis Pairs in Regular Matroids*.
- Ito–Iwamasa–Kobayashi–Nakahata–Otachi–Wasa, *Reconfiguring (non-spanning) Arborescences*.

### Splitting-off / dynamic obstruction
- Mader splitting / minimal-connectivity papers.
- Frank, *On a Theorem of Mader*.
- Szigeti, *Edge-Splittings Preserving Local Edge-Connectivity of Graphs*.
- Szigeti, *On Partition Constrained Splitting Off*.
- Szigeti, *On admissible edges*.
- Lau–Yung, *Efficient Edge Splitting-Off Algorithms Maintaining All-Pairs Edge-Connectivities*.
- Végh, *Connectivity Augmentation Algorithms*.
- Gabow–Jordán, *Bipartition Constrained Edge-Splitting in Directed Graphs*.
- Bernáth–Király, *A Unifying Approach to Splitting-Off*.

### Minimum-cut / carcass structure
- Dinitz–Vainshtein, odd connectivity carcass line.
- Baswana–Pandey, modern connectivity-carcass exposition.
- Dinitz–Nutov, minimum/minimum+1 two-level cactus line.
- Dinitz–Karzanov–Lomonosov, classical minimum-cut structure.
- Picard–Queyranne, *On the Structure of All Minimum Cuts in a Network and Applications*.
- Gusfield–Naor, *Extracting Maximal Information about Sets of Minimum Cuts*.

### Submodular / discrete convexity
- Edmonds–Giles submodular-flow work.
- Frank, *Connections in Combinatorial Optimization*.
- Frank–Murota, *Discrete Decreasing Minimization, Part I: Base-polyhedra with Applications in Network Optimization* and related M-convex work.
- Zimmermann, submodular-flow work.
- Bouchet–Cunningham, *Delta-Matroids, Jump Systems, and Bisubmodular Polyhedra*.
- Lovász, *The Membership Problem in Jump Systems*.



# M. 文献搜索 Round 1 原始 ledger（完整纳入）

第一轮完成。我把你列出的已知论文全部当作 **citation seeds**，没有计入下面候选数。下面共整理出 **58 篇新候选**；其中我认为真正值得优先追原始 citation graph 的，是 A 类和 C 类中的 Gabow–Jordán / Pretzel / Mader / Nash-Williams 几条线。

这里的 **FULL TEXT FOUND** 只表示我已经定位到可读原文、作者稿或开放版本，**不表示这一轮重新精读了证明**。

# A. VERY CLOSE

**A1. Ahmad Abdi, Gérard Cornuéjols, Giacomo Zambelli — “Arc Connectivity and Submodular Flows in Digraphs” (2024), Combinatorica 44, 1069–1090.**  
DOI `10.1007/s00493-024-00108-0`; arXiv `2310.19472`. 文章直接定义 **\(k\)-arc-connected flip**：选一组 arcs 同时 reversal 后得到 \(k\)-arc-connected digraph。虽然 move 不是 single-edge，但这是我找到的现代文献里概念距离你的问题最近的之一，而且直接接 submodular-flow machinery。**Chain:** Frank/submodular flow → Ito edge flips。**FULL TEXT FOUND.** 

**A2. John Donald, John Elwin — “On the Structure of the Strong Orientations of a Graph” (1993), SIAM J. Discrete Math. 6, 30–43.**  
DOI `10.1137/0406003`. 它真的建立了一个以 strong orientations 为顶点的 transformation digraph；允许的 elementary transformation 是 directed cycle reversal 或特定 directed path reversal，并证明整个状态空间 strongly connected。与 single-edge flip 不同，但它的 **minimal difference set (MDS)** 很值得追，看是否有后续把 macro move 细化。**Chain:** Frank strong orientation/path reversal → Aichholzer flip-distance。**ABSTRACT ONLY.** 

**A3. C. St. J. A. Nash-Williams — “Strongly Connected Mixed Graphs and Connected Detachments of Graphs” (1995), J. Combin. Math. Combin. Comput. 19, 33–47.**  
无 DOI 核实；有期刊 PDF。研究已经固定一部分 arcs 的 mixed graph，询问还能否继续 orientation 一些 undirected edges，同时保持 strong connectivity 并满足 prescribed indegrees。非常适合把“已经 flip / 尚未 flip 的边”解释成 partial orientation。**Chain:** Frank mixed orientations / FKK orientation → Nash-Williams detachment。**FULL TEXT FOUND.** 

**A4. Fan R. K. Chung, Michael R. Garey, Robert E. Tarjan — “Strongly Connected Orientations of Mixed Multigraphs” (1985), Networks 15, 477–484.**  
DOI `10.1002/net.3230150409`. 研究 mixed **multigraph** 中剩余 undirected edges 如何定向而 preserve reachability / strong connectivity；冻结一批 edge orientations 后的 completion problem 与 flip path 的 intermediate completion 很接近。**Chain:** Boesch–Tindell → Frank/FKK mixed orientation。**ABSTRACT ONLY.** 

**A5. Frank Boesch, Ralph Tindell — “Robbins’s Theorem for Mixed Multigraphs” (1980), American Mathematical Monthly 87, 716–719.**  
DOI `10.1080/00029890.1980.11995131`. 是 Chung–Garey–Tarjan 明确指出的 predecessor；已经在 1980 年研究 partial orientation 何时能完成为 strong orientation。可能是最值得追的早期“固定一部分方向”语言源头之一。**Chain:** Robbins → Boesch–Tindell → Chung–Garey–Tarjan → FKK。**ABSTRACT ONLY.** 

**A6. András Frank, András Gyárfás — “How to Orient the Edges of a Graph?” (1978; Keszthely 1976), Colloq. Math. Soc. János Bolyai 18, 353–364.**  
无 DOI；Rényi 有原文 PDF。它把 prescribed degree bounds、strong connectivity、rooted directed tree 放在同一个 orientation framework 中；尤其值得注意的是原文的 constructive manipulations 包括 **directed path reversals**。**Chain:** Frank 1982 → Frank degree-constrained/submodular orientation。**FULL TEXT FOUND.** 

**A7. Harold N. Gabow, Tibor Jordán — “Bipartition Constrained Edge-Splitting in Directed Graphs” (2001), Discrete Applied Mathematics 115, 49–62.**  
DOI `10.1016/S0166-218X(01)00214-1`. 这一轮最值得标红：定义 local split pair 为 **admissible** 当且仅当操作后仍保持 \(k\)-edge-connectivity，并证明在 bipartition constraint 下只要  
\[
\rho(s)\ge 2k+1
\]
就存在 admissible pair。不是 reversal，但恰好出现 **\(2k+1\) + connectivity-preserving local move + obstruction/admissibility**。**Chain:** Mader → Szigeti splitting-off。**FULL TEXT FOUND.** 

**A8. Bill Jackson — “Some Remarks on Arc-connectivity, Vertex Splitting, and Orientation in Graphs and Digraphs” (1988), J. Graph Theory 12, 429–436.**  
DOI `10.1002/jgt.3190120314`. 把 arc-connectivity-preserving splitting 和 mixed-graph orientation 放在同一篇文章里，明确使用 Lovász/Frank 的技术。可能是 Mader local operation 与 orientation 问题之间最早的桥梁之一。**Chain:** Lovász/Mader → Frank → Szigeti splitting-off。**ABSTRACT ONLY.** 

**A9. András Frank, Zoltán Király — “Graph Orientations with Edge-connection and Parity Constraints” (2002), Combinatorica 22, 47–70.**  
DOI `10.1007/s004930200003`. 同时 imposing connectivity 与 parity；在你的临界值从 \(2k+2\) 降到奇数 \(2k+1\) 时，这类 parity obstruction 很可疑。应重点追它引用的更老 odd-cut/orientation 文献，而不是重新读本文。**Chain:** FKK / Frank submodular orientations → odd-cut line。**ABSTRACT ONLY.** 

**A10. András Frank, Csaba Király — “Tree-compositions and Orientations” (2013), Operations Research Letters 41, 336–342.**  
DOI `10.1016/j.orl.2013.03.009`. Tree-composition 被明确设计来描述 **mixed graph 无法得到 \(k\)-edge-connected orientation 的 obstacles**。如果 flip 被 blocker 卡住后可编码成 partial/mixed orientation，这是一条很自然的 obstruction language。**Chain:** FKK / Frank submodular orientation。**FULL TEXT FOUND.** 

**A11. Ahmad Abdi, Gérard Cornuéjols, Siyue Liu, Olha Silina — “Strongly Connected Orientations and Integer Lattices” (2025), IPCO 2025, LNCS 15620, 1–14.**  
DOI `10.1007/978-3-031-93112-3_1`; arXiv `2410.13665`. 直接考虑所有“reversal 后变成 strongly connected”的 arc subsets 所形成的 polytope/lattice；尤其研究 minimum dicut tight faces。对你的 tight-cut blocker system 很近。**Chain:** Abdi–Cornuéjols–Zambelli → submodular flips / dijoins。**FULL TEXT FOUND.** 

**A12. Siyue Liu, Olha Silina — “Lattice Structure and Efficient Basis Construction for Strongly Connected Orientations” (2026), LNCS 16588, 204–219 / arXiv.**  
arXiv `2603.17424`. 研究一族 cuts 上都 **tight** 的 strongly connected orientations，并建立 integral basis；这种“同时锁死若干 tight shores 后还剩多少 orientation freedom”的视角与 blocker core 很接近。**Chain:** A11。**FULL TEXT FOUND.** 

**A13. Florian Hörsch, Zoltán Szigeti — “Connectivity of Orientations of 3-edge-connected Graphs” (2021), European J. Combin. 94, 103292.**  
DOI `10.1016/j.ejc.2020.103292`. 核心局部概念是 orientation 中的 **deletable arc**：删去仍 strong。虽然不是 reversible arc，但这是“某条 physical edge 在当前 orientation 中有多少 connectivity slack”的极近邻。**Chain:** Hoppenot–Szigeti / Bang-Jensen–Hörsch–Kriesell。**FULL TEXT FOUND.** 

**A14. Jørgen Bang-Jensen, Anders Yeo — “Making a Tournament \(k\)-arc-strong by Reversing or Deorienting Arcs” (2004), Discrete Applied Mathematics 136, 161–171.**  
DOI `10.1016/S0166-218X(03)00438-4`. 标题就包含 arc reversal 与 \(k\)-arc-strong，而且 tournament theorem 中恰出现 \(n\ge2k+1\)。底层对象不同，但“reversal + \(k\)-arc strong + \(2k+1\)”同时出现值得追 references/citers。**Chain:** Bang-Jensen arc-reversal literature。**FULL TEXT FOUND.** 

---

# B. STRUCTURALLY RELATED

**B1. Jørgen Bang-Jensen, András Frank, Bill Jackson — “Preserving and Increasing Local Edge-Connectivity in Mixed Graphs” (1995), SIAM J. Discrete Math. 8, 155–178.**  
DOI `10.1137/S0036142993226983`. Mixed graphs + connectivity-preserving splitting + augmentation；连接 orientation 与 Mader machinery 的主干之一。**Chain:** Mader/Frank splitting → Jackson 1988。**ABSTRACT ONLY.** 

**B2. Jørgen Bang-Jensen, Tibor Jordán — “Splitting Off Edges within a Specified Subset Preserving the Edge-Connectivity of the Graph” (2000), Journal of Algorithms 37, 326–343.**  
DOI `10.1006/jagm.2000.1119`. 加 side constraints 后寻找最长 admissible splitting sequence；是 Gabow–Jordán 那个 \(2k+1\) directed theorem 的直接邻域。**Chain:** Mader → constrained splitting → A7。**ABSTRACT ONLY.** 

**B3. Jørgen Bang-Jensen, Tibor Jordán — “Splitting Off Edges between Two Subsets Preserving the Edge-Connectivity of the Graph” (2004), Discrete Mathematics 276, 5–28.**  
DOI `10.1016/S0012-365X(03)00291-7`. 继续研究 constrained admissible pairs 与完整 splitting sequences；适合搜 blocker/dangerous-set terminology。**Chain:** B2 → A7。**FULL TEXT FOUND.** 

**B4. Attila Bernáth, Tamás Király — “A Unifying Approach to Splitting-Off” (2012), Combinatorica 32, 373–401.**  
DOI `10.1007/s00493-012-2548-8`. 明确研究 splitting-off algorithm **什么时候会 get stuck**，并以 symmetric skew-supermodular set functions 描述障碍。这个“所有局部 move 都被 blocker 阻止 ⇒ 特殊 global obstruction”模式很值得移植。**Chain:** Mader/Szigeti + Benczúr–Frank。**ABSTRACT ONLY.** 

**B5. Tibor Jordán, Zoltán Szigeti — “Detachments Preserving Local Edge-Connectivity of Graphs” (2003), SIAM J. Discrete Math. 17, 72–87.**  
DOI `10.1137/S0895480199363933`. 把 Mader splitting generalize 成指定 local-connectivity requirement 的 admissible detachment。**Chain:** Mader → Szigeti splitting。**FULL TEXT FOUND**（1999 BRICS version）. 

**B6. Alex R. Berg, Bill Jackson, Tibor Jordán — “Highly Edge-connected Detachments of Graphs and Digraphs” (2003), J. Graph Theory 43, 67–77.**  
DOI `10.1002/jgt.10104`. 将 Nash-Williams detachment theorem 推到 directed graph，高 arc-connectivity local surgery 的直接邻域。**Chain:** Nash-Williams/Mader/Szigeti。**ABSTRACT ONLY.** 

**B7. Balázs Fleiner — “Detachment of Vertices of Graphs Preserving Edge-Connectivity” (2004/05), SIAM J. Discrete Math. 18, 581–591.**  
DOI `10.1137/S0895480198341511`. 给出 \(k\)-feasible prescribed-degree detachment 的 iff 条件；另一种“哪些小局部修改仍保 connectivity”的精细 characterization。**Chain:** Mader → Nash-Williams → Szigeti。**ABSTRACT ONLY.** 

**B8. Takuro Fukunaga, Hiroshi Nagamochi — “Some Theorems on Detachments Preserving Local-Edge-Connectivity” (2006), Electronic Notes in Discrete Mathematics 24, 173–180.**  
DOI `10.1016/j.endm.2006.06.041`. 特别考虑把一个点 split 成指定小度数 pieces 而 preserve local connectivity；local move 粒度比一般 detachment 更细。**Chain:** Mader → Fleiner/Jordán–Szigeti。**ABSTRACT ONLY.** 

**B9. Satoru Iwata, Tibor Jordán — “Orientations and Detachments of Graphs with Prescribed Degrees and Connectivity” (2014), Discrete Optimization 12, 121–128.**  
DOI `10.1016/j.disopt.2014.02.003`. prescribed indegree orientation、\(k\) edge-disjoint arborescences 与 detachments 被直接连接起来。**Chain:** Kobayashi arborescence exchange + Mader/Szigeti。**FULL TEXT FOUND.** 

**B10. Wolfgang Mader — “Konstruktion aller \(n\)-fach kantenzusammenhängenden Digraphen” (1982), European J. Combin. 3, 63–67.**  
DOI `10.1016/S0195-6698(82)80009-7`. 这是 **directed** splitting theorem，不是你已列的 undirected reduction paper；通过删除入/出两 arc 再 splice，保持所有相关 local arc-connectivities。**Chain:** Mader reduction → Jackson → Gabow–Jordán。**FULL TEXT FOUND.** 

**B11. Wolfgang Mader — “Minimal \(n\)-fach zusammenhängende Digraphen” (1985), JCTB 38, 102–117.**  
DOI `10.1016/0095-8956(85)90076-0`. 研究 minimal \(n\)-connected digraph 中哪些 vertices/arcs 必然 tight；很适合“所有边都不可安全操作时结构必须怎样”的反向思路。**Chain:** Mader directed connectivity。**FULL TEXT FOUND.** 

**B12. András Frank — “On Connectivity Properties of Eulerian Digraphs” (1988), Annals of Discrete Mathematics 41, 179–194.**  
DOI `10.1016/S0167-5060(08)70459-X`. 给 Lovász/Mader Eulerian splitting 的 directed counterparts；如果 orientation disagreement 被编码成 Eulerian difference digraph，这条线可能突然变近。**Chain:** Lovász → Mader → Frank splitting.**FULL TEXT FOUND.** 

**B13. András Frank, Tamás Király — “Combined Connectivity Augmentation and Orientation Problems” (2003), Discrete Applied Mathematics 131, 401–419.**  
DOI `10.1016/S0166-218X(02)00460-2`. 明确把 orientation、augmentation、supermodular polyhedra 和 splitting-off 拼在一起。**Chain:** Frank submodular + Mader.**FULL TEXT FOUND.** 

**B14. András Frank, Tibor Jordán, Zoltán Szigeti — “An Orientation Theorem with Parity Conditions” (2001), Discrete Applied Mathematics 115, 37–47.**  
DOI `10.1016/S0166-218X(01)00213-X`. T-odd orientation 同时含 \(k\) edge-disjoint arborescences；又是一条 parity/connectivity bridge。**Chain:** Frank–Király parity + arborescence packing。**ABSTRACT ONLY.** 

**B15. András Frank, Éva Tardos — “An Application of Submodular Flows” (1989), Linear Algebra Appl. 114–115, 329–348.**  
DOI `10.1016/0024-3795(89)90469-2`. supermodular graph framework、\(k\) disjoint paths 与 branching coverings；可能是后来 orientation feasibility/exchange 的隐藏算法祖先。**Chain:** Edmonds–Giles / Zimmermann → Frank orientation.**FULL TEXT FOUND.** 

**B16. William H. Cunningham, András Frank — “A Primal-Dual Algorithm for Submodular Flows” (1985), Mathematics of Operations Research 10, 251–262.**  
DOI `10.1287/moor.10.2.251`. 算法的 elementary steps 是 auxiliary digraph + augmenting paths；值得查其 residual/exchange graph 是否给 orientation cut-feasibility 一个可解释的 local augmentation system。**Chain:** Edmonds–Giles / Zimmermann.**FULL TEXT FOUND.** 

**B17. András Frank, Éva Tardos — “Matroids from Crossing Families” (1984), Colloq. Math. Soc. János Bolyai 37, 295–304.**  
DOI `10.1016/B978-0-444-86893-0.50022-X`. crossing-family inequalities 直接产生 matroid bases；可能给 tight-cut families 下的 exchange structure 提供更老的形式化入口。**Chain:** Frank submodular → matroid exchange.**ABSTRACT ONLY.** 

**B18. András A. Benczúr, András Frank — “Covering Symmetric Supermodular Functions by Graphs” (1999), Mathematical Programming 84, 483–503.**  
DOI `10.1007/s101070050034`. 是 Bernáth–Király splitting-off stuck theory 的直接祖先之一。**Chain:** Frank supermodular → Bernáth–Király.**ABSTRACT ONLY.** 

**B19. László Kozma, Shay Moran — “Shattering, Graph Orientations, and Connectivity” (2013), Electronic J. Combin. 20, P44.**  
DOI `10.37236/3326`; arXiv `1211.1319`. 某些 orientation systems 的 shattering-extremality 会带来保性质的 monotone edge-flip behavior；未直接覆盖 \(k\)-arc-strong，但它提供一种证明 orientation state graph 为 partial cube/isometric 类对象的完全不同语言。**Chain:** Greene–Zaslavsky / orientation flip graphs.**FULL TEXT FOUND.** 

---

# C. OLD / OBSCURE BUT POSSIBLY IMPORTANT

**C1. C. St. J. A. Nash-Williams — “Connected Detachments of Graphs and Generalized Euler Trails” (1985), J. London Math. Soc. 31, 17–29.**  
DOI `10.1112/jlms/s2-31.1.17`. 后来 Szigeti/Fleiner/Jordán detachment results 的核心老祖先；值得查 theorem proof 中 local sequence 是否已经隐含“一个一个改”的过程。**Chain:** Mader splitting → Nash-Williams → modern detachments.**FULL TEXT FOUND.** 

**C2. C. St. J. A. Nash-Williams — “Another Proof of a Theorem Concerning Detachments of Graphs” (1991), European J. Combin. 12, 245–247.**  
DOI `10.1016/S0195-6698(13)80090-X`. 极短、很容易在现代 citation search 中漏掉；给 splitting/detachment structure 的另一种 proof language。**Chain:** C1 → 1995 mixed orientation paper。**FULL TEXT FOUND.** 

**C3. Oliver Pretzel — “On Reorienting Graphs by Pushing Down Maximal Vertices” (1986), Order 3, 135–153.**  
可核 bibliographic trace；原始 DOI 本轮未确认。**这是一个重点 obscure lead**：1986 年就研究通过 local pushes 在 orientations 间 reorient，Propp 后来明确以它为起点。**Chain:** Fukuda–Prodon–Sakuma / Greene–Zaslavsky → orientation flip lattices.**SECONDARY CITATION ONLY.** 

**C4. Oliver Pretzel — “Orientations and Reorientations of Graphs” (1986), in *Combinatorics and Ordered Sets*, Contemp. Math. 57, 103–125.**  
老标题里直接出现 **reorientations**，而不是现代 reconfiguration；应优先把 references 整页挖出来。**Chain:** C3 → Propp.**SECONDARY CITATION ONLY.** 

**C5. Oliver Pretzel — “Orientations and Edge Functions on Graphs” (1991), Surveys in Combinatorics 1991, 161–186.**  
DOI `10.1017/CBO9780511666216.007`. 是 C3/C4 这条旧 local-reorientation 传统的 survey/bibliography portal，特别适合下一轮往 1970s/80s 倒挖。**Chain:** Pretzel → Propp/Felsner.**FULL TEXT FOUND.** 

**C6. Oliver Pretzel, Dale Youngs — “Cycle Lengths and Graph Orientations” (1990), SIAM J. Discrete Math. 3, 544–553.**  
DOI `10.1137/0403047`. 通过 flow-difference 等 edge functions 描述 orientation；可能用于代数化两个 orientations 的 difference。**Chain:** Pretzel reorientation line.**ABSTRACT ONLY.** 

**C7. D. R. Fulkerson, L. S. Shapley — “Minimal \(k\)-arc Connected Graphs” (1971), Networks 1, 91–98.**  
DOI `10.1002/net.3230010108`. 实际写于 **1961**；属于极早期 minimal \(k\)-arc-connectivity structure。与你要求的 minimal \(k\)-connected digraph neighborhood 完全吻合，后续 citation 值得单独追。**Chain:** old directed connectivity → Mader.**ABSTRACT ONLY.** 

**C8. Wolfgang Mader — “On a Property of \(n\)-Edge-Connected Digraphs” (1981), Combinatorica 1, 385–386.**  
这篇只有两页，是 1982 directed splitting theorem 前后的 obscure lemma；极可能是后来反复引用但标题完全不可搜索的那种文献。**Chain:** Mader directed splitting.**SECONDARY CITATION ONLY.** 

**C9. Wolfgang Mader — “On \(N\)-Edge-Connected Digraphs” (1983), North-Holland Mathematics Studies 75, 439–441.**  
DOI `10.1016/S0304-0208(08)73419-4`. 说明 finite \(n\)-edge-connected digraphs 可从 \(K_1\) 通过 edge addition 与 splitting-type operations successive construction 得到。**Chain:** C8/B10 → minimal directed connectivity.**ABSTRACT ONLY.** 

**C10. András Frank, Éva Tardos, András Sebő — “Covering Directed and Odd Cuts” (1984), Mathematical Programming Study 22, 99–112.**  
DOI `10.1007/BFb0121011`. 文章明确强调 **strong connectivity 与 parity conditions 的 analogy**，并讨论 orientation problems；对 \(2k+1\) 临界的 odd-cut interpretation 很值得追。**Chain:** Frank–Király parity → Frank submodular.**ABSTRACT ONLY.** 

**C11. Jean-Claude Picard, Maurice Queyranne — “On the Structure of All Minimum Cuts in a Network and Applications” (1980; tech report 1979), Mathematical Programming Studies 13, 8–16.**  
DOI `10.1007/BFb0120902`. 把固定 \(s,t\) 的所有 minimum cuts 表成一个 relation/DAG 的 closures；可能给“一条 edge 同时被哪些 tight cuts 阻塞”提供紧凑表达。**Chain:** Dinitz–Karzanov–Lomonosov → cactus/carcass.**FULL TEXT FOUND**（1979 technical report）. 

**C12. Dan Gusfield, Dalit Naor — “Extracting Maximal Information about Sets of Minimum Cuts” (1993), Algorithmica 10, 64–89.**  
DOI `10.1007/BF01908632`. 把 Gomory–Hu 与 Picard–Queyranne 两种 cut representations 联系起来；可作为 simultaneous tight-shore structure 的另一入口。**Chain:** C11 → Dinitz/cactus.**ABSTRACT ONLY.** 

**C13. András A. Benczúr — “A Representation of Cuts within \(6/5\) Times the Edge Connectivity with Applications” (1995), FOCS 1995, 92–102.**  
DOI `10.1109/SFCS.1995.492466`. 不只 minimum cuts，而是 very near-minimum cuts；如果 \(2k+1\) 阈值最终要求 simultaneously 控制 tight 与 one-slack cuts，这条支线很可能比普通 cactus 更合适。**Chain:** minimum-cut structure → Dinitz–Nutov minimum+1.**SECONDARY CITATION ONLY.** 

**C14. Richard A. Brualdi, Edward B. Scrimger — “Exchange Systems, Matchings, and Transversals” (1968), J. Combinatorial Theory 5, 244–257.**  
DOI `10.1016/S0021-9800(68)80071-7`. 非 orientation paper，但这是非常早的 abstract **exchange system** formalism；适合作为 Bérczi–Mátravölgyi–Schwarcz 那条 restricted basis-exchange 链的远祖。**Chain:** matroid exchange/reconfiguration.**FULL TEXT FOUND.** 

**C15. Richard A. Brualdi — “Comments on Bases in Dependence Structures” (1969), Bull. Austral. Math. Soc. 1, 161–167.**  
经典 symmetric replacement/exchange theorem 的早期来源。若最终 orientation feasible set 能被识别成某种 base system，这可能成为最老的交换背景之一。**Chain:** Bérczi basis-pair reconfiguration.**FULL TEXT FOUND.** 

**C16. S. L. Hakimi — “On the Degrees of the Vertices of a Directed Graph” (1965), Journal of the Franklin Institute 279, 290–308.**  
DOI `10.1016/0016-0032(65)90340-6`. prescribed indegree/outdegree orientation 的早期基础论文，而且考虑 strongly connected realizations、parallel edges、no loops。**Chain:** Hakimi → Frank–Gyárfás → degree-constrained orientations.**ABSTRACT ONLY.** 

**C17. C. St. J. A. Nash-Williams — “On Orientations, Connectivity and Odd-Vertex-Pairings in Finite Graphs” (1960), Canadian J. Math. 12, 555–567.**  
DOI `10.4153/CJM-1960-049-6`. 这是 orientation + connectivity + odd-pairing 传统非常早的入口；Frank/Király 后来 parity work 的历史背景应继续从这里往后追。**Chain:** Nash-Williams → Frank parity/orientation.**ABSTRACT/FIRST-PAGE TEXT FOUND; 暂记 ABSTRACT ONLY.** 

---

# D. WEAK LEADS

这些我暂时不认为应投入和 A/C 相同的时间，但它们扩宽方法地图。

**D1. James Propp — “Lattice Structure for Orientations of Graphs” (original preprint 1993; arXiv 2002; journal version 2025), Electronic J. Combin. 32, P4.26.**  
DOI `10.37236/9474`; arXiv `math/0209005`. fixed flow-difference orientation class 在 local moves 下形成 distributive lattice，并明确说明这是 Pretzel 1986 的延伸。**Chain:** Pretzel C3/C4.**FULL TEXT FOUND.** 

**D2. Stefan Felsner — “Lattice Structures from Planar Graphs” (2004), Electronic J. Combin. 11, R15.**  
DOI `10.37236/1768`. prescribed-outdegree / \(\alpha\)-orientations 在 face flips 下构成 distributive lattice；restriction 不同，但证明 local flip graph connected 的机制值得保留。**Chain:** Pretzel/Propp → α-orientations.**FULL TEXT FOUND.** 

**D3. Oliver Pretzel — “On Reorienting Graphs by Pushing Down Maximal Vertices—II” (2003), Discrete Mathematics 270, 227–240.**  
DOI `10.1016/S0012-365X(03)00160-2`. 给 Propp lattice theorem 新证明并分析 irreducible orientations / sink dependence。**Chain:** C3 → D1.**FULL TEXT FOUND.** 

**D4. Stefan Felsner, Kolja Knauer — “ULD-Lattices and \(\Delta\)-Bonds” (2009), Combinatorics, Probability and Computing 18.**  
arXiv `0807.1217`. generalizes c-orientations、α-orientations 与 planar-flow flip lattices；可能提供比 distributive lattice 更宽的 local exchange abstraction。**Chain:** Propp/Felsner.**FULL TEXT FOUND.** 

**D5. Eric Babson, Lukas Finschi, Komei Fukuda — “Cocircuit Graphs and Efficient Orientation Reconstruction in Oriented Matroids” (2001), European J. Combin. 22, 587–600.**  
DOI `10.1006/eujc.2001.0481`. cocircuit adjacency / reorientation class 的 oriented-matroid analogue；如果以后把 tight cuts 当 cocircuits，这条线可能变近。**Chain:** Fukuda / oriented-matroid pivots → matroid exchange.**FULL TEXT FOUND.** 

**D6. Emeric Gioan, Chi Ho Yuen — “On the Number of Circuit–Cocircuit Reversal Classes of an Oriented Matroid” (2019), Discrete Mathematics 342, 1056–1059.**  
DOI `10.1016/j.disc.2018.12.006`; arXiv `1707.00342`. 直接研究 circuit/cocircuit reversal system；cographic specialization值得后面单独追。**Chain:** oriented matroid reversal → Aichholzer-type orientation flips.**FULL TEXT FOUND.** 

**D7. Zsuzsanna Dancso, Jongmin Lim — “Lattice of Integer Flows and the Poset of Strongly Connected Orientations for Regular Matroids” (2023), Discrete Mathematics 346, 113589.**  
DOI `10.1016/j.disc.2023.113589`; arXiv `2202.13265`. 强连通 orientations 的 poset 被放进 integer flow lattice / regular matroid geometry；而且直接指向一个 **Amini 2010** 的更老结果，值得下一轮反向追原文。**Chain:** strong orientation ↔ flow lattice ↔ oriented matroid.**FULL TEXT FOUND.** 

**D8. Takehiro Ito, Yuni Iwamasa, Yasuaki Kobayashi, Yu Nakahata, Yota Otachi, Kunihiro Wasa — “Reconfiguring (non-spanning) Arborescences” (2023), Theoretical Computer Science 943, 131–141.**  
DOI `10.1016/j.tcs.2022.12.007`; arXiv `2107.03092`. single remove/add arc reconfiguration；对象比你已经知道的 “union of arborescences” 更基础，可提供 shortest exchange sequence 的技术。**Chain:** Kobayashi–Mahara–Schwarcz.**FULL TEXT FOUND.** 

---

## 第一轮最重要的新信号

不是在这些文献里找到了解答，而是发现了三个此前很容易漏掉的邻域：

1. **\(2k+1\) 本身已经在 connectivity-preserving local-operation literature 中出现。** Gabow–Jordán 2001 的 theorem 是目前最醒目的例子：
   \[
   \rho(s)\ge 2k+1
   \Longrightarrow
   \text{存在满足 bipartition constraint 的 admissible split pair}.
   \]
   这与问题中的阈值碰撞得过于精确，下一轮应该系统追它的 proof ancestry 和 citing papers。

2. **1990 年代之前已经有不叫 reconfiguration 的 strong-orientation transformation theory。** Donald–Elwin 的 MDS/path-cycle reversal，以及 Pretzel 的 pushing-down/reorientation 系列尤其值得挖。

3. **Mader splitting 与 orientation 之间不是两条独立文献线。** Jackson 1988、Bang-Jensen–Frank–Jackson 1995、Gabow–Jordán 2001、Frank–Király 2003 把它们连接得相当紧。

# NEXT CITATION CHAINS TO FOLLOW

下一轮我建议不重新 keyword-search，而按下面这些链继续往深处走：

1. **Gabow–Jordán 2001 \(2k+1\) theorem → references + citers**：重点找 admissible pair、blocking pair、dangerous set、obstacle 的原始 lemma，以及是否还有 directed/partition-constrained 后续版本。

2. **Donald–Elwin 1993 → MDS ancestry/citers**：追 “minimal difference set / simple transformation / handle basis”，看有没有把 cycle/path reversal further decomposed 的旧结果。

3. **Pretzel 1986 → Pretzel 1986 Contemp. Math. → Pretzel 1991 → Propp**：这是下一轮最重要的“旧 reconfiguration 不叫 reconfiguration”链。

4. **Nash-Williams 1995 mixed strong orientations → Nash-Williams 1985/1991 detachments → earlier detachment literature**：特别追 proof 是否通过 elementary admissible changes 实现。

5. **Mader 1981 → 1982 → 1983 → 1985 → Jackson 1988 → Bang-Jensen–Frank–Jackson 1995**：专搜 *admissible*, *critical*, *dangerous*, *obstacle*, *lifting*, *split pair*。

6. **Frank–Király 2002 → Frank–Tardos–Sebő 1984 → Nash-Williams 1960/1969 parity-orientation line**：目标是判断 \(2k+1\) 是否早已有 odd-cut obstruction language。

7. **Abdi–Cornuéjols–Zambelli 2024 → Abdi–Cornuéjols–Liu–Silina 2025 → Liu–Silina 2026**：不重新精读 theorem，专门追 references/citers 中关于 tight dicuts、degree-constrained dijoins、flip sets 的来源。

8. **Picard–Queyranne 1980 → Gusfield–Naor 1993 → Benczúr 1995 → near-mincuts**：然后接回你已经知道的 Dinitz–Nutov minimum+1 / carcass 文献，重点只找“同时表示 tight 与 one-slack cuts”的技术。

9. **Brualdi–Scrimger 1968 / Brualdi 1969 → base-orderable / strongly base-orderable matroids → restricted symmetric exchange**：最终接回 Bérczi–Mátravölgyi–Schwarcz。

10. **Dancso–Lim 2023 → Amini 2010 原始 theorem → integer flow/cut lattice**：Amini 这篇我这轮只定位到由后文明确引用，下一轮应先把准确 title、原文和 citation descendants 挖出来。

11. **Gioan circuit–cocircuit reversal → earlier Gioan papers → cographic oriented matroids / cycle–cocycle reversing systems**。Felsner 的 flip bibliography 还暴露出一篇 **Gioan 2007, “Enumerating degree sequences in digraphs and a cycle–cocycle reversing system”**，这应该进入下一轮正式核查名单。

12. **Fulkerson–Shapley 1961/1971 → Harary 1962 → Mader minimal digraphs**：专门搜 minimal \(k\)-arc-connected digraph、removable arc、contractible arc 的老术语。

你之后如果只说 **“继续”**，我就从这 12 条 citation chains 向更老、更偏的原文继续挖，不重新从关键词搜索起步。

# N. 文献搜索 Round 2 原始 ledger（完整纳入）

继续第二轮。这一轮没有重新扫你原来的 seed list，而是沿上一轮留下的 citation chains 向外追。**新增约 50 个条目/线索**。其中有几篇我认为应该明显上调优先级：

- **Arkin–Hassin–Shahar 2002**：直接研究用 **arc reversals 提升 arc-connectivity**；
- **Farber–Richter–Shank 1985**：几乎就是“保持可行性的 single-edge exchange state graph connected”在“两棵边不交生成树”上的版本；
- **Gabow 1976**：研究如何把一次较大的 symmetric exchange **串行化为逐元素合法交换**；
- **Szigeti 2004, On admissible edges**：直接研究“某条边为何不属于任何 admissible pair”，非常适合 blocker 思路；
- **Bernáth–Iwata–Király–Király–Szigeti 2008**：把 well-balanced / smooth \(k\)-arc-connected orientations、odd pairing、Mader-style reductions 连在一起。

---

# A. VERY CLOSE

### A1. Esther M. Arkin, Refael Hassin, Shimon Shahar
**Increasing digraph arc-connectivity by arc addition, reversal and complement**  
2002, *Discrete Applied Mathematics* 122, 13–22.  
DOI: `10.1016/S0166-218X(01)00319-5`

直接研究：给定 digraph，最少需要多少 **arc reversals** 才能达到目标 arc-connectivity。特别有价值的是 reversal problem 被转化到 weighted orientation / connectivity orientation machinery，因此它实际上把“arc reversal”与 Frank 学派的 orientation polyhedron 接上了。  
**Citation chain:** Frank orientation/submodular → arc-connectivity augmentation/reversal → Ito/Hoppenot–Szigeti.  
**FULL TEXT FOUND.** 

### A2. M. Farber, B. Richter, H. Shank
**Edge-disjoint spanning trees: A connectedness theorem**  
1985, *Journal of Graph Theory* 9(3), 319–324.  
DOI: `10.1002/jgt.3190090303`

这是第二轮最贴结构的一篇。状态是“两棵 edge-disjoint spanning trees”，move 是 **single edge exchange**，而 theorem 正是：任意两个状态可以通过逐次 single-edge exchanges 相连，且**每一步仍然是两棵 edge-disjoint spanning trees**。它与你的问题的逻辑骨架几乎一样，只是 feasibility system 换成了 spanning-tree packing。  
**Citation chain:** matroid basis exchange → arborescence-packing exchange → Kobayashi–Mahara–Schwarcz / Bérczi et al.  
**FULL TEXT FOUND.**

### A3. Harold N. Gabow
**Decomposing symmetric exchanges in matroid bases**  
1976, *Mathematical Programming* 10, 271–276.

定义 **strong serial exchange**，核心问题正是：一个 simultaneously feasible symmetric exchange 能否分解成逐元素 exchanges，使每个 intermediate set 都仍然是 base。这个“macro move → legal atomic moves”的问题形式，与你们目前反复碰到的 path/circuit reversal 是否可 single-edge-serialize 极其相似。  
**Citation chain:** Brualdi/Greene exchange → Gabow → Farber–Richter–Shank → modern basis-pair reconfiguration.  
**ABSTRACT ONLY.**

### A4. Attila Bernáth, Satoru Iwata, Tamás Király, Zoltán Király, Zoltán Szigeti
**Recent results on well-balanced orientations**  
2008, *Discrete Optimization* 5, 663–676.  
DOI: `10.1016/j.disopt.2008.03.001`

非常值得追 references。文章围绕 Nash-Williams strong/well-balanced orientation theorem，且特别出现 **smooth \(k\)-arc-connected orientations** 与 \(k\)-feasible odd-vertex pairings。奇数 parity、arc connectivity 和局部 pairing operation 在这里直接交会。  
**Citation chain:** Nash-Williams 1960/1969 → Mader/Lovász → Frank/Szigeti orientation.  
**FULL TEXT FOUND.**

### A5. Carla D. Savage, Cun-Quan Zhang
**The connectivity of acyclic orientation graphs**  
1998, *Discrete Mathematics* 184, 281–287.  
DOI: `10.1016/S0012-365X(97)00201-X`

直接把一个 orientation class 变成 graph：vertices 是 feasible orientations，adjacency 是 **reverse one edge**。Feasibility 是 acyclicity 而不是 \(k\)-arc-connectivity，但这是精确的 single-physical-edge orientation reconfiguration 模型。  
**Citation chain:** Greene–Zaslavsky / Fukuda–Prodon–Sakuma → orientation flip graphs.  
**ABSTRACT ONLY.** 

### A6. Wei-Ping Liu, Ivan Rival
**Inversions, cuts, and orientations**  
1991, *Discrete Mathematics* 87, 163–174.  
DOI: `10.1016/0012-365X(91)90045-4`

老术语里的 reconfiguration。研究 cut/inversion 型 reorientation，并有把这种较大的 reorientation **sequentially 构造**的结果。这条线值得专门检查“sequential”到底原子化到什么粒度。  
**Citation chain:** Mosesian → Pretzel → Liu–Rival → Propp/Felsner.  
**SECONDARY CITATION ONLY.**

### A7. András Frank
**An Algorithm for Submodular Functions on Graphs**  
1982, *North-Holland Mathematics Studies* 66, 97–120.  
DOI: `10.1016/S0304-0208(08)72446-0`

注意这**不是**你已知的 1982 *A Note on k-Strongly Connected Orientations...*。其应用包括 minimum-cost \(k\)-strongly-connected orientation；值得追 residual/augmenting operations 是否已经包含一种 atomic feasibility-preserving orientation walk。  
**Citation chain:** Edmonds–Giles → Frank submodular flow → later orientation polyhedra.  
**ABSTRACT ONLY.** 

### A8. Jørgen Bang-Jensen, Tibor Jordán
**Adding and Reversing Arcs in Semicomplete Digraphs**  
1998, *Combinatorics, Probability and Computing* 7, 17–25.  
DOI: `10.1017/S0963548397003179`

直接最优化“reverse arcs 使 digraph 成为 \(k\)-connected”。图类受限于 semicomplete digraph，但比一般 augmentation 更贴 reversal。值得向前后 citation 看是否有“reversible arc / safe reversal”局部 lemma。  
**Citation chain:** arc reversal augmentation → Bang-Jensen–Yeo → Bang-Jensen–Hörsch–Kriesell.  
**ABSTRACT ONLY.** 

### A9. Zoltán Király, Zoltán Szigeti
**Reliable Orientations of Eulerian Graphs**  
2006, EGRES Technical Report TR-2006-01.

研究 Eulerian graph 的 \(k\)-arc-connected orientation，并要求删除任意 vertex 后仍保持 \((k-1)\)-arc-connectivity；使用 feasible pairings、Lovász/Mader splitting 等工具。不是 flip theorem，但它把“orientation slack + connectivity-preserving local pairing”放在同一个框架里。  
**Citation chain:** Lovász/Mader splitting → Nash-Williams well-balanced → Szigeti.  
**FULL TEXT FOUND.** 

---

# B. STRUCTURALLY RELATED

### B1. Steffen Enni
**A note on mixed graphs and directed splitting off**  
1998, *Journal of Graph Theory* 27, 213–221.  
DOI: `10.1002/(SICI)1097-0118(199804)27:4<213::AID-JGT2>3.0.CO;2-Q`

直接回应 Jackson 关于 mixed orientation / directed splitting-off 的猜想，并给出 counterexamples 与 Eulerian special cases。非常适合查“为什么 admissible local operation 不一定存在”的早期障碍。  
**Chain:** Jackson 1988 → Mader-directed splitting.  
**ABSTRACT ONLY.** 

### B2. E. M. Arkin, R. Hassin
**A note on orientations of mixed graphs**  
2002, *Discrete Applied Mathematics* 116, 271–278.  
DOI: `10.1016/S0166-218X(01)00228-1`

冻结已有 arcs、只允许剩余 edges 选择方向，本质上就是 orientation fiber/completion 问题。可视为 Boesch–Tindell / Chung–Garey–Tarjan 那条 fixed-boundary completion 链的后继。  
**Chain:** mixed orientation completion → Frank orientation.  
**FULL TEXT FOUND.** 

### B3. Zoltán Király, Zoltán Szigeti
**Simultaneous well-balanced orientations of graphs**  
2006, *JCTB* 96, 684–692.  
DOI: `10.1016/j.jctb.2006.01.002`

要求多个 edge-disjoint subgraphs、甚至若干 contractions **同时** well-balanced；这很像你的 fiber 中同时冻结/控制多个 cut systems。  
**Chain:** Nash-Williams well-balanced → Frank/Szigeti simultaneous constraints.  
**FULL TEXT FOUND.** 

### B4. Alex R. Berg, Tibor Jordán
**Sparse certificates and removable cycles in \(l\)-mixed \(p\)-connected graphs**  
2005, *Operations Research Letters* 33, 111–114.  
DOI: `10.1016/j.orl.2004.05.008`

定义 connectivity-preserving **removable cycles**，并在 degree 条件下保证它们存在。作者还明确说明研究动机来自 connected orientation 问题。  
**Chain:** Mader removable operations → orientation existence.  
**FULL TEXT FOUND**（EGRES version）. 

### B5. Zoltán Szigeti
**On admissible edges**  
2004, EGRES TR-2004-07.

这一篇尤其建议下一轮精确追 references。它不仅找 admissible pairs，而是**characterize when a fixed edge belongs to no admissible pairs**，并由此重证 Mader theorem。换句话说，它直接研究 local move 被全部 blocker 杀死时发生什么。  
**Chain:** Mader → Frank → Szigeti splitting-off.  
**ABSTRACT/REPORT PAGE FOUND.**

### B6. Attila Bernáth, Tamás Király, László Végh
**Special skew-supermodular functions and a generalization of Mader's splitting-off theorem**  
2011, EGRES TR-2011-10.

把 splitting-off 推到更一般的 skew-supermodular requirement system；很可能是研究“cut constraints 不恰好属于经典 connectivity function 时，admissible pair theorem还能剩多少”的最好入口。  
**Chain:** Frank supermodular → Benczúr–Frank → Bernáth–Király splitting.  
**FULL TEXT FOUND.** 

### B7. Emeric Gioan
**Enumerating degree sequences in digraphs and a cycle–cocycle reversing system**  
2007, *European Journal of Combinatorics* 28, 1351–1366.  
DOI: `10.1016/j.ejc.2005.11.006`

定义 cycle reversal、cocycle/cut reversal 以及 combined reversal dynamical systems，并讨论 oriented-matroid generalization。是 Pretzel/Propp 链和现代 reversal-system 链之间的重要桥。  
**Chain:** Greene–Zaslavsky/Pretzel → oriented matroid reversal.  
**FULL TEXT FOUND / OPEN ARCHIVE.**

### B8. Omid Amini
**Lattice of integer flows and poset of strongly connected orientations**  
2010, arXiv:`1007.2456`.

integer-flow lattice 的 Voronoi cell face poset 与 **strongly connected orientations of subgraphs** 的 poset 同构。这个结果把 strong-orientation state space 几何化，是 Dancso–Lim 那条线真正的早期来源。  
**Chain:** integer flow lattice → Dancso–Lim.  
**FULL TEXT FOUND.**

### B9. Spencer Backman
**Riemann–Roch theory for graph orientations**  
2017, *Advances in Mathematics* 309, 655–691.  
DOI: `10.1016/j.aim.2017.01.005`

把 Gioan 的 cycle–cocycle system 推到 partial orientations，并使用 **directed path reversals**；同时明确连到 max-flow/min-cut。可能提供宏观 reversal、canonical form 和 residual path 的统一语言。  
**Chain:** Gioan → flow/cut lattice.  
**FULL TEXT FOUND.**

### B10. Spencer Backman
**Partial graph orientations and the Tutte polynomial**  
2018, *Advances in Applied Mathematics* 94, 103–119.  
DOI: `10.1016/j.aam.2017.05.003`; arXiv:`1408.3962`.

尤其有意思的是 cut/cycle reversal equivalence classes、minimal representatives，以及其 **abstract rewriting / confluence** interpretation。虽然 feasibility property 不同，但“local rewrites 是否 confluent/connected”语言可能很好用。  
**Chain:** Gioan → orientation reversal systems.  
**FULL TEXT FOUND.**

### B11. Daniel Kotlar, Ran Ziv
**On Serial Symmetric Exchanges of Matroid Bases**  
2013, *Journal of Graph Theory* 73, 296–304.  
DOI: `10.1002/jgt.21675`; arXiv:`1110.1826`.

专门发展 Gabow 的 **serial symmetric exchange**。对“大的 feasible exchange 能否按一个一个元素顺序完成”非常直接。  
**Chain:** Gabow 1976 → modern basis reconfiguration.  
**FULL TEXT FOUND.**

### B12. Daniel Kotlar
**On Circuits and Serial Symmetric Basis-Exchange in Matroids**  
2013, *SIAM J. Discrete Math.* 27, 1274–1286.  
DOI: `10.1137/120867603`.

用 circuits 精细分析 serial exchanges，尤其适合与你这里用 tight cuts / blockers certificate 逐步控制 exchange legality 类比。  
**Chain:** Gabow → Kotlar–Ziv → Bérczi basis-pairs.  
**FULL TEXT FOUND.** 

### B13. Martin Farber
**Basic pair graphs of transversal matroids**  
1989, *Discrete Mathematics* 73(3), 245–248.

直接定义 **basis pair graph**：状态包含两个 disjoint bases，邻接就是交换两个 component 中的元素；证明 transversal matroid 情形 connected，并明确指出 graphic/cographic cases 已知 connected。  
**Chain:** Farber–Richter–Shank → basis-pair graph → modern basis-pair reconfiguration.  
**ABSTRACT ONLY.**

### B14. Neil L. White
**A unique exchange property for bases**  
1980, *Linear Algebra and its Applications* 31, 81–91.  
DOI: `10.1016/0024-3795(80)90209-8`.

定义 compatible sequences of bases 之间能否通过 successive **unique exchanges** 转化；研究 UE(1), UE(2), UE(3) classes，并包含 graphic-matroid partial results。  
**Chain:** Brualdi/Greene → Gabow → basis-pair reconfiguration.  
**FULL TEXT FOUND / OPEN ARCHIVE.**

### B15. Raul Cordovil, M. L. Moreira
**Bases-cobases graphs and polytopes of matroids**  
1993, *Combinatorica* 13, 157–165.  
DOI: `10.1007/BF01303201`.

直接把 feasible base/cobase configurations 组成 adjacency graph/polytope；属于“feasible states + elementary exchange graph”的几何版本。  
**Chain:** basis graph / basis-pair exchange → Bérczi.  
**FULL TEXT FOUND.**

### B16. András Frank
**Finding feasible vectors of Edmonds–Giles polyhedra**  
1984, *JCTB* 36, 221–239.  
DOI: `10.1016/0095-8956(84)90029-7`.

算法围绕 Edmonds–Giles/submodular feasibility polyhedra中的 augmenting operations；值得下一轮专搜后来的“unit exchange / residual graph”版本，看 orientation incidence vector 能否得到更细的 adjacency statement。  
**Chain:** Edmonds–Giles → submodular flows → Frank orientation.  
**ABSTRACT ONLY.** 

### B17. Alex R. Berg, Tibor Jordán
**Minimally \(k\)-Edge-Connected Directed Graphs of Maximal Size**  
2005, *Graphs and Combinatorics* 21, 39–50.  
DOI: `10.1007/s00373-004-0588-6`.

继续 Fulkerson–Shapley/Mader 的 minimal directed connectivity 线。对于寻找“没有任何 removable/safe local operation”的极端 orientation，这类 minimal structures 很可能是最自然的比较对象。  
**Chain:** Fulkerson–Shapley → Mader minimal digraphs.  
**FULL TEXT FOUND**（technical-report version）. 

### B18. Olivier Durand de Gevigney, Zoltán Szigeti
**On minimally 2-\(T\)-connected directed graphs**  
2018, *Discrete Applied Mathematics* 250, 183–185.  
DOI: `10.1016/j.dam.2018.04.003`.

用 **tight bi-sets** 分析 minimal directed connectivity。对于 blocker family 的 uncrossing / cover structure，这是很适合向外追的 terminology source。  
**Chain:** Mader minimality → Szigeti tight-set methods.  
**FULL TEXT FOUND.** 

### B19. Harold N. Gabow
**Efficient splitting off algorithms for graphs**  
1994, STOC 1994, 696–705.  
DOI: `10.1145/195058.195436`.

从算法角度真正需要**找到 admissible pair**，因此比存在性 splitting theorem 更可能明确维护 blocked pairs / cut certificates。它又直接是后来 Gabow–Jordán \(2k+1\) 链的重要祖先。  
**Chain:** Mader → algorithmic admissible splitting → Gabow–Jordán 2001.  
**FULL TEXT FOUND.** 

---

# C. OLD / OBSCURE BUT POSSIBLY IMPORTANT

### C1. László Lovász
**On some connectivity properties of Eulerian graphs**  
1976, *Acta Mathematica Academiae Scientiarum Hungaricae* 28, 129–138.  
DOI: `10.1007/BF01902503`.

Eulerian splitting-off tradition 中的关键老入口。后来的 Mader/Jackson/Frank/Szigeti repeatedly 回到它。  
**Chain:** Lovász → Mader directed splitting → Jackson 1988.  
**ABSTRACT ONLY.** 

### C2. C. St. J. A. Nash-Williams
**Well-balanced orientations of finite graphs and unobtrusive odd-vertex-pairings**  
1969, in *Recent Progress in Combinatorics*, pp. 133–149.

这一篇应当和 1960 paper 分开看。标题已经同时出现 well-balanced orientation 与 odd pairing，是 2006/2008 Szigeti/Király 线的直接老祖先。  
**Chain:** Nash-Williams → Király–Szigeti → Bernáth–Iwata–Király–Király–Szigeti.  
**SECONDARY CITATION ONLY.** 

### C3. Wolfgang Mader
**Minimale \(n\)-fach kantenzusammenhängende Graphen**  
1971, *Mathematische Annalen* 191, 21–28.  
DOI: `10.1007/BF01433466`.

比你列出的 reduction paper 更早；属于“如果 connectivity 恰好 minimal，那么一定存在什么低度/可削减结构”的源头。  
**Chain:** Mader minimal graph → splitting-off.  
**ABSTRACT ONLY.** 

### C4. Wolfgang Mader
**Ecken vom Innen- und Aussengrad \(n\) in minimal \(n\)-fach kantenzusammenhängenden Digraphen**  
1974, *Archiv der Mathematik* 25, 107–112.

非常符合你指定的 “minimal \(k\)-connected digraph” 邻域：研究 minimal directed connectivity 中 indegree/outdegree 恰到阈值的 vertices。  
**Chain:** Fulkerson–Shapley → Mader 1974 → Mader 1985.  
**SECONDARY CITATION ONLY.** 

### C5. Oliver Pretzel
**Removing Monotone Cycles from Orientations**  
1988/1989, *Annals of Discrete Mathematics* 41, 355–362.  
DOI: `10.1016/S0167-5060(08)70474-6`.

定理研究 orientation 中某些 monotone cycles 能否消去而留下每个 cycle 两向都有足够 arcs 的 orientation；更重要的是 references 暴露出 Mosesian 与 Aigner–Prins 的更早 orientation transformation 文献。  
**Chain:** Mosesian → Pretzel reorientation.  
**FULL TEXT FOUND.**

### C6. K. M. Mosesian
**On strongly basable graphs**  
1972, *Dokl. Akad. Nauk Armjan. SSR* 54, 134–138. Russian.

Pretzel/Liu–Rival 之前的 vertex-pushing / reorientation ancestry。现代搜索几乎搜不到。  
**Chain:** Mosesian → Pretzel → Liu–Rival → Propp.  
**SECONDARY CITATION ONLY.**

### C7. K. M. Mosesian
**Some theorems on strongly basable graphs**  
1972, same journal 54, 241–245. Russian.

同一早期系列，Pretzel 的 monotone-cycle paper 明确列为 predecessor。  
**Chain:** same as C6.  
**SECONDARY CITATION ONLY.**

### C8. K. M. Mosesian
**Basable and strongly basable graphs**  
1972, *Dokl. Akad. Nauk Armjan. SSR* 55, 83–86. Russian.

标题英文译法有若干变体，但 bibliography 能确认是同一 1972 三篇系列的一篇。  
**Chain:** Mosesian/Pretzel pushing-down.  
**SECONDARY CITATION ONLY.** 

### C9. Curtis Greene
**A multiple exchange property for bases**  
1973, *Proc. AMS* 39, 45–50.  
DOI: `10.1090/S0002-9939-1973-0311494-8`.

对任意 base subset \(A\) 找另一 base 中对应 \(B\)，使两边 simultaneously remain bases。它是 Gabow serial decomposition 的直接祖先之一。  
**Chain:** Greene → Gabow 1976 → serial exchange.  
**FULL TEXT FOUND.**

### C10. D. R. Woodall
**An exchange theorem for bases of matroids**  
1974, *JCTB* 16, 227–228.  
DOI: `10.1016/0095-8956(74)90067-7`.

极短老文，出现在几乎所有 serial symmetric exchange bibliography 里。  
**Chain:** Greene/Gabow → Kotlar.  
**FULL TEXT FOUND.** 

### C11. Richard A. Brualdi
**Common transversals and strong exchange systems**  
1970, *Journal of Combinatorial Theory* 8, 307–329.  
DOI: `10.1016/S0021-9800(70)80084-9`.

“strong exchange system” 这套 terminology 比后来 reconfiguration 早几十年。可作为 restricted exchange connectivity 的老根。  
**Chain:** Brualdi → Gabow/White → basis-pair reconfiguration.  
**ABSTRACT ONLY.** 

### C12. Joan Davies, Colin McDiarmid
**Disjoint Common Transversals and Exchange Structures**  
1976, *Journal of the London Mathematical Society* s2-14, 55–62.  
DOI: `10.1112/jlms/s2-14.1.55`.

研究 simultaneous disjoint feasible objects 的 exchange structures；与“两个/多个 packing 约束下仍能逐步交换”是同一类障碍。  
**Chain:** Brualdi strong exchanges → matroid intersection/exchange.  
**ABSTRACT ONLY.** 

### C13. Curtis Greene, Thomas L. Magnanti
**Some Abstract Pivot Algorithms**  
1975, *SIAM Journal on Applied Mathematics* 29, 530–539.  
DOI: `10.1137/0129045`.

“pivot” 是你要求主动搜索的老术语之一。这篇试图抽象 combinatorial feasible bases 上的 elementary pivots；可能与 later submodular-flow residual algorithms 相接。  
**Chain:** matroid exchange → abstract pivot → combinatorial optimization.  
**ABSTRACT ONLY.** 

### C14. Richard L. Cummins
**Hamilton Circuits in Tree Graphs**  
1966, *IEEE Transactions on Circuit Theory* CT-13, 82–90.  
DOI: `10.1109/TCT.1966.1082546`.

非常早的 reconfiguration/Gray-code 祖先：状态是 spanning trees，边代表 elementary tree transformation，并证明 tree graph 存在很强的 Hamiltonicity 性质。  
**Chain:** spanning-tree exchange graph → Farber–Richter–Shank.  
**ABSTRACT ONLY.**

### C15. Carlos A. Holzmann, Frank Harary
**On the Tree Graph of a Matroid**  
1972, *SIAM Journal on Applied Mathematics* 22, 187–193.  
DOI: `10.1137/0122021`.

把 C14 直接推广到 matroid bases；base graph 甚至 uniformly Hamiltonian。说明“single-element exchange graph connected”在 modern reconfiguration 术语出现前已有成熟传统。  
**Chain:** Cummins → Farber/Gabow → basis-pair exchange.  
**ABSTRACT/PDF LOCATED.**

### C16. D. J. Naddef, W. R. Pulleyblank
**Hamiltonicity in \((0,1)\)-polyhedra**  
1984, *JCTB* 37, 41–52.  
DOI: `10.1016/0095-8956(84)90043-1`.

若某类 feasible orientations 真能表示成某个 \(0/1\) polyhedron 的全部 vertices，polyhedral skeleton 的 connectivity/Hamiltonicity 可能成为异常强的工具。不过关键难点仍是 skeleton adjacency 是否就是 physical single-edge flip。  
**Chain:** polyhedral exchange graph → Farber–Richter–Shank.  
**FULL TEXT FOUND.**

---

# D. WEAK LEADS

### D1. William F. Klostermeyer
**Pushing Vertices and Orienting Edges**  
1999, *Ars Combinatoria* 51, 65–75.

继续 Mosesian/Pretzel 的 push operation：push 一个 vertex 等价于把 incident cut 上的 arcs 全反向。研究怎样通过这种 moves 到达 strongly connected orientations。  
**Chain:** Mosesian → Pretzel.  
**FULL TEXT FOUND.** 

### D2. Eric Goles, Erich Prisner
**Source reversal and chip firing on graphs**  
2000, *Theoretical Computer Science* 233, 287–295.  
DOI: `10.1016/S0304-3975(99)00122-X`.

source reversal 是 cut flip，而 chip-firing 提供 dynamical-system/lattice language。不是 connectivity-preserving，但可作为 orientation dynamics 的旁系。  
**Chain:** Pretzel/Propp → chip firing.  
**ABSTRACT ONLY.** 

### D3. Gary MacGillivray, K. L. B. Wood
**Re-Orienting Tournaments By Pushing Vertices**  
2000, *Ars Combinatoria* 57, 33–47.

研究 tournament 上的 vertex push/cut reversal 等价类。操作不够局部，但可能提供 cut-reversal decomposition terminology。  
**Chain:** Pretzel/Mosesian.  
**ABSTRACT ONLY.** 

### D4. William F. Klostermeyer, L. Šoltés
**Hamiltonicity and reversing arcs in digraphs**  
1998, *Journal of Graph Theory* 28, 13–30.

研究通过 reversing arcs / switching 达到 Hamiltonian property；feasibility 完全不同，但属于 1990s “reversing arcs” literature，可能向外带出遗漏的 reversal papers。  
**Chain:** general arc reversal.  
**ABSTRACT ONLY.** 

### D5. Carla D. Savage, Matthew B. Squire, Douglas B. West
**Gray Code Results for Acyclic Orientations**  
1993, *Congressus Numerantium* 96, 185–204.

目标就是用很小的 local orientation changes 枚举所有 feasible orientations；是 single-edge-flip Gray-code 传统的重要老入口。  
**Chain:** acyclic orientations → Savage–Zhang 1998.  
**FULL TEXT FOUND.** 

### D6. Matthew B. Squire
**Generating the Acyclic Orientations of a Graph**  
1998, *Journal of Algorithms* 26, 275–290.  
DOI: `10.1006/jagm.1997.0891`.

generation algorithm 比 connectivity theorem 弱相关，但 bibliography 很可能能继续挖 1980s–90s orientation Gray-code literature。  
**Chain:** Gray codes → acyclic orientation flip graph.  
**ABSTRACT ONLY.** 

### D7. Yefim Dinitz, Zeev Nutov
**Cactus tree type models for families of bisections of a set**  
约 1996, manuscript.

这是 Dinitz–Nutov cut-model 工作旁边很隐蔽的一条线：不是只描述一个 graph 的 mincuts，而是研究抽象 bisection families 的 cactus-tree representation。对“blocker shore family 是否有 cactus-like global representation”有潜在价值。  
**Chain:** DKL mincuts → Dinitz/Nutov cactus/min+1.  
**FULL TEXT FOUND**（author manuscript）. 

### D8. A. M. H. Gerards
**On 2-vertex connected orientations**  
1997, unpublished manuscript.

目前只在 Berg–Jordán 2006 的 bibliography 中明确找到，后者把它列作 2-connected orientation 问题的 predecessor。原稿可能仍残留在旧 CWI/author archive。  
**Chain:** Frank vertex-connected orientation conjecture → Berg–Jordán.  
**SECONDARY CITATION ONLY.**

### D9. M. Aigner, G. Prins
**\(k\)-Orientable graphs**  
unpublished preprint, Freie Universität Berlin；年代至少早于 Pretzel 1988。

Pretzel 的 *Removing Monotone Cycles* 明确列入 references，但本轮没有定位到原稿。标题相当诱人，而且处在 Mosesian–Pretzel 旧 orientation 链上。  
**Chain:** Mosesian → Pretzel.  
**SECONDARY CITATION ONLY.**

---

## 这一轮我认为最重要的结构性扩张

现在 literature map 里已经出现一条此前不够突出的路线：

\[
\boxed{
\text{macro feasible exchange}
\;\longrightarrow\;
\text{serial exchange}
\;\longrightarrow\;
\text{single-step feasible path}
}
\]

具体是

\[
\text{Greene 1973}
\to
\text{Gabow 1976}
\to
\text{White 1980}
\to
\text{Farber--Richter--Shank 1985}
\to
\text{Farber 1989}
\to
\text{Kotlar 2013}
\to
\text{modern basis-pair reconfiguration}.
\]

这里 **Farber–Richter–Shank 1985** 尤其值得保留：它不只是一个 exchange theorem，而是真的证明整个 feasible **state graph under single exchanges is connected**。

另一条则是：

\[
\boxed{
\text{no admissible local move}
\;\longrightarrow\;
\text{tight/dangerous obstruction structure}
}
\]

即

\[
\text{Lovász/Mader}
\to
\text{Gabow 1994}
\to
\text{Szigeti 2004}
\to
\text{Gabow--Jordán 2001}
\to
\text{Bernáth--Király--Végh}.
\]

其中 **Szigeti, On admissible edges** 现在看来应该和 Gabow–Jordán 的 \(2k+1\) paper 一起作为下一轮最高优先级：它明确 characterizes **一条 edge 完全没有 admissible partners** 的情形。

# NEXT CITATION CHAINS TO FOLLOW

下一次你再说 **“继续”**，我会优先沿这些链走，不回头重新扫关键词：

1. **Gabow 1976 → Farber–Richter–Shank 1985 → Farber 1989 → White 1980 → Cordovil–Moreira 1993**：专挖 *serial exchange / basis-pair graph / connectedness theorem*，尤其 graphic、cographic、regular matroid 中更早或更强的 single-exchange connectivity。

2. **Gabow–Jordán \(2k+1\) → Gabow 1994 → Szigeti 2004 → Bernáth–Király–Végh 2011**：精确追 *non-admissible pair / blocking set / dangerous set / obstacle* 的原始定义和 odd-degree special lemmas。

3. **Nash-Williams 1969 → Király–Szigeti 2004/2006 → Bernáth et al. 2008**：追 *smooth \(k\)-arc-connected orientation*, feasible odd pairing 与 path/circuit reversal，尤其所有奇数阈值现象。

4. **Arkin–Hassin–Shahar 2002 → Frank weighted orientations → citing papers**：重点找有没有讨论 optimal reversal set 的 **ordering/serialization**，即同一批 arcs 有没有一个顺序使 intermediate digraphs 保持 \(k\)-arc-strong。

5. **Liu–Rival 1991 → Mosesian 1972 → Pretzel 1986/1988**：把 “cut/inversion/push 可 sequentially realize” 的原始 theorem 找全，并查 sequential operation 到底能否细到 individual edges。

6. **Mader minimal digraphs → Berg–Jordán 2005 → Durand de Gevigney–Szigeti 2018**：专找 removable/reversible/contractible **individual arcs** 的结构性保证，而不是整个 cycle。

7. **Amini 2010 → Gioan 2007/2008 → Backman 2017/2018 → Dancso–Lim**：寻找 strong-orientation poset / flow lattice 中的 cover relation 究竟对应什么 physical modification。

8. **Dinitz–Nutov abstract bisection manuscript → cactus tree / min+1 papers**：查有没有不依赖“这是 exact minimum cut family”的 representation theorem，可以描述 blocker cuts。

9. **Gerards 1997 unpublished manuscript**：沿 Berg/Jordán bibliography、旧 CWI 页面和 citing literature 尝试把稿子本身挖出来。

10. **Aigner–Prins, \(k\)-Orientable graphs**：沿 Pretzel bibliography、Prins/Aigner publication lists、德文数据库找这个未出版 preprint 的痕迹。

11. **Cummins 1966 → Holzmann–Harary 1972 → Naddef–Pulleyblank 1981/1984 → Farber 1985**：这是一个很老的“feasible state graph 不只 connected，甚至 Hamiltonian”传统，下一轮可专门找 orientation analogue。

12. **Frank 1982 algorithm → Frank 1984 feasible vectors → Cunningham–Frank submodular flow**：不再看 existence theorem，而只挖 residual graph 中的 **unit-coordinate / elementary augmentation adjacency**，看有没有隐藏的 feasible-walk theorem。

# O. 文献搜索 Round 3 原始 ledger（完整纳入）

继续第三轮。以下只列**前两轮没有正式列出的新条目**。这轮真正扩出来的两条主线是：

\[
\text{minimum-cost }k\text{-arc-connected orientation}
\longleftrightarrow
\text{submodular-flow adjacency/augmentation}
\]

以及

\[
\text{macro feasible exchange}
\longrightarrow
\text{serial / sequential exchange}
\longrightarrow
\text{single-step feasible walk}.
\]

另外发现一个很重要、但原始出处仍待定位的 **Lovász polyhedral-adjacency theorem**，放在最后单列。

---

# A. VERY CLOSE

### A1. Satoru Iwata, Yusuke Kobayashi
**An Algorithm for Minimum Cost Arc-Connectivity Orientations**  
2010, *Algorithmica* 56(4), 437–447.  
DOI `10.1007/s00453-008-9179-x`.

给定 \(2k\)-edge-connected undirected graph，直接求 minimum-cost **\(k\)-arc-connected orientation**。这意味着给每条 physical edge 的两个方向赋不同 cost 后，可以把“靠近指定 target orientation”编码进同一 feasibility polyhedron；文章明确沿 Frank 1982 → Gabow 1995 的 submodular-flow 算法链。  
**Chain:** Frank 1982 submodular orientation → Gabow 1995 → Iwata–Kobayashi → Ito/Blind–Knauer–Valicov.  
**FULL TEXT FOUND.**

### A2. Harold N. Gabow
**Centroids, Representations, and Submodular Flows**  
1995, *Journal of Algorithms* 18(3), 586–628.  
DOI `10.1006/jagm.1995.1022`.

这是 A1 明确引用的加速来源。它为 crossing/intersecting set families 建 compact representation，并用于 submodular flows；Iwata–Kobayashi 明确指出其算法给 minimum-cost \(k\)-arc-connected orientation 改进到 \(O(kn^2m)\)。所以这篇比标题显示得离问题近得多。  
**Chain:** Edmonds–Giles → Frank → Gabow → minimum-cost arc-connected orientations.  
**FULL TEXT FOUND.**

### A3. András Frank
**Orientations of Graphs and Submodular Flows**  
1996, *Congressus Numerantium* 113, 111–142.

专门系统连接 orientation theorems 与 submodular flows，并把 Nash-Williams orientation 与 mixed-orientation extension 纳入同一框架。下一步尤其值得从它的 bibliography 找 polyhedral adjacency / residual augmentation 的老来源。  
**Chain:** Frank 1982 → submodular flow → FKK / Iwata–Kobayashi.  
**FULL TEXT FOUND.**

### A4. Xueliang Li
**Edge-disjoint Minimum-weight Connected Spanning \(k\)-edge Subgraphs in a Weighted Graph: A Connectedness Theorem**  
1998, *Discrete Mathematics* 188, 175–182.  
DOI `10.1016/S0012-365X(97)00253-7`.

这是 Farber–Richter–Shank 的严格加强：任意两个 pairs of edge-disjoint **minimum-weight connected spanning \(k\)-edge subgraphs** 可以由 **single-edge exchanges** 互达，而且每一步仍保持全部 feasibility 和 minimum-weight 条件。其逻辑形式与当前问题非常近。  
**Chain:** Farber–Richter–Shank 1985 → packing reconfiguration → modern basis-pair reconfiguration.  
**ABSTRACT/FULL ARTICLE PAGE FOUND.**

### A5. Satoru Iwata
**On Matroid Intersection Adjacency**  
2002, *Discrete Mathematics* 242, 277–281.  
DOI `10.1016/S0012-365X(01)00167-4`.

研究两个 matroid 的 common-base polytope 中 extreme points 的**邻接关系**，并只用 simultaneous base exchange axiom 重证 Frank–Tardos theorem。对当前问题很有启发性，因为“polyhedral adjacency 是否能细化成 physical single-edge adjacency”正是一个自然问题。  
**Chain:** Frank–Tardos polyhedral adjacency → matroid exchange → reconfiguration.  
**FULL TEXT FOUND.**

### A6. Xu-dong Yuan, Mao-cheng Cai
**Vertices of Degree \(k\) in a Minimally \(k\)-Edge-Connected Digraph**  
2000, *Discrete Mathematics* 218, 293–298.  
DOI `10.1016/S0012-365X(99)00362-3`.

这是 directed minimal-connectivity line。尤其醒目的是他们证明 Mader conjecture
\[
u^+(D)+2u^\pm(D)+u^-(D)\ge 2k+2.
\]
这里出现的 **\(2k+2\)** 与我们的已知 flip threshold 数值相同；目前没有证据说明二者有直接关系，但“minimal \(k\)-arc-connected obstruction 必含多少 threshold vertices”值得追。文章关键词还明确包括 *\(k\)-cut, crossing-free, terminal*。  
**Chain:** Fulkerson–Shapley → Mader minimal digraphs → Yuan–Cai.  
**FULL TEXT FOUND.**

### A7. Xudong Yuan, Liying Kang, Mao-cheng Cai
**The Number of Vertices of Degree \(k\) in a Minimally \(k\)-Edge-Connected Digraph**  
2000, *Journal of Graph Theory* 33, 94–108.  
DOI `10.1002/(SICI)1097-0118(200002)33:2<94::AID-JGT4>3.0.CO;2-I`.

A6 的更 quantitative companion paper，继续研究 minimal directed \(k\)-connectivity 强迫出的 threshold-degree vertices。若 frozen orientation 最终能压缩成某种 minimal critical digraph，这条线可能成为结构工具。  
**Chain:** Mader critical/minimal digraphs → A6.  
**FULL TEXT FOUND.**

### A8. Wolfgang Mader
**Ecken von kleinem Grad in kritisch \(n\)-fach zusammenhängenden Digraphen**  
1991, *Journal of Combinatorial Theory B* 53, 260–272.  
DOI `10.1016/0095-8956(91)90077-W`.

证明 critically \(n\)-connected digraph 必有小 in/out-degree vertex，并推出 minimally \(n\)-edge-connected digraph 中存在 indegree=outdegree=\(n\) 的 vertex。它比一般“minimal digraph”背景更贴近“所有 local moves 被 tight cuts 锁死时必须暴露什么局部结构”。  
**Chain:** Mader 1974 → Mader 1985 → minimal/critical directed connectivity.  
**FULL TEXT FOUND.**

### A9. David C. Fisher, Kathryn Fraughnaugh, Larry Langley, Douglas B. West
**The Number of Dependent Arcs in an Acyclic Orientation**  
1997, *JCTB* 71, 73–78.  
DOI `10.1006/jctb.1997.1769`.

这里的 **dependent arc** 定义得恰好像我们的“illegal physical edge”：反转该 arc 会破坏 feasibility，只不过 feasibility 是 acyclicity。论文研究一个 orientation 中可以有多少这种不可单边反转的 arcs，是非常合适的 terminology/method analogue。  
**Chain:** Greene–Zaslavsky / acyclic orientation flips → Savage–Zhang.  
**FULL TEXT FOUND.**

---

# B. STRUCTURALLY RELATED

### B1. Sean McGuinness
**A Base Exchange Property for Regular Matroids**  
2014, *JCTB* 107, 42–77.  
DOI `10.1016/j.jctb.2014.02.004`.

证明 regular matroid 的任意两个 bases 中，总能找到具有**唯一 symmetric exchange partner** 的元素，解决 White 1980 问题。因为你已知的 Bérczi–Mátravölgyi–Schwarcz 正是在 regular matroids 做 basis-pair reconfiguration，这篇应视为它的重要 predecessor。  
**Chain:** White 1980 → McGuinness → Bérczi et al.  
**FULL TEXT FOUND.**

### B2. J. C. M. Keijsper, R. A. Pendavingh, Alexander Schrijver
**Adjacency, Inseparability, and Base Orderability in Matroids**  
2000, *European Journal of Combinatorics* 21, 487–502.  
DOI `10.1006/eujc.1999.0355`.

把 oriented-matroid **inseparability**、binary-matroid adjacency 与 strongly base-orderable subsets 联系起来。这里“某些元素因所有 circuits/cocircuits 的符号关系而不能独立交换”与 tight-cut blockers 很相似。  
**Chain:** oriented matroid circuit–cocircuit → restricted basis exchange.  
**FULL TEXT FOUND.**

### B3. John Donald, Malcolm Tobey
**A Generalised Exchange Theorem for Matroid Bases**  
1991, *Bulletin of the Australian Mathematical Society* 43, 177–180.

对任意 \(r\)-subset of one base，建立可交换到另一个 base 的 \(r\)-subset injection；它是后来 sequential exchange results 的直接 predecessor。  
**Chain:** Brualdi → Donald–Tobey → Kotlar–Roda–Ziv.  
**FULL TEXT FOUND.**

### B4. Joseph E. Bonin
**On Basis-Exchange Properties for Matroids**  
1998, *Discrete Mathematics* 187, 265–268.  
DOI `10.1016/S0012-365X(97)00269-0`.

把 basis-exchange property 与 circuit–cocircuit intersection restrictions 联系起来，并 characterizes series-parallel network matroids 的一种 exchange property。  
**Chain:** circuit/cocircuit blockers → basis exchange.  
**FULL TEXT FOUND.**

### B5. Joseph E. Bonin
**Basis-Exchange Properties of Sparse Paving Matroids**  
2013, *Advances in Applied Mathematics* 50, 6–15.  
DOI `10.1016/j.aam.2011.05.006`.

验证多个长期 basis-exchange conjectures，包括与 basis-pair connectivity 相邻的问题。适合作为“哪些结构类自动允许 serialization”的比较样本。  
**Chain:** Gabow/Farber/White → modern basis-pair exchange.  
**FULL TEXT FOUND.**

### B6. Konstantinos Papalamprou
**On the Basis Pair Graphs of Signed-Graphic Matroids**  
2021, *Discrete Mathematics, Algorithms and Applications* 13, 2150033.  
DOI `10.1142/S1793830921500336`.

明确研究 basis-pair graph **connectedness**，并识别 signed-graphic case 中尚存的 obstruction minors。比一般 matroid exchange 更贴“state graph connected?”。  
**Chain:** Farber basis-pair graph → regular-matroid reconfiguration.  
**ABSTRACT ONLY.**

### B7. Dani Kotlar, Elad Roda, Ran Ziv
**On Sequential Basis Exchange in Matroids**  
2021, *SIAM J. Discrete Math.* 35, 2517–2519.  
DOI `10.1137/19M1291261`.

继续 Gabow 的 serialization 问题；文章还给 Donald–Tobey theorem 一个直接 exchange proof。  
**Chain:** Gabow 1976 → Donald–Tobey → sequential exchange.  
**FULL TEXT FOUND.**

### B8. Sean McGuinness
**Serial Exchanges in Matroids**  
2022, *Discrete Mathematics* 345, 112679.  
DOI `10.1016/j.disc.2021.112679`.

定义 \(X\subseteq B_1\) 与 \(Y\subseteq B_2\) 的 exchange 可以按顺序进行、且**每个 prefix 后两边仍都是 bases**；这和 “reverse 一个 target difference set 时，每个 prefix orientation 均 legal” 是极直接的抽象类比。  
**Chain:** Gabow serial exchange → Kotlar → modern reconfiguration.  
**FULL TEXT FOUND.**

### B9. Dominique Andres, Winfried Hochstättler, Markus Merkel
**On a Base Exchange Game on Bispanning Graphs**  
2014, *Discrete Applied Mathematics* 165, 25–36.  
DOI `10.1016/j.dam.2013.08.016`.

两棵 spanning trees partition edge set；每轮交换一条 edge 后必须再次得到两棵 spanning trees。它研究的不只是 existence，而是 adversarial **local feasible exchange dynamics**。  
**Chain:** Farber–Richter–Shank → unique symmetric exchanges.  
**FULL TEXT FOUND.**

### B10. André Bouchet, William H. Cunningham
**Delta-Matroids, Jump Systems, and Bisubmodular Polyhedra**  
1995, *SIAM J. Discrete Math.* 8, 17–32.  
DOI `10.1137/S0895480191222926`.

jump-system 的核心 two-step exchange axiom 很值得记住：一个 unit step 不可行时，允许第二个 unit step 修补。这可能是“single edge blocked，但 two-edge compensating move 可行”最成熟的抽象离散凸模型之一。  
**Chain:** delta-matroid → jump systems → Murota.  
**FULL TEXT FOUND.**

### B11. László Lovász
**The Membership Problem in Jump Systems**  
1997, *JCTB* 70, 45–66.  
DOI `10.1006/jctb.1997.1744`.

继续 jump-system exchange geometry；值得与 orientation incidence vectors 是否可能形成某种 jump system/M-convex slice 的问题对照。  
**Chain:** Bouchet–Cunningham → Murota discrete convexity.  
**FULL TEXT FOUND.**

### B12. Yusuke Kobayashi, Kazuo Murota, Ken’ichiro Tanaka
**Operations on M-Convex Functions on Jump Systems**  
2007, *SIAM J. Discrete Math.* 21, 107–129.  
DOI `10.1137/060652841`.

研究 splitting、aggregation、convolution、network transformation 等操作保持 jump-M-convexity；说明 exchange structure 在经过网络型 transformations 后仍可存活。  
**Chain:** Murota → network/submodular exchange.  
**FULL TEXT FOUND.**

### B13. András Frank
**Submodular Functions in Graph Theory**  
1993, *Discrete Mathematics* 111, 231–243.  
DOI `10.1016/0012-365X(93)90158-P`.

这一篇特别值得留在 blocker 链：它用 submodular functions 给 Mader theorem 新证明，并处理 connectivity augmentation。比一般 survey 更可能暴露“dangerous/tight sets ⇒ admissible operation”的 uncrossing skeleton。  
**Chain:** Mader → Frank submodular → splitting-off.  
**FULL TEXT FOUND.**

### B14. András Frank
**Augmenting Graphs to Meet Edge-Connectivity Requirements**  
1992, *SIAM J. Discrete Math.* 5, 25–53.  
DOI `10.1137/0405003`.

后来大量 constrained splitting/augmentation 文献的基础 citation；其任意 pairwise connectivity requirements 是典型 symmetric skew-supermodular demand source。  
**Chain:** Mader → Frank augmentation → Benczúr/Frank/Bernáth/Király.  
**FULL TEXT FOUND.**

### B15. Tamás Király, Jácint Szabó
**A Note on Parity Constrained Orientations**  
2009, *Combinatorica* 29, 619–628.  
DOI `10.1007/s00493-009-2411-8`.

把 connectivity requirement 表成 intersecting supermodular \(p\)，同时 impose in-degree parity。对于 \(2k+1\) 临界问题，值得继续追其 parity/odd-set bibliography。  
**Chain:** Frank–Jordán–Szigeti parity orientation → Frank–Király.  
**FULL TEXT FOUND.**

### B16. Attila Bernáth, Gwenaël Joret
**Well-Balanced Orientations of Mixed Graphs**  
2008, *Information Processing Letters* 106, 149–151.  
DOI `10.1016/j.ipl.2007.10.014`.

证明 mixed graph 的 well-balanced completion 已经可以 NP-hard。对于“冻结一些 physical edges 后 orientation fiber 会不会仍有好结构”，这是一个重要警告。  
**Chain:** Nash-Williams mixed/well-balanced → fixed-boundary orientation fibers.  
**FULL TEXT FOUND.**

### B17. Zoltán Király, Zoltán Szigeti
**Notes on Well-Balanced Orientations**  
2004, EGRES TR-2004-10.

这是 2008 survey 之前的技术报告，直接围绕 Nash-Williams well-balanced orientation、odd pairing 和 splitting methods。下一轮可只挖它的 references，不需重读后来的 summary。  
**Chain:** Nash-Williams 1969 → Lovász splitting → well-balanced orientation.  
**FULL TEXT FOUND.**

### B18. Satoru Iwata, Tamás Király, Zoltán Király, Zoltán Szigeti
**On Well-Balanced Orientations, Counter-examples for Related Problems**  
2004/2005, EGRES Technical Report TR-2004-16.

这篇的价值主要是 **counterexamples**：它测试若干看似自然的 stronger orientation statements，适合检查我们是否正无意间假设了一个已知 false 的 local-to-global property。EGRES 作者页确认该报告存在。  
**Chain:** Nash-Williams → Király/Szigeti well-balanced line.  
**FULL TEXT FOUND.**

---

# C. OLD / OBSCURE BUT POSSIBLY IMPORTANT

### C1. László Lovász
**Connectivity in Digraphs**  
1973, *JCTB* 15, 174–177.  
DOI `10.1016/0095-8956(73)90018-X`.

非常短的老文，研究 directed local edge-connectivities \(c(x,y)\) 的结构关系。它属于后来 Eulerian/splitting/orientation machinery 的 Lovász directed-connectivity 背景。**注意：我目前没有证据证明它就是下面那个 polyhedral adjacency theorem 的原出处。**   
**Chain:** Lovász directed connectivity → Eulerian splitting → Frank/Mader.  
**FULL TEXT FOUND.**

### C2. Wolfgang Mader
**On Critically Connected Digraphs**  
1989, *Journal of Graph Theory* 13, 513–522.  
DOI `10.1002/jgt.3190130412`.

研究 vertex deletion 一步就破坏 connectivity 的 critical digraph；证明此类 digraph 中存在非常低 outdegree vertices。虽然是 vertex-connectivity，但“全局 minimality ⇒ 局部低 slack”模式与 frozen flip states 十分接近。  
**Chain:** Mader critical graph theory → C8/A8.  
**ABSTRACT ONLY.**

### C3. Wolfgang Mader
**On Vertices of Degree \(n\) in Minimally \(n\)-Edge-Connected Graphs**  
1995, *Combinatorics, Probability and Computing* 4, 81–95.  
DOI `10.1017/S0963548300001498`.

研究 minimal edge-connectivity 中 degree 恰为 threshold 的 vertices，尤其 odd \(n\)。这是 Yuan–Cai directed analogue 的直接 ancestry。  
**Chain:** Mader minimality → Yuan/Cai.  
**ABSTRACT ONLY.**

### C4. Y. O. Hamidoune
**Sur les sommets de demi-degré \(h\) d’un graphe fortement \(h\)-connexe minimal**  
1978, *C. R. Acad. Sci. Paris Série A* 286, 863–865.

非常 obscure 的 minimal strongly connected digraph semidegree paper；Mader 的 critical-digraph line 后来直接与 Hamidoune 的 conjectures 相连。  
**Chain:** Hamidoune → Mader 1989/1991.  
**SECONDARY CITATION ONLY.**

### C5. B. Bollobás, D. L. Goldsmith, D. R. Woodall
**Indestructive Deletions of Edges from Graphs**  
1981, *JCTB* 30, 263–275.  
DOI `10.1016/0095-8956(81)90043-5`.

标题就很对路：在已有 connectivity \(k\) 的图中，寻找能够删掉而不把 connectivity 降得过多的 edges。不是 orientation，但属于“safe/removable individual physical edge”的早期传统。  
**Chain:** minimal connectivity ↔ removable edges → Mader-style reductions.  
**FULL TEXT FOUND.**

### C6. Toshimasa Watanabe, Akira Nakamura
**Edge-Connectivity Augmentation Problems**  
1987, *Journal of Computer and System Sciences* 35, 96–144.  
DOI `10.1016/0022-0000(87)90038-9`.

是 Frank 1992 和后来的 splitting-off augmentation chain 的重要早期算法前驱。尤其值得从 references 倒挖日本学派 1980s 的 reduction terminology。  
**Chain:** Eswaran–Tarjan → Watanabe–Nakamura → Frank 1992.  
**FULL TEXT FOUND.**

### C7. Guo-Ray Cai, Yu-Geng Sun
**The Minimum Augmentation of Any Graph to a \(K\)-Edge-Connected Graph**  
1989, *Networks* 19, 151–172.  
DOI `10.1002/net.3230190112`.

解决 general multigraph 的 \(K\)-edge-connectivity augmentation；其 references 又往 Mader、Kotzig 和日本 1983 augmentation work 延伸。  
**Chain:** Mader reduction → Frank 1992 → constrained augmentation/splitting.  
**ABSTRACT ONLY.**

### C8. Kapali P. Eswaran, R. Endre Tarjan
**Augmentation Problems**  
1976, *SIAM Journal on Computing* 5, 653–665.  
DOI `10.1137/0205044`.

非常早的 graph/digraph connectivity augmentation paper，包括把 directed graph augment 到 strongly connected。是整个 augmentation literature 的祖先节点之一。  
**Chain:** 1970s augmentation → Watanabe/Cai/Frank.  
**ABSTRACT ONLY.**

### C9. Harold N. Gabow
**Applications of a Poset Representation to Edge Connectivity and Graph Rigidity**  
1991, FOCS 1991, 812–821.  
DOI `10.1109/SFCS.1991.185453`.

给 minimum-cut families 建 poset representation，并把它直接用于提高 edge-connectivity 的 augmentation algorithms。若 blocker hypergraph 需要比 laminar family 更丰富但仍 compact 的表示，这一老工具值得追。  
**Chain:** Picard–Queyranne / DKL → Gabow cut representation → Gabow submodular flow.  
**FULL TEXT LOCATED.**

### C10. A. V. Karzanov, E. A. Timofeev
**Efficient Algorithm for Finding All Minimal Edge Cuts of a Nonoriented Graph**  
1986, *Cybernetics* 22, 156–162; Russian original *Kibernetika* 2, 8–12.

这是 DKL cactus theorem 最早的 algorithmic descendants 之一；Gabow 1991、Naor–Vazirani 1991 都明确引用。对 tight-cut blocker family 的 compact representation 很可能比现代 cactus citation 更接近原始技术。  
**Chain:** DKL 1976 → Karzanov–Timofeev → Gabow / Naor–Vazirani.  
**SECONDARY CITATION / ABSTRACT FOUND.**

### C11. Dalit Naor, Vijay V. Vazirani
**Representing and Enumerating Edge Connectivity Cuts in RNC**  
1991, WADS 1991, LNCS 519, 273–285.  
DOI `10.1007/BFB0028269`.

研究所有 minimum edge-connectivity cuts 的 succinct representation / enumeration，并明确建立在 DKL + Karzanov–Timofeev 上。  
**Chain:** DKL → KT → min-cut representation.  
**FULL TEXT LOCATED.**

### C12. Yefim Dinitz
**The 3-Edge-Components and a Structural Description of All 3-Edge-Cuts in a Graph**  
1993, WG 1992 Proceedings, LNCS 657, 145–157.  
DOI `10.1007/3-540-56402-0_44`.

不是只看 global mincut；它显式给任意 graph 的 **所有 3-edge-cuts** 做结构分类，而且总 cut 数可以 cubic 但 representation 仍 linear-size。对 \(2k+1\) 临界里“min / min+1 cut system”尤其值得比较。  
**Chain:** DKL → connectivity carcass → Dinitz–Nutov min+1.  
**ABSTRACT ONLY.**

### C13. Yefim Dinitz, Alek Vainshtein
**Locally Orientable Graphs, Cell Structures, and a New Algorithm for the Incremental Maintenance of Connectivity Carcasses**  
1995, SODA 1995, 302–311.

这是一个很容易被标题误判而漏掉的 paper：他们引入 **locally orientable graphs**，作为 generalization of digraphs，用来 compactly describe connectivity carcasses 和 cell structures。它不是我们的 orientation problem，但“cut structure 自身需要局部方向信息才能表示”非常有趣。  
**Chain:** Dinitz–Vainshtein carcass → Dinitz–Nutov/Baswana–Pandey.  
**ABSTRACT ONLY.**

### C14. Yoji Kajitani, Shuichi Ueno, Hiroshi Miyano
**Ordering of the Elements of a Matroid Such That Its Consecutive \(w\) Elements Are Independent**  
1988, *Discrete Mathematics* 72, 187–194.  
DOI `10.1016/0012-365X(88)90209-9`.

不是 exchange graph，而是寻找一个 global ordering，使**所有 consecutive windows 均保持 feasibility**。作为“能否把一批变换排出一个全过程都合法的顺序”的老式 formulation 很值得保留。  
**Chain:** old matroid ordering → serial exchange.  
**FULL TEXT FOUND.**

---

# D. WEAK LEADS

### D1. Toshimasa Ishii, Masayuki Hagiwara
**Minimum Augmentation of Local Edge-Connectivity between Vertices and Vertex Subsets in Undirected Graphs**  
2006, *Discrete Applied Mathematics* 154, 2307–2329.  
DOI `10.1016/j.dam.2006.04.017`.

处理 vertex-to-area local connectivity demands；是 Bernáth–Király “dangerous set / splitting gets stuck” 应用链的一部分。  
**Chain:** Frank local requirements → node-to-area augmentation → skew-supermodular splitting.  
**ABSTRACT ONLY.**

### D2. Hiroyoshi Miwa, Hiro Ito
**NA-Edge-Connectivity Augmentation Problems by Adding Edges**  
2004, *Journal of the Operations Research Society of Japan* 47, 224–243.  
DOI `10.15807/jorsj.47.224`.

研究 node-to-area connectivity；重要性主要在于它提供比 pairwise cut demand 更复杂的 set-system testbed。J-STAGE 有开放 PDF。  
**Chain:** local connectivity augmentation → Ishii/Hagiwara → skew-supermodular cover.  
**FULL TEXT FOUND.**

### D3. Attila Bernáth, Tamás Király
**Covering Skew-Supermodular Functions by Hypergraphs of Minimum Total Size**  
2009, *Operations Research Letters* 37, 345–350.  
DOI `10.1016/j.orl.2009.04.002`.

同时覆盖两个 skew-supermodular functions，属于“同时满足多个 blocker systems”的自然邻域。  
**Chain:** Benczúr–Frank → Bernáth–Király splitting.  
**ABSTRACT ONLY.**

### D4. Roland Grappe, Zoltán Szigeti
**Covering Symmetric Semi-Monotone Functions**  
2008, *Discrete Applied Mathematics* 156, 138–144.  
DOI `10.1016/j.dam.2007.09.012`.

semi-monotone functions 是 skew-supermodular 的特殊类，并等价连接到 node-to-area augmentation。对 residual demand 不再全局 nonnegative / 不再 ordinary crossing-supermodular 时，也许可提供一个中间函数类。  
**Chain:** Szigeti/Frank skew-supermodular covering.  
**FULL TEXT FOUND.**

### D5. Zoltán Szigeti
**Edge-Connectivity Augmentation of Graphs over Symmetric Parity Families**  
2008, *Discrete Mathematics* 308, 6527–6532.  
DOI `10.1016/j.disc.2007.11.054`.

minimum \(T\)-cut/parity-family augmentation；主要价值仍是 odd/parity cut structure。  
**Chain:** Frank parity → odd cuts → \(2k+1\)-type phenomena.  
**FULL TEXT FOUND.**

### D6. Tamás Király
**Applications of Eulerian Splitting-Off**  
2007, EGRES TR-2007-01.

用一个 generalized splitting-off theorem 统一多个 connectivity results；可以作为 Lovász/Mader proofs 之外的另一套 admissibility language。  
**Chain:** Lovász Eulerian splitting → Bertsimas–Teo → Király.  
**FULL TEXT FOUND.**

### D7. Tamás Fleiner, András Frank
**A Quick Proof for the Cactus Representation of Mincuts**  
2009, EGRES Quick-Proof 2009-03.

如果 blocker cuts 最后真的能退化成 genuine global mincuts，这个 proof 的 crossing-set handling 很短，可能比 DKL 原证明更容易移植。  
**Chain:** DKL → modern cactus proof.  
**FULL TEXT FOUND.**

### D8. Tamás Király
**Covering Symmetric Supermodular Functions by Uniform Hypergraphs**  
2004, *JCTB* 91, 185–200.  
DOI `10.1016/j.jctb.2003.12.004`.

直接考虑 symmetric crossing-supermodular cut demands；如果 physical edges 最终被视为 size-2 hyperedges，这篇提供另一个 covering interpretation。  
**Chain:** Frank submodular covering → hypergraph orientation/splitting.  
**FULL TEXT FOUND.**

### D9. Shinya Fujita, Ken-ichi Kawarabayashi
**Connectivity Keeping Edges in Graphs with Large Minimum Degree**  
2008, *JCTB* 98, 805–811.  
DOI `10.1016/j.jctb.2007.11.001`.

寻找一条可以安全删除而保持 \(k\)-connectivity 的 edge；虽然 vertex-connectivity 语境不同，但“必须存在一个 safe atomic physical edge”与 flip-exit lemma 的结构相当接近。  
**Chain:** critical connectivity → removable-edge theory.  
**FULL TEXT FOUND.**

### D10. W. Mader
**Connectivity Keeping Paths in \(k\)-Connected Graphs**  
2010, *Journal of Graph Theory* 65, 61–69.  
DOI `10.1002/jgt.20465`.

把“safe vertex/edge”扩大为可以整个删除而保持 connectivity 的 path；更适合作为 macro-operation 与 atomic-operation差异的比较文献。  
**Chain:** critical graphs → connectivity-preserving local deletion.  
**FULL TEXT FOUND.**

---

## 一个很重要但尚未找到原始 publication 的 Lovász lead

Schrijver 的 *Combinatorial Optimization*, Chapter 61 明确写道：

> Frank 的 path/circuit reversal connectivity theorem 可以从 **L. Lovász 的一个结果**推出：两个 \(k\)-arc-connected orientations 在相应 orientation polytope 中相邻，当且仅当二者的差是一个 directed circuit，或一组 vertex-disjoint directed paths。

这条信息对你的问题很重要，因为它把已有 macro theorem 精确放成：

\[
\boxed{
\text{polyhedral adjacency}
=
\text{circuit/path-system reversal}
}
\]

而你的问题其实是在问更细的一层：

\[
\boxed{
\text{这种 macro adjacency / macro path}
\stackrel{?}{\Longrightarrow}
\text{physical one-edge feasible walk}
}
\]

尤其是在 \(\lambda(G)=2k+1\) 的临界 slack 下。

**但我现在没有找到 Lovász 这个 adjacency result 的可靠原始 paper。** 搜到的 Lovász 1973 *Connectivity in Digraphs* 并没有足够证据表明就是它，所以我不会强行把二者合并。当前状态：

**LOVÁSZ POLYTOPE ADJACENCY RESULT — SECONDARY CITATION ONLY / ORIGINAL SOURCE UNIDENTIFIED.**

这应该成为下一轮 citation archaeology 的第一优先级。

---

# NEXT CITATION CHAINS TO FOLLOW

下一轮我会继续沿下面这些线，而不重启：

1. **Schrijver Chapter 61 → Lovász adjacency result**：查 Schrijver bibliography、Frank 1982 原 references、Lovász publication list/technical reports，目标是找出“directed circuit or vertex-disjoint paths = adjacent orientations”的原始出处。

2. **Iwata–Kobayashi 2010 → Gabow 1995 → Gabow 1993 cost-scaling papers → Frank algorithm**：专找 residual operation 到底一次改变多少 orientation coordinates，以及有没有 unit-coordinate feasible pivot lemma。

3. **Farber–Richter–Shank → Li 1998 → basis-pair graph literature**：继续挖 graphic/cographic matroids 中更老的 connectedness/Hamiltonicity results，特别是是否存在“ordered exchange”或 monotone exchange。

4. **White → McGuinness → Bérczi et al.**：追 regular/cographic matroid 中 unique exchange、serial exchange 与 forbidden-minor obstruction。

5. **Mader 1991 → Yuan–Cai 2000 → Yuan–Kang–Cai 2000**：专搜 minimally \(k\)-edge-connected **digraph** 中 removable/deletable arcs、critical cuts、terminal/crossing-free families；重点看 \(2k+1\)、\(2k+2\) 数值是否在别处再出现。

6. **Szigeti admissible-edge → Bernáth–Király dangerous sets → Frank 1992/1993**：继续定位“一个 fixed physical edge 没有 admissible partner”的最早 blocker lemmas。

7. **Gabow 1991 posets → Karzanov–Timofeev 1986 → DKL/Dinitz 1993 → Dinitz–Vainshtein locally orientable carcass**：重点找是否存在适合 simultaneous tight / one-slack cuts 的 cell decomposition，而不是只用 cactus。

8. **Fisher–Fraughnaugh–Langley–West dependent arcs → Edelman predecessor → older acyclic-orientation reversal papers**：追“individual edge reversible iff 不属于某类 certificate”的旧 theorem。

9. **Bouchet/Cunningham jump systems → Lovász jump systems → Kobayashi–Murota**：查 orientation/flow degree-vector systems 是否已经被证明是 jump systems 或 delta-matroids；如果有，这是非常潜在的两步交换框架。

10. **Nash-Williams well-balanced → Király–Szigeti 2004 → Iwata et al. counterexamples**：专找所谓 **smooth \(k\)-arc-connected orientations** 的原始定义、odd pairing 操作及 serialization。

11. **Japanese augmentation chain**：Watanabe–Nakamura → Ueno–Kajitani–Wada 1983 → Miwa–Ito → Ishii/Akiyama/Nagamochi；这条线目前还有不少 1980s 技术报告几乎未被现代搜索收录。

12. **Old safe-operation chain**：Bollobás–Goldsmith–Woodall 1981 → Mader critical digraphs → connectivity-keeping edges/paths；目标是找真正的 directed **removable / reversible individual arc** theorem，而不是 cycle/path macro operations。

这一轮最值得下一步深追的不是新增数量本身，而是 **Lovász adjacency theorem 的原始出处**。如果它有一篇被后来的 Frank/Schrijver 简化引用、但今天几乎搜不到的论文或 unpublished note，那很可能正处在你这个 single-edge serialization 问题的最直接历史上游。

---

# P. 2026-09-30 主档案原文（完整历史保留；若冲突以上文为准）

# 图定向单边翻转重配置研究记录
## 项目总档案｜2026-09-30 综合更新版

> 本版以 `graph_orientation_reconfiguration_progress_2026-09-28(2).md` 为历史底稿，**保留其全文**，并在最前面加入 2026-09-28 之后至 2026-09-30 的全部可恢复进展、有限计算、路线修正、模型状态与新的结构性简化。
>
> 状态标签继续使用：
> - **LOCKED**：项目内部已审计，可直接作为后续起点；
> - **COMPUTATIONAL / EXACT FINITE**：在明确有限域内完整穷举成立，不能升级为一般定理；
> - **PARTIAL / SAMPLED**：只覆盖部分实例或随机样本；
> - **OPEN**：尚未解决；
> - **FALSE / DEAD**：已被明确反例或严格 reduction 杀死，不应复活；
> - **CANDIDATE THEOREM**：当前有完整证明思路，但尚未经过独立项目审计时使用。
>
> 若本页与后附 2026-09-28 档案冲突，以本页为准。

---

# A. 核心问题与当前总判断

设 \(G=(V,E)\) 为 finite loopless undirected multigraph，允许 parallel edges。一个 orientation \(D\) 称为 \(k\)-arc-strong，当且仅当

\[
 d_D^+(X)\ge k
 \qquad
 \forall\varnothing\neq X\subsetneq V.
\]

一次 legal move 是翻转一条 **physical edge**，并要求翻转后仍然 \(k\)-arc-strong。

核心问题：

\[
\boxed{
\lambda(G)\ge 2k+1,
\quad k\ge2
\Longrightarrow
\text{所有 }k\text{-arc-strong orientations 在 legal single-edge flips 下连通？}
}
\]

项目接受的文献 baseline：\(\lambda\ge2k+2\) 时有正结果；真正临界层是 \(2k+1\)。

当前 master framing 仍为：

\[
\boxed{
\textbf{CRITICAL SERIALIZATION OF LEGAL PATH/CYCLE REVERSALS AT }2k+1.
}
\]

截至 2026-09-30，项目经验明显偏向原命题 **TRUE**，但远未达到证明。当前主观概率区间约为

\[
\boxed{85\%\text{--}92\%}
\]

仅作为研究判断，不是数学结论。提高信心的主要原因不是“随机搜不到反例”，而是多种性质不同的反例探测器均持续 negative，同时局部 barrier 已经从 5 增长到 7，却仍未形成 genuine component separation。

当前最重要的经验图景：

\[
\boxed{
\text{local / static obstruction 可以很深，}
\quad
\text{但仍反复存在 dynamic escape。}
}
\]

如果命题为真，证明越来越不像 greedy mismatch-decrease，而像：

\[
\boxed{
\text{F-core}
+\text{ blocker uncrossing}
+\text{ common-edge recharge/release}
+\text{ global serialization / potential}.
}
\]

如果命题为假，当前更期待的反例形状不是一个小 static wall，而是一个可扩展的 **serial-lock / dependency-cycle / no-entry slack-transport gadget**。

---

# B. 2026-09-29 至 2026-09-30 最大新增：n=7, k=2 exact finite search

这一组计算是当前最强的 finite evidence之一。所有以下 “COMPLETE” 都只在给定 finite universe 内成立。

## B1. 精确定义：mismatch-3 blocked-source progress distance

固定 legal orientations \(D,D^\star\)，要求：

1. \(D,D^\star\) 都 2-arc-strong；
2. \(|D\triangle D^\star|=3\)（physical-edge Hamming distance）；
3. source 的三个 mismatch physical edges 都 individually blocked，即单独翻任一条都会离开 legal locus。

定义 progress distance：

\[
\delta(D,D^\star)
=
\min\{\operatorname{dist}_{\rm flip}(D,X):X\text{ legal},\ |X\triangle D^\star|\le2\}.
\]

因为每个 single flip 使 Hamming distance 对固定 target 改变 \(\pm1\)，source mismatch=3，而第一个 correction 被 blocked，所以可能的首次 progress distance 只能是

\[
3,5,7,9,\ldots
\]

这解释了 exhaustive histogram 中偶数层全部为 0。

## B2. M=18：COMPLETE EXHAUSTIVE

参数：

\[
n=7,
\quad k=2,
\quad \lambda\ge5,
\quad M=18.
\]

由 degree sum 与 minimum degree 强迫：

\[
\deg(G)=(6,5,5,5,5,5,5).
\]

underlying graph enumeration checksums：

- degree realizations before \(\lambda\)-filter：747,900；
- labelled \(\lambda\ge5\) graphs：214,430；
- isomorphism classes：372。

完整 search：

- graph classes：372/372；
- total legal orientation states：5,855,322；
- total qualifying ordered pairs：3,897,018；
- distance 3：3,888,130；
- distance 5：8,888；
- 其它 distance：0；
- exact global maximum：
  \[
  \boxed{5}.
  \]

比例：distance 3 约 99.7719%，distance 5 约 0.2281%。

按 graph-class maximum：331 类 max=3，32 类 max=5，9 类没有 qualifying pair。

因此 finite theorem：

\[
\boxed{
M=18\text{ universe 中，blocked mismatch-3 progress radius 恰为 }5.
}
\]

## B3. M=19：COMPLETE EXHAUSTIVE，首次出现 radius 7

参数：

\[
n=7,
\quad k=2,
\quad \lambda\ge5,
\quad M=19.
\]

完整 search：

- graph classes：8,210/8,210；
- total legal states：327,822,940；
- total qualifying ordered pairs：182,369,190；
- distance 3：181,428,442；
- distance 5：940,532；
- distance 7：216；
- exact global maximum：
  \[
  \boxed{7}.
  \]

比例：

- \(d=3\)：约 99.48415%；
- \(d=5\)：约 0.51573%；
- \(d=7\)：约 0.00011844%。

这是一个关键路线修正：

\[
\boxed{
\text{uniform radius-5 progress theorem FALSE.}
}
\]

局部 temporary debt 的深度确实可以随 graph layer 增长。

### M=19 full physical connectivity

随后对全部 8,210 个 underlying graph classes 直接做 legal **physical** single-edge-flip graph connectivity：

\[
\boxed{
\text{8210/8210 全部 connected.}
}
\]

因此得到 exact finite theorem：

\[
\boxed{
 n=7,
 k=2,
 \lambda(G)\ge5,
 |E|=19
 \Longrightarrow
 \text{整个 legal physical flip graph connected.}
}
\]

这直接确认：

\[
\boxed{
\text{progress radius }7\neq\text{ genuine disconnectedness}.
}
\]

## B4. M=20：COMPLETE EXHAUSTIVE progress search

参数：

\[
n=7,
\quad k=2,
\quad \lambda\ge5,
\quad M=20.
\]

完整 search：

- graph classes：75,701/75,701；
- total legal states：7,526,411,290；
- total qualifying ordered pairs：3,313,114,400；
- distance 3：3,295,172,958；
- distance 5：17,928,038；
- distance 7：13,404；
- exact global maximum：
  \[
  \boxed{7}.
  \]

比例：

- \(d=3\)：约 99.45847%；
- \(d=5\)：约 0.54112%；
- \(d=7\)：约 0.00040457%。

因此三层 exact maximum sequence 为：

\[
\boxed{
M=18:5,
\qquad
M=19:7,
\qquad
M=20:7.
}
\]

它杀死了“\(M=19\) 的 7 只是单层偶然”的解释，但仍没有形成 global separation。

### 数据保存警告

原搜索程序的 `records.jsonl` **只保存每个 distance 最多 100 条完整 witness**，总计约 300 条，并没有保存全部 13,404 个 distance-7 pair。已保存的 distance-7 witness 恰好只来自一个 underlying graph；因此不能用 `records.jsonl` 重建全部 hard-7 geometry。

真正的 graph-level hard 区域来自 `per_graph.csv`：共有 38 个 graph classes 的 `maximum_distance=7`。

### 38 个 hard-7 M=20 graph classes

以下 38 类被单独做 full physical connectivity：

| class | legal states | reached |
|---:|---:|---:|
| 1750 | 81,728 | 81,728 |
| 2209 | 77,824 | 77,824 |
| 2365 | 77,824 | 77,824 |
| 8735 | 78,080 | 78,080 |
| 10160 | 77,824 | 77,824 |
| 11912 | 75,968 | 75,968 |
| 13012 | 75,968 | 75,968 |
| 13017 | 71,488 | 71,488 |
| 13077 | 75,328 | 75,328 |
| 13078 | 71,808 | 71,808 |
| 13766 | 73,568 | 73,568 |
| 13874 | 75,328 | 75,328 |
| 14080 | 75,968 | 75,968 |
| 14863 | 75,200 | 75,200 |
| 18436 | 74,912 | 74,912 |
| 18529 | 75,968 | 75,968 |
| 19505 | 76,320 | 76,320 |
| 21917 | 77,056 | 77,056 |
| 22471 | 87,072 | 87,072 |
| 22504 | 77,568 | 77,568 |
| 22515 | 78,080 | 78,080 |
| 25103 | 80,368 | 80,368 |
| 36873 | 74,688 | 74,688 |
| 41415 | 73,568 | 73,568 |
| 41499 | 73,408 | 73,408 |
| 41689 | 74,912 | 74,912 |
| 43318 | 72,736 | 72,736 |
| 43338 | 71,072 | 71,072 |
| 43589 | 72,448 | 72,448 |
| 43637 | 73,408 | 73,408 |
| 43640 | 72,512 | 72,512 |
| 43682 | 73,152 | 73,152 |
| 45836 | 77,824 | 77,824 |
| 45958 | 86,112 | 86,112 |
| 46156 | 74,912 | 74,912 |
| 46872 | 74,688 | 74,688 |
| 49450 | 80,608 | 80,608 |
| 67202 | 76,608 | 76,608 |

结论：

\[
\boxed{
\text{M=20 的全部 38 个 hard-7 underlying graphs 的 physical flip graph 均 connected.}
}
\]

所以“用 progress distance 富集反例候选”的相关性有限：hardest known local barrier graphs 仍全部 global connected。

## B5. M=20 quotient / label-fiber direct counterexample searches

为了更直接证伪，随后转向 quotient dynamics。

### Frozen internal bundle search：COMPLETE NEGATIVE

对全部 75,701 个 M=20 graph classes，搜索 legal quotient component 中是否存在 parallel bundle \(i\)，使

\[
x_i\equiv c,
\qquad
0<c<m_i,
\]

即 internal coordinate 在整个 component 中冻结。

这种情况会固定“哪些 labelled copies 朝参考方向”，从而直接产生 physical disconnectedness。

完整搜索结果：

\[
\boxed{
\text{75,701/75,701：无 frozen internal bundle obstruction.}
}
\]

### Quotient connectivity search：COMPLETE NEGATIVE

对同一完整 M=20 universe，直接检查 legal quotient-state graph connected components：

\[
\boxed{
\text{75,701/75,701 legal quotient graphs 全部 connected.}
}
\]

这一结果与下面的 quotient-to-labelled lifting theorem 结合后，可升级为整个 M=20 physical connectivity finite theorem。

## B6. M=21 / M=22 progress search：仅 PARTIAL

M=21、22 完整 graph-class universe 计算量暴涨，不再适合机械 exhaustive。曾各自做过一段 partial run，总耗时量级约为 M=20 完整 run 的一小部分；已观察 maximum 仍为 7，没有发现 9，但没有保留足够的完整 class accounting 以形成 theorem。

因此只能记：

\[
\boxed{
M=21,22\text{ partial：目前 observed max}=7,
\text{ 但绝不排除后续出现 }9.
}
\]

不要把它升级为 finite theorem。

---

# C. 新的 exact simplification：quotient component 到 labelled physical component

这一点是 2026-09-30 最值得正式吸收的结构简化之一。

对每个 parallel bundle \(i\)，设 multiplicity 为 \(m_i\)，固定一个 reference direction，quotient coordinate 为

\[
x_i\in\{0,1,\dots,m_i\}.
\]

quotient map

\[
\pi:\{\text{labelled orientations}\}\to\prod_i\{0,\ldots,m_i\}
\]

只记录每个 bundle 中有多少条朝 reference direction。\(k\)-arc-strong legality只依赖 quotient state。

## C1. Frozen coordinate 是 genuine label invariant

若在一个 connected legal quotient component \(C\) 中，某个 coordinate 恒等于

\[
x_i\equiv c,
\qquad 0<c<m_i,
\]

则任何 legal physical path 都从不翻 bundle \(i\) 中的任何 edge；因此 reference-directed physical-label subset

\[
L_i(D)\subseteq\{1,\dots,m_i\},
\qquad |L_i|=c
\]

沿路径不变。

所以 preimage 至少分裂成

\[
\binom{m_i}{c}
\]

个 physical components。

## C2. 非冻结 coordinate 可实现任意 cross-transposition

反之，设 \(C\) connected，coordinate \(i\) 在 \(C\) 中不是 constant。固定 base quotient state \(q\in C\)。若 \(q_i\in\{0,m_i\}\)，该 bundle 在 fiber 中只有一个 label pattern，无需处理。

若

\[
0<q_i<m_i,
\]

取从 \(q\) 到某个第一次允许改变 coordinate \(i\) 的 quotient edge 的最短路径：

\[
q=q_0,q_1,\dots,q_t=z,
\]

要求 prefix \(q_0\to\cdots\to q_t\) 不改变 \(i\)，而从 \(z\) 有 legal \(i\)-move。

lift 这个 prefix 到 physical path；因为 prefix 没碰 bundle \(i\)，该 bundle 的 physical label pattern保持原样。

在 \(z\) 做一次 \(i\)-move，然后立刻 reverse quotient move，但第二步选择 bundle 中另一条 physical copy。于是 quotient state回到 \(z\)，却交换了一条 reference-directed copy 与一条 opposite-directed copy。

随后严格沿 prefix 的 reverse path 返回，并对其它 bundle 使用原 physical copies 逆转，就恢复所有其它 label 信息。

因此在 base state \(q\) 的 fiber 中，可以实现 bundle \(i\) 任意一对“正/反” physical copies 的 cross-transposition。

这些 cross-transpositions 生成所有大小为 \(q_i\) 的 label subsets。

## C3. Quotient–Labelled Component Theorem

因此可得到：

\[
\boxed{
\textbf{QUOTIENT–LABELLED COMPONENT THEOREM}
}
\]

设 \(C\) 是 legal quotient graph 的一个 connected component。令

\[
F(C)=\{i:x_i\text{ 在 }C\text{ 中恒定为 }c_i,
\ 0<c_i<m_i\}.
\]

则 \(\pi^{-1}(C)\) 的 physical connected components **恰好**由这些 frozen internal bundles 的 labelled subsets决定，组件数为

\[
\boxed{
\prod_{i\in F(C)}\binom{m_i}{c_i}.
}
\]

特别：

\[
\boxed{
\pi^{-1}(C)\text{ connected}
\iff
C\text{ 中没有 frozen internal coordinate}.
}
\]

因此：

\[
\boxed{
\text{physical legal flip graph connected}
\iff
\text{quotient legal graph connected且无 frozen internal bundle}.
}
\]

这个 theorem 使此前担心的“更复杂 monodromy obstruction”消失：一旦 quotient component 内 coordinate 真正可动，简单的 out-and-back loop 已足以生成 fiber 内任意 label rearrangement。

### C4. 对 M=20 的后果

因为完整 M=20 universe 已证明：

1. 每个 legal quotient graph connected；
2. 无 frozen internal bundle；

所以结合上面 lifting theorem：

\[
\boxed{
 n=7,
 k=2,
 \lambda(G)\ge5,
 |E|=20
 \Longrightarrow
 \text{整个 legal physical flip graph connected.}
}
\]

这是比“38 个 hard-7 classes connected”更强的完整 finite theorem。

---

# D. 新的 degree-vector reduction 与反例筛选器

对 orientation \(D\)，令

\[
p_D(v)=d_D^+(v).
\]

基本恒等式：

\[
\boxed{
 d_D^+(X)=p_D(X)-|E(X)|.
}
\]

所以 legality 只依赖 outdegree vector：

\[
\boxed{
D\text{ legal}
\iff
p_D(X)\ge |E(X)|+k
\quad
\forall\varnothing\neq X\subsetneq V.
}
\]

一次 edge reversal \(u\to v\) 在 degree vector 层投影为

\[
p\mapsto p-e_u+e_v.
\]

因此定义 legal degree-vector graph \(\mathcal P(G,k)\)：

- vertices：所有 realizable legal outdegree vectors；
- adjacency：存在 support edge \(uv\) 且 \(p-e_u+e_v\) 仍 legal。

任何 physical legal flip path 都投影为 \(\mathcal P(G,k)\) 中的 path，所以：

\[
\boxed{
\mathcal P(G,k)\text{ disconnected}
\Longrightarrow
\text{physical legal flip graph disconnected}.
}
\]

这是一个极便宜的 **direct counterexample filter**。

对 fixed \(n\)，degree-vector candidate 数只按 composition polynomial 增长，例如 \(n=7\) 时粗上界

\[
\binom{M+6}{6}.
\]

具体：

\[
M=20:230230,
\quad
M=21:296010,
\quad
M=22:376740.
\]

远小于相应 \(2^M\) orientation space。

## D1. n=8, k=2, 5-regular special collapse

若 \(G\) 5-regular、\(n=8\)、\(M=20\)，则 legal orientation 每个顶点必须有

\[
d^+(v)\in\{2,3\},
\]

且恰好四个顶点 outdegree=3、四个=2。因此 degree vector 只等价于一个 4-subset，总共

\[
\binom84=70
\]

个 potential states。

已经做过若干随机 5-regular \(\lambda\ge5\) multigraph trials；degree-vector graph 均 connected，未见反例。

状态：

\[
\boxed{
\text{SAMPLED NEGATIVE ONLY；不是 theorem。}
}
\]

---

# E. 反例导向的 parallel-heavy random quotient 搜索

为了跳出 \(M\le20\) exact box，又避免 \(2^M\) 爆炸，设计了 parallel-heavy random search：

- \(n=8,k=2\)；
- 先取一个 simple connected / preferably bridgeless support，约 8--10 support edges；
- 独立生成 5 棵 spanning trees \(T_1,\dots,T_5\)；
- 令 \(G\) 为其 multiset union。

于是

\[
M=35,
\]

并且每个 cut 被每棵 spanning tree 至少跨一次，因此自动

\[
\lambda(G)\ge5.
\]

只搜索 quotient state space

\[
\prod_e(m_e+1),
\]

不展开 \(2^{35}\) labelled orientations。

进行了约十几轮 / 多个 seed 的尝试，未发现 disconnected legal quotient graph。

状态：

\[
\boxed{
\text{SAMPLED NEGATIVE；只说明随机 parallel-heavy 候选暂未命中。}
}
\]

如果未来继续证伪，建议不要简单增加 random trials，而是转向 **反向合成小 closed quotient component**，例如直接要求存在 closed \(K_2\)、\(C_4\) 或小 cube component，并让 SAT/ILP/CP-SAT 求 multiplicities + blocker cuts。

---

# F. 模型一｜MIXED-FRAME：最新状态（supersedes 2026-09-28 front page）

模型一负责 dynamic blocker birth / service interaction / pure-partial geometry。

## F1. ENTER-W branch 已关闭

此前 pure-partial witness \(W\) 的 ENTER-W branch 曾是一般图 six-point compression 的 escape。最新 exact analysis 得到：

\[
\boxed{
\textbf{PURE-PARTIAL WITNESS NEUTRALIZATION THEOREM}
}
\]

在严格 hypothesis 下，service edge \(b\)：

- 不能 leave \(W\)；
- 不能 enter \(W\)；
- 因而 \(b\) 对 \(W\) neutral。

进一步强迫

\[
\boxed{K=A_{\widehat Q}(h)\subseteq W.}
\]

所以整个 ENTER-W / service-incidence parent branch CLOSED。

## F2. 当前 surviving pure-partial state

保留：

- \(W\in\mathcal B_Q(h)\)；
- \(f\notin F_h\)；
- \(b\) neutral on \(W\)；
- \(K\subseteq W\)；
- \(L=Y_{\min}(x_1,y_1)\neq\varnothing\)。

对每个 strict \(H\)，tight \(H,W\) 与 \(h\) crossing exclusive wings 强迫

\[
H\cap W=\varnothing
\quad\text{or}\quad
H\cup W=V.
\]

## F3. Triple-atom escape

一般图中 six-point contradiction 的真正 surviving escape 现在定位到 triple atom

\[
T=H\cap L\cap W.
\]

关键 identity：

\[
3k+\beta_L+d_Q^+(T)
=
 d_Q^+(H\cap L)
+d_Q^+(H\cap W)
+d_Q^+(L\cap W)
+d_Q^+(H\cup L\cup W)
+\Gamma_3.
\]

六点模型中 \(T=\varnothing\)，一般图中 \(T\neq\varnothing\) 可以吸收原 contradiction。

当前唯一主任务：

\[
\boxed{
\textbf{TRIPLE-ATOM VERDICT}
}
\]

目标只接受：

- 证明 \(T=\varnothing\)；或
- 给出足够强 strict bound 杀死 \(T\neq\varnothing\)；或
- 构造 actual finite full-hypothesis triple-atom certificate。

scalar feasibility 不算 graph certificate。

---

# G. 模型二｜COUNTEREXAMPLE：sigma=7 当前最深状态

模型二继续 fixed reservoir-interface architecture 的 counterexample / phase-basin 审计。

## G1. 已永久关闭的旧层

- 所有 \(\sigma=6\) feasible patterns arbitrary-hidden universal no-go：CLOSED；
- \(P=(1,2,4)\)：DISJOINT / CO-COVER 两支均 closed；
- \(P=(1,3,3)\)：完整 closed，uniform pattern escape distance \(\le4\)。

其中 \(P=(1,3,3)\) 的 Branch R/A/C 与 maximal-wall closure均已完成；不要重做。

## G2. P=(1,4,2) first exact normal form

retained architecture：

\[
V_0=\{a,b,c,u_a,u_b,u_c,r\}.
\]

当

\[
D_a,D_c,R_b,A_{ba},R_c
\]

全部 source-blocked，exact arbitrary-hidden uncrossing 强迫

\[
\boxed{H,Q,U,P_2\text{ tight}}.
\]

\(D_c\)-wall 必落入：

\[
\boxed{
\text{TYPE K: }K_1\text{ tight}
\qquad\text{or}\qquad
\text{TYPE M: }M\text{ tight}.
}
\]

其中

\[
K_2\text{ tight}\Longrightarrow M\text{ tight}.
\]

又因为 \(Q\) tight，defect release \(E\) automatically blocked。

若进一步 \(L_a\) blocked，则 TYPE K 也被迫进入 TYPE M，所以 deepest mandatory core：

\[
\boxed{H,Q,U,P_2,M\text{ tight}.}
\]

### 数值修正（永久）

旧稿 \(D_c\) table 两项曾写错，正确为：

\[
M=\{a,b,u_a,u_b,r\}:
\qquad
 d_{\rm old}^+(M)=3,
\quad |\delta_{\rm old}(M)|=6;
\]

\[
J=V_0-\{u_c\}:
\qquad
 d_{\rm old}^+(J)=2,
\quad |\delta_{\rm old}(J)|=5.
\]

trace catalogue 与 normal-form conclusions 不变。

## G3. Five branches collapse to two

在 deepest core 下，\(L_a\)-blocker old traces原有五支：

\[
\Lambda_1,\Lambda_3,\Lambda_5,\Lambda_6,\Lambda_7.
\]

exact closure：

\[
\boxed{\Lambda_3\Rightarrow\Lambda_6},
\]

\[
\boxed{\Lambda_5\Rightarrow\Lambda_3\Rightarrow\Lambda_6},
\]

\[
\boxed{\Lambda_7\Rightarrow\Lambda_6}.
\]

并且 \(\Lambda_5\) 还强迫 \(\Lambda_7,P_1\) 等。

所以 deepest arbitrary-hidden problem 从 5 支严格降为 2 个 essential types：

### TYPE I

\[
\boxed{
H,Q,U,P_2,M,\Lambda_1\text{ tight}.
}
\]

### TYPE II

\[
\boxed{
H,Q,U,P_2,M,\Lambda_6\text{ tight}.
}
\]

TYPE II 进一步有 exact geometry：若 expanded shores 为 \(X_M,X_6\)，则

\[
\boxed{X_M\cup X_6=V},
\]

\[
\boxed{d^+(X_M\cap X_6)=4},
\]

\[
\boxed{|E(X_M-X_6,X_6-X_M)|=2}.
\]

这两条 crossing 已全部由 retained old

\[
2\times(r-u_c)
\]

占满，所以 exclusive wings 之间 **不能有任何 hidden edge**。

正式名称：

\[
\boxed{
\textbf{TYPE II = CO-COVER-4 / CROSS-2 NORMAL FORM}.}
\]

当前 sharp OPEN：

1. TYPE II 是否 actual realizable？
2. 若 realizable，其 maximal same-phase basin 是否 closed？
3. 若 TYPE II impossible，再处理 TYPE I。

尚不能写 \(P=(1,4,2)\) CLOSED。

---

# H. 模型三｜SEPARATED-FLOW：OLD-E1 finite closure + F-core 路线

## H1. n=7, M=18 strengthened OLD-E1 complete finite theorem

在整个 strengthened OLD-E1 universe 中，对每个 legal Type-C

\[
D_{\rm pre}\xrightarrow{f}W\xrightarrow{p}D_0
\]

exact exhaustive 得到：

\[
\boxed{
\operatorname{dist}_{\rm legal}
\left(D_0,\{|S|\le2\}\right)
\le3,
}
\]

且 sharp。

核心 census：

- 747,900 labelled degree realizations；
- 214,430 \(\lambda=5\)；
- 372 isomorphism classes fixing unique degree-6 vertex；
- 97,517,568 orientation states；
- 34 graph classes support strengthened exits；
- 11,523 Type-C exits；
- distance 1：9,710；
- distance 2：0；
- distance 3：1,813；
- distance \(\ge4\)：0。

hard 1,813 cases全部具有：

- \(r,q,\bar f\) blocked；
- empty middle blocker regions；
- shell profiles \((1,0,6)\)、\((3,0,4)\)、以及 \((4,0,3)\) 或 \((5,0,2)\)；
- shortest path type统一为
  \[
  \boxed{\text{COMMON RECHARGE}\to\text{CORRECTION}\to\text{CORRECTION}},
  \]
  mismatch evolution
  \[
  3\to4\to3\to2.
  \]

这进一步确认：temporary mismatch debt 是真实机制，不是 proof artifact。

## H2. F-core / minimal-core literature package

在所有 mismatch edges \(F\) blocked 时，取 inclusion-minimal spanning \(k\)-arc-strong subdigraph \(H\subseteq D\)，并要求 \(F\subseteq A(H)\)。项目锁定以下 package：

1. \(H\) minimally \(k\)-arc-connected；
2. 每条 \(g\in D-H\) 相对 target 是 common edge，且 \(H\subseteq D-g\) 仍 \(k\)-strong，因此 \(g\) legal；
3. current tight shore \(X\) 有
   \[
   d_H^+(X)=k=d_D^+(X),
   \]
   所以 \(D-H\) 无 arc leave \(X\)；任何 crossing outside-core edge 必须 enter；
4. Mader-type minimal-core lemma 给 balanced vertex \(v\) with
   \[
   d_H^+(v)=d_H^-(v)=k;
   \]
   在 \(\delta(G)\ge2k+1\) 下，\(v\) 至少 incident 一条 \(D-H\) common legal edge。

## H3. Common full-compensator release

若 blocked mismatch \(e\) 的 canonical partition 为 \(A_e,U_e,C_e\)，而 legal common edge

\[
g:x\to y,
\qquad x\in C_e,
\quad y\in A_e,
\]

则翻 \(g\) 后 \(e\) 立即 legal。因此有 2-step primitive：

\[
\boxed{g\to e.}
\]

如果 outside-core \(g\in D-H\) 同时 crossing \(A_e,U_e\)，minimal-core tightness 强迫它正是 \(C_e\to A_e\) 型 full compensator。

## H4. 当前 symbolic bottleneck

在 hard OLD-E1 states 中，\(M_e=\varnothing\) for \(r,q,\bar f\)，所以 blocker family退化成单一 canonical shore。

当前需要证明：某条 outside-core common legal edge \(g\in D_0-H\) 必命中这些 blocker shores之一，理想上先命中 \(q/r\)，从而形成

\[
g\to q\to r
\quad\text{或}\quad
 g\to r\to\bar f.
\]

若所有 outside-core edges 都避免三张 blocker shore，则 endpoints 必落在相同 membership atom；希望结合 degree sequence

\[
(6,5,5,5,5,5,5)
\]

和唯一 excess unit 推 contradiction。

当前任务：

\[
\boxed{
\textbf{OUTSIDE-CORE BLOCKER-HIT / ATOM-PLACEMENT}.}
\]

---

# I. 模型四｜BARRIER-GLOBAL：full EDP reduction

研究 \(k=2,n=5\) full EDP relaxed-to-strict component问题：

\[
|\delta_H(X)|
\ge
5-\mathbf1_{\{X\text{ separates }a,b\}}.
\]

## I1. complete small window

完整 negative：\(M\le14\) full EDP 中没有 bad component。

## I2. minimal-counterexample structural reductions

对 edge-minimal bad \(H\)：

- 初始 multiplicity cap 降到有限范围；
- saturated 5-class 分析；
- pure 5 support bridge exact Cartesian factorization；
- n\(\le4\) full EDP complete computational base；
- pure-4 \(a\)-\(b\)-separating support bridge factorization并下沉到更小实例。

最终正式 LOCK：任何 minimal bad \(n=5\) instance 可假设

\[
\boxed{m_{uv}\le4\ \forall uv},
\]

\[
\boxed{15\le |E(H)|\le40},
\]

且 simple support graph connected、无 bridge：

\[
\boxed{\lambda(S(H))\ge2.}
\]

所有 support-bridge geometry 永久 CLOSED。

## I3. degree-2 support vertex：固定 product proof 路线被杀

构造 actual full-EDP example：

\[
m=(0,2,2,0,2,2,2,2,2,2),
\quad M=16,
\]

terminal support-degree-2 vertex \(x=a=0\)，core \(H-a=2K_4\)。

固定 core orientation 时 interface fiber 会依赖 core state；存在 fiber completely lacking strict-compatible interface state；virtual distinguished source 还会在 core orientations 间迁移。

因此永久 FALSE：

- degree-2 suppression 给 state-independent interface factor depending only on \((p,q)\)；
- terminal degree-2 deletion 给 fixed distinguished pair；
- 每个 fixed-core relaxed interface fiber 都含 strict-compatible state。

该 example 的 whole relaxed quotient graph仍 connected，所以它不是 bad component，只是杀掉 fixed-product proof route。

当前下一步只研究：

\[
\boxed{
\textbf{NONTERMINAL DEGREE-2 VERDICT}.}
\]

若 nonterminal degree-2 elimination 成立，则 minimal bad support-degree-2 vertices 必只能是 terminals。

---

# J. 模型五｜PARALLEL-QUOTIENT：global extremal beta frontier

## J1. alignment / beta=0 过强机制已被反例击破

存在 exact

\[
k=2,
\quad n=8,
\quad 5\text{-regular},
\quad \lambda=5
\]

fixed-path instance，使

\[
\omega_P=3,
\qquad
\beta(P)=0,
\]

但 right-aligned canonical trace genuine recurrence：

\[
H_A\to\text{one-slack}\to H_A.
\]

因此永久 FALSE：

\[
\boxed{
\beta=0
+\text{ aligned blocker recurrence}
\Longrightarrow
\text{DISJOINT/CO-COVER horizontal bad cell}.
}
\]

alignment 本身不能当 vertical monotonicity mechanism。

当前 explicit path 不是 global \(\Phi\)-minimizer（存在更简单 direct route），所以仍 OPEN：

\[
\boxed{
P^*\text{ global }\Phi\text{-minimal failing simple path}
\Longrightarrow
\beta(P^*)=0\ ?
}
\]

radius\(\le2\) 2-switch exhaustive negative只是 finite evidence，不能升级。

当前唯一任务：

\[
\boxed{
\textbf{GLOBAL EXTREMAL BETA VERDICT}.}
\]

只接受：

- 证明 \(\beta>0\) 可 surgery 成更小 \(\Phi\) path；或
- actual graph + exhaustive all relevant paths，给 failing global minimizer with \(\beta>0\)。

---

# K. 模型六｜GLOBAL 2-IDPS

长期目标：legal degree transfer

\[
p\to p-e_s+e_t
\]

是否总可用至多两个 path intervals serialise。

LOCK：

- global one-interval theorem FALSE；
- box-only width2 theorem；
- regular \(|V|\le6\) global width\(\le2\)；
- \(n=8,k=2\) 5-regular low-slack structure压到 Residual Q / Residual T；
- rigid multi-quad ring exact enumeration无 width3。

当前未解决：

\[
\boxed{
\text{close }n=8,k=2\text{ regular Residual Q/T，或找 first width3 witness}.}
\]

这个方向仍是正向 serialization theorem 的重要 testbed。

---

# L. 模型七｜PHASE-FORK：auxiliary width 最新 finite frontier

## L1. n=6, k=2, lambda=5 complete layers

已经完整得到：

### M=15

- 12,043 5-regular multigraphs；
- 2,233 \(\lambda=5\)；
- 12 isomorphism classes；
- 1,147,440 legal states；
- 15,738,480 cycle instances；
- max auxiliary width：1。

### M=16

- 332,535 candidates；
- 112,845 \(\lambda=5\)；
- 212 iso classes；
- 88,198,200 states；
- 1,208,994,480 cycles；
- aw2 instances：100,800；
- aw\(\ge3\)：0。

### M=17

- 2,533,620 graphs；
- 1,173,465 \(\lambda=5\)；
- 1,898 iso classes；
- 1,486,337,460 states；
- 20,952,325,320 cycles；
- aw2：1,663,560；
- aw\(\ge3\)：0。

### M=18 COMPLETE

- 262,893 sorted-degree multiplicity matrices；
- 125,253 \(\lambda=5\)；
- 9,871 underlying isomorphism classes；
- 6,493,610 labelled graphs；
- 13,322,332,980 legal quotient states；
- 195,059,997,000 feasible ordered cycle instances；

width distribution：

\[
aw0=190,445,543,280,
\]

\[
aw1=4,605,328,800,
\]

\[
aw2=9,124,920,
\]

\[
\boxed{aw\ge3=0.}
\]

aw2 只出现在 cycle length 3/4；length 5/6 在这个 finite universe 中 aw\(\le1\)。non-wall aw2=1,586,160。

因此 finite theorem：

\[
\boxed{
n=6,
\lambda=5,
aw\ge3
\Longrightarrow
|E|\ge19.
}
\]

另有 edge-minimal reduction：\(m_{uv}\ge6\) 可下降，所以 edge-minimal n=6 aw3 可假设 \(m_{uv}\le5\)，故 \(M\le55\)。

## L2. 后续高 M search

曾有 n=6, M=21 computation，总 deterministic case 数约 928，完成约 513 后暂停切换方向。当前没有足够信息把 M=19/20/21 升级为 complete theorem；不要从 partial run 推断 aw3 不存在。

---

# M. 文献模型 A/B/C：已关闭的文献路线与保留工具

## M1. 文献模型 A｜RESTRICTED-EXCHANGE

状态：**LOCKED + KILL**。

保留：

- exact cut identity；
- TWO-MODE BLOCKER RELEASE；
- 2-edge macro blockers 的 DISJOINT / CO-COVER structure。

杀掉 / 不再投入：

- BKV macro path existence 自动给 hidden single-edge refinement；
- generic M-convex exchange 自动 lift 到 physical move；
- inverse perfect-b-matching route 自动给 local prefix。

## M2. 文献模型 B｜ORIENTATION-RECONFIGURATION

状态：**LOCKED + KILL as independent route**。

保留 theorem package：

- Mader-type minimal-core safe/balanced structure；
- target balance；
- F-core construction；
- blocker lattice；
- common full-compensator release。

DEAD：

- universal “\(F\neq\varnothing\Rightarrow\exists e\in F\) legal”；
- 把 DJS / FPS analogy 当完成 proof route。

## M3. 文献模型 C｜AUGMENTATION-UNCROSSING

状态：**PARTIAL + KILL**。

Frank–Király–Király 型存在性 characterization 可能提供背景，但没有找到可直接给 full single-edge refinement 的标准 theorem。

必须永久保持：

\[
\boxed{
\text{“只翻 macro edge set }F\text{ 的 prefix-feasible ordering”}
=\text{ width-0 serialization only},
}
\]

它绝不等价于原问题，因为真实 legal path 可能需要：

- off-\(F\) auxiliary flips；
- temporary mismatch debt；
- repeated flips；
- common-edge recharge。

---

# N. 统一 proof picture：为什么现在更偏向 TRUE

当前最有希望的证明链不是 mismatch greedy，而是如下四层。

## N1. F-core：保证 auxiliary legal common edges 存在

在 target mismatches 全 blocked 时，minimal \(k\)-strong core \(H\) 把真正必要的 arcs 压入 core，外部 \(D-H\) arcs天然形成 legal common resource。

这解决“所有 target corrections 都 blocked 后还有没有 legal move？”：有，且有结构。

## N2. blocker uncrossing：把 arbitrary wall 压成少量 canonical atoms

模型二的连续结果显示：几十个 old-trace witness assignments 经 exact cut closure 往往降成 2--5 个 geometry；模型一、三也反复出现 canonical core / middle / exterior atoms。

希望一般化为：若所有 candidate recharge 都失败，blocker family 必出现极端 laminar / disjoint / co-cover / atom decomposition。

## N3. common-edge release：recharge 再 correction

真正的 local primitive越来越清楚：

\[
\boxed{
\text{COMMON RECHARGE}\to\text{CORRECTION}.
}
\]

甚至更长：

\[
\text{COMMON}\to\text{CORRECTION}\to\text{COMMON}\to\cdots
\]

这就是计算中 radius 5、7 的来源。证明必须允许 temporary Hamming debt，而不能把它视作失败。

## N4. global potential / dependency elimination

目前缺少的是一个真正 global measure。单独使用

\[
|D\triangle D^\star|
\]

肯定不行。

潜在形式应当是 lexicographic / multicomponent：

\[
\Phi(D)=
\bigl(
\text{residual mismatch structure},
\text{blocked dependency complexity},
\text{tight-atom complexity},
\text{auxiliary debt}
\bigr),
\]

允许第一项短期上升，但每个 recharge/correction macro operation 严格减少更高层 dependency structure。

理想 theorem：

\[
\boxed{
\text{整体合法的 path/cycle reversal}
\Longrightarrow
\text{可借助 auxiliary flips serialise 成 legal single-edge path}.}
\]

这仍是整个项目最可能的最终证明形状。

---

# O. 如果原命题为 FALSE：当前最值得寻找的反例结构

当前 finite evidence使以下反例形状变得不太可信：

- isolated legal orientation；
- 一个小 static tight wall；
- 单纯 frozen parallel-label pattern（M=20 complete negative）；
- 单纯 high progress barrier；
- degree-vector disconnectedness 在小随机 regular samples 中直接出现。

如果真有 counterexample，更可能是：

\[
\boxed{
\textbf{closed dependency cycle / serial-lock gadget}
}
\]

也就是多个 blocked corrections 互相需要 slack service，但 service dependency 形成一个没有入口的闭环。

计算上最直接的新方向应是 **反向合成**，不是继续扩大 \(M\)：

1. 规定一个小 closed quotient component，如 \(K_2\)、\(C_4\)、small cube；
2. 对每个 forbidden outgoing move显式分配 tight blocker cut；
3. 用 SAT / ILP / CP-SAT 求 multiplicities、orientation counts、cut equalities；
4. 一旦得到候选，独立 verifier 检查 \(\lambda\ge5\)、所有 legal states与 component closure。

这比继续 M=21/22 exhaustive 更接近 genuine falsification。

---

# P. 最新 FALSE / DEAD / STOP 列表（增量）

除历史档案已有 FALSE 外，新增/强化：

1. **uniform blocked mismatch-3 radius \(\le5\) FALSE**：M=19 exact 有 216 个 distance-7 pairs。
2. “edge density 增加会单调降低 local barrier” FALSE as heuristic：M18 max5，M19/M20 max7。
3. “hard progress-distance graph 很可能就是 disconnected graph”目前无支持：M19 全 8210 connected；M20 全 38 hard-7 graphs connected。
4. “需要复杂 parallel-label monodromy group 才能处理 fiber”不再需要：quotient–labelled component theorem 将 fiber obstruction精确归结为 frozen internal coordinates。
5. 继续 brute-force M21/M22 complete progress census：**低性价比，暂停**。
6. 继续仅随机增加 n=8 degree-vector trials：信息增量低，暂停。
7. 继续仅随机增加 parallel-heavy quotient trials：信息增量低；若恢复，应转 inverse synthesis。
8. P=(1,4,2) five deepest branches 已过时：正式只剩 TYPE I / TYPE II。
9. Model4 terminal degree-2 state-independent product reduction FALSE。
10. Model5 \(\beta=0\)+alignment recurrence \(\Rightarrow\) bad horizontal cell FALSE。

---

# Q. 当前最高价值 OPEN QUESTIONS（2026-09-30）

按理论价值而非模型编号：

## Q1. Global serialization theorem

证明 critical \(2k+1\) 下 macro path/cycle reversal 可通过 auxiliary common flips serialise。

## Q2. F-core blocker-hit theorem

当所有 mismatch blocked 时，minimal core外必有 common legal edge命中某个 blocker core，或“不命中”结构直接 contradiction。

## Q3. Model1 triple atom

\[
T=H\cap L\cap W
\]

能否 actual survive？这是 pure-partial general-graph compression 的当前唯一 escape。

## Q4. Model2 TYPE-II realizability

CO-COVER-4 / CROSS-2 geometry 是否 actual realizable？若不能，\(P=(1,4,2)\) 几乎只剩 TYPE I。

## Q5. Model4 nonterminal support-degree-2 elimination

若成功，将 minimal full-EDP bad instance进一步压到 support minimum degree \(\ge3\) except terminals。

## Q6. Model5 global extremal beta

failing global \(\Phi\)-minimal simple path 是否必 \(\beta=0\)？

## Q7. Model6 Residual Q/T

完成 n=8,k=2 regular 2-IDPS，或找到 first width3 witness。

## Q8. Genuine counterexample synthesis

直接求 closed quotient component / dependency cycle，而不是继续追 radius 9。

---

# R. 当前计算策略建议

## R1. 推荐

- 直接 component search，而不是 barrier proxy；
- quotient state space 优先于 physical \(2^M\)；
- degree-vector graph 作 cheap direct-disconnection filter；
- parallel-heavy graph 可把大 \(M\) 压到较小 quotient state count；
- inverse SAT/ILP synthesis targeted closed component；
- 保存完整 graph-level statistics，不要只保存前 100 witnesses；
- 所有 exhaustive 程序必须有 class-level checkpoint + independent verifier。

## R2. 不推荐

- 机械 M=21,22,23 exhaustive；
- 只扩大 random trials 不改变目标；
- 用 high barrier 当 disconnectedness proxy；
- 只看 records.jsonl 的 capped witnesses 推断 hard graph distribution；
- 让 Codex 同时设计多个 metrics / framework / heuristic；
- 长 prompt 把单一代码任务膨胀成研究软件工程。

## R3. Codex 使用经验

用户本地完整计算通常由用户手动启动。给 Codex 的任务应：

- 一个 prompt 只做一个搜索目标；
- 明确 exact universe / success certificate；
- 只要求写代码、compile、short self-test；
- 明确“不要替我长跑 / 不要等待”；
- 复用已有 verified engine，不无故重写；
- negative sampled run 必须标 SAMPLED，不许写 COMPLETE。

---

# S. Soundness / anti-error rules（当前版本）

必须永久保留：

1. static wall \(\neq\) closed basin；
2. source blocked \(\neq\) globally blocked；
3. sampled negative \(\neq\) theorem；
4. quotient disconnected \(\Rightarrow\) genuine counterexample；
5. quotient connected **单独**不足；但结合 quotient–labelled component theorem，只需再排除 frozen internal bundles；
6. high barrier / high aw \(\neq\) disconnected；
7. small-\(n\) finite \(\neq\) symbolic theorem；
8. labels matter，但 fiber obstruction现已可精确归结为 frozen internal bundles；
9. cut-neutral algebra \(\neq\) legal path reduction；
10. macro legality \(\neq\) serializability；
11. width-0 prefix ordering \(\neq\) original problem；
12. common flip 可增加 mismatch，是 recharge/debt，不应误判为 progress failure；
13. killed conjectures不能换名字复活；
14. finite exact maximum 的提升（5→7）只能杀 local bound，不能自动支持 global false；
15. records/witness caps 与 total counts 必须分开记录。

---

# T. 当前整体评价

现在最有解释力的 finite sequence不是“所有东西越来越简单”，而是：

\[
\boxed{
\text{局部序列化越来越难，global connectivity 仍稳定。}
}
\]

具体：

- M18 blocked mismatch-3 exact radius 5；
- M19 exact radius 7，但 entire physical universe connected；
- M20 exact radius 7；hard-7 38 graphs全部 physical connected；
- M20 entire quotient universe connected且无 frozen internal bundle，因此 entire physical universe connected；
- n8 degree-vector和大-M parallel-heavy random counterexample filters 暂未命中。

这比单纯“小图没反例”更有意义：项目已经明确观察到 temporary debt、recharge、deep local obstruction，却仍然看到全局绕行。

因此当前最合理判断仍是：

\[
\boxed{
\text{原命题更可能为真；真正难点是 global serialization，而不是 static existence。}
}
\]

但风险仍然真实：

- barrier 已经从 5 增至 7；
- 多个 stronger intermediate conjectures连续死亡；
- 尚无一般 global potential；
- 尚不能排除需要很多顶点的 serial-lock gadget；
- k>2 的 direct finite evidence远少于 k=2。

所以项目不应写“接近证明”，而应写：

\[
\boxed{
\text{有限证据明显偏正，但核心一般定理仍缺失。}
}
\]

---

# U. 2026-09-28 之前完整历史档案

以下全文保留原 `graph_orientation_reconfiguration_progress_2026-09-28(2).md`，用于保存所有旧定义、witness、路线、一次性模型、文献搜索、错误修正史与早期有限计算。若历史状态与 A--T 冲突，以 A--T 为准。



---

# 图定向单边翻转重配置研究记录
## 项目总档案（更新至 2026-09-28 10:55 +08:00）

> 本文件以 2026-09-27 的完整项目档案为底稿，并加入 2026-09-27 夜间至 2026-09-28 上午的最新 LOCK / 反例 / exhaustive computation / 路线修正。
> **LOCKED** = 项目内部已复核，可作为后续起点；**OPEN** = 尚未解决；**COMPUTATIONAL** = 只在明确有限域内成立，不能擅自升级。
> 旧档案原文保留在本文件后半部；若与本页更新冲突，以本页更新为准。

# A. 当前总问题

设 \(G=(V,E)\) 为 finite loopless undirected multigraph。orientation \(D\) 为 \(k\)-arc-strong iff

\[
d_D^+(X)\ge k
\qquad
orall\emptyset
e X\subsetneq V.
\]

legal move = reverse one physical edge，结果仍 \(k\)-arc-strong。

核心问题：

\[
oxed{
\lambda(G)\ge2k+1,\ k\ge2
\Longrightarrow
	ext{all }k	ext{-arc-strong orientations connected under legal single-edge flips?}
}
\]

已知 \(\lambda\ge2k+2\) 时成立；临界层 \(\lambda=2k+1\) 仍 OPEN。

当前 master framing：

\[
oxed{
	extbf{CRITICAL SERIALIZATION OF LEGAL PATH/CYCLE REVERSALS AT }2k+1.
}
\]

不要把 high barrier / high auxiliary width / source wall / fixed-path failure 直接当 genuine global disconnection。

# B. 2026-09-28 最新总更新

## B1. 模型一｜MIXED-FRAME

此前 GLOBAL-AC：

\[
oxed{
K\cap A=arnothing
\quad	ext{or}\quad
C\subseteq K.
}
\]

一般图 six-point compression 的真正 escape 是 pure-partial witness \(W\) 的 \(b\)-ENTERS branch。

令

\[
I=A\cap W,\quad
P=A-W,\quad
Q_0=W-A,\quad
O=V-(A\cup W).
\]

ENTER-W 已压成：

\[
b,g:O	o I,\qquad
\eta:I	o Q_0,\qquad
h:Q_0	o O.
\]

另一个 \(\eta:P	o O\) branch 已被 target legality 杀死。

最新 LOCK：

- 第一 circulation：
  \[
  a_{PO}=a_{IP},\qquad a_{Q_0O}=a_{IQ_0}.
  \]
- 使用 \(U=igcup\mathcal H\) 与 \(W\) uncross，得到第二 circulation。
- 第二 circulation 强迫 common physical edge
  \[
  e':Y	o Z.
  \]
- \(h\) 与 \(e'\) 是 distinct \(Q_0	o O\) edges，因此
  \[
  oxed{eta:=a_{IQ_0}=a_{Q_0O}\ge2.}
  \]
- 所以除 \(\eta\) 外存在
  \[
  oxed{e:I	o Q_0,\ e
e\eta,\ e	ext{ COMMON}.}
  \]
- target legality 杀掉 \(f:O	o O\)，故
  \[
  oxed{f:Q_0	o Q_0.}
  \]
- \(K\) cannot BORN；ENTER-W 只剩 OLD-OUT / OLD-IN，MIXED dead。
- OLD-OUT half：
  \[
  oxed{K=O_{
m out}\Rightarrow K\subseteq W.}
  \]
- 唯一 K escape：
  \[
  oxed{K=O_{
m in},\ C\subseteq K.}
  \]

当前最尖锐 OPEN：

\[
oxed{
	ext{forced common }e:I	o Q_0
	ext{ 与 }e':Y	o Z
	ext{ 在 discharge 后能否同时被 external blockers 挡住？}
}
\]

最新 prompt 已发：**TWO FORCED COMMON COMPANIONS: SERVICE OR CONTRADICTION**。新输出前不要重发。

## B2. 模型二｜COUNTEREXAMPLE

fixed reservoir-interface architecture 中六个 feasible \(\sigma=6\) destruction patterns：

\[
(1,2,3),(1,3,2),(1,4,1),(2,2,2),(2,3,1),(3,2,1)
\]

全部 arbitrary-finite-hidden universal no-go。

escape bounds：

\[
(1,4,1)\le2,\quad
(1,3,2)\le3,\quad
(1,2,3)\le2,
\]

\[
(2,2,2)\le2,\quad
(2,3,1)\le3,\quad
(3,2,1)\le2.
\]

正式 LOCK：

\[
oxed{\sigma=6	ext{ CLOSED/FROZEN}}
\]

及仅对该 fixed architecture：

\[
oxed{\sigma_{
m dyn}\ge7.}
\]

Reusable：
- Complement-\(\ge4\) incompatibility；
- trace-persistent release serialization。

最新 prompt 已发：进入 \(\sigma=7\)，先做 exhaustive pattern list、parent transport、OLD-REDUCIBLE、Complement-3 / blocker birth / actual closed basin。新输出前不要重发。

## B3. 模型三｜SEPARATED-FLOW

这是最新几轮中最重要的方向反转。

存在 actual：

\[
oxed{
n=7,\quad |E|=18,\quad \lambda=5
}
\]

graph/source \(D_0\)，同时支持：

1. exact legal length-4 pure one-slack loop；
2. genuine Hamming-distance-2 OLD-E1 predecessor
   \[
   D_{
m pre}=D_0^{p,f}
   \]
   满足 E1–E11；
3. legal target \(D^\star\)；
4.
   \[
   S(D_{
m pre},D^\star)=\{r,p,q\};
   \]
5.
   \[
   oxed{
   F_r=arnothing,\qquad
   m\in M_r,\qquad
   F_p=\{r\}.
   }
   \]

waiting token \(p\) 的唯一 blocker：

\[
\mathcal B_{D_{
m pre}}(p)=\{\{3,5,6\}\}.
\]

因此：

\[
oxed{
(|A_p|,|M_p|,|C_p|)=(3,0,4).
}
\]

proposed universal blocker-size gap
\[
|A_p|\le1	ext{ or }|C_p|\le1
\]
FALSE。

该 witness 甚至落入此前 static T2-Q2 geometry：

\[
(q,t)=(2,2).
\]

length-4 loop 使用 disjoint singleton shores：

\[
X_0=\{0\},\ X_1=\{1\},\ X_2=\{2\},\ X_3=\{3\}.
\]

所以现在可以 LOCK：

\[
oxed{
	extbf{MINIMAL 18-EDGE LENGTH-4 SLACK LOOPS
CAN COEXIST WITH GENUINE OLD-E1 ENDPOINT GEOMETRY}.
}
\]

尚未得到 genuine reduced reentry；真正剩余：

\[
oxed{
D_4\leadsto D_{
m pre}
}
\]

是否存在 prefix-avoiding legal continuation。

最新 prompt 已发：先 reconcile old T2-Q2 theorem exact hypotheses，然后 full \(2^{18}\) labelled legal-state graph、prefix-avoiding BFS、unrestricted distance、reachable 时 full reduced OLD-E1 audit、unreachable 时提取 component-boundary invariant，并比较 quotient vs labelled fiber。新输出前不要重发。

## B4. 模型七｜PHASE-FORK

旧 theorem：

\[
n=5,\ m_{uv}\le3,\ \lambda=5
\Longrightarrow aw\le2
\]

for all feasible simple discrepancy cycles。

最新完成 MULTIPLICITY-5 REDUCTION：edge-minimal \(n=5,aw\ge3\) 中任何 \(m_{uv}=5\) class 必独占 pure 5-bundle mincut，等价为 simple support graph 的 multiplicity-5 bridge。

\(n=5\) pure-five-bundle geometry 完整分类：
1. one pendant leaf；
2. two separate pendant leaves；
3. length-2 pendant chain。

建立 LEAF FIVE-BUNDLE PRODUCT LEMMA：删去 pendant 5-bundle leaf 得 \(H\)，则

\[
\lambda(H)\ge5,
\]

且

\[
L(G,2)=L(H,2)	imes\{2,3\},
\qquad
Q(G,2)\cong Q(H,2)\square K_2,
\]

并对 cycle \(C\subseteq H\)：

\[
aw_G(C)\le aw_H(C).
\]

新增 complete small-core census：

\[
oxed{
n=4,\ m_{uv}\le4,\ \lambda\ge5
\Longrightarrow aw\le1
}
\]

for all feasible simple cycles；

\[
oxed{
n=3,\ m_{uv}\le4,\ \lambda\ge5
\Longrightarrow aw=0.
}
\]

因此 theorem-level：

\[
oxed{
	ext{edge-minimal }n=5,\ aw\ge3
\Longrightarrow
m_{uv}\le4.
}
\]

所以 \(m=5\) 永久 DEAD。

当前唯一 \(n=5\) frontier：

\[
oxed{\max m_{uv}=4.}
\]

而每个 hypothetical edge-minimal \(m=4\) class 必满足：

TYPE 4A：
\[
oxed{4+1}
\]
size-5 minimum cut；

或 TYPE 4B：
off-cycle balanced \(2/2\)，无 4+1 protection，但 opposite 2-tight blockers \(A,B\) 存在且
\[
oxed{A,B	ext{ disjoint or co-cover}.}
\]

最新 prompt 已发：**complete the entire \(n=5,m\le4\) all-cycle universe**。新输出前不要重发。

# C. 其它数字模型当前状态

## 模型四｜BARRIER-GLOBAL
LOCK：deficit lattice / one-flip strictification / deficit migration / side-shield framework；bare relaxed-to-strict FALSE；full edge-deletion-profile case OPEN。

active prompt 已发：
\[
oxed{	ext{SIDE-SHIELD RECURSION: PROVE ESCAPE OR CLOSED CAGE}.}
\]

## 模型五｜PARALLEL-QUOTIENT
LOCK：literal reroute definition导致 graph complete；proper reroute可 disconnected；raw \(eta=0\) 不保证 success；trace recurrence存在；causal locality；connector stub 不是 actual connector。

active prompt 已发：
\[
oxed{	ext{RAW-BETA EXTREMALITY VERDICT}.}
\]

## 模型六｜GLOBAL 2-IDPS
LOCK：global one-interval FALSE；regular \(|V|\le6\) width \(\le2\)；\(n=8,k=2\) regular 压到 Residual Q/T；rigid multi-quad exact no width3。

active prompt 已发：关闭 \(n=8,k=2\) regular residual Q/T，或找 first width3 witness。

# D. 真实 CPU 搜索状态

本地机器：
- Intel Core Ultra 5 125H；
- 18 logical threads；
- 32 GiB RAM；
- Windows 11；
- Python 3.14.3；
- 8 workers 在 Step 1.5 benchmark 中最好；
- optimized fastcore 对 K6,k=2 完整 component computation 比 reference 约快 99×。

Step 1/1.5：reference + fastcore differential testing 全通过。

## n=5 quotient-disconnection
\[
n=5,\ k=2,\ \lambda\ge5,\ 13\le|E|\le18.
\]

raw multiplicity tuples：
\[
12,476,464.
\]

canonical \(\lambda\ge5\) graphs searched：
\[
10,516.
\]

未发现 disconnected legal quotient graph。

暂记：
\[
oxed{
n=5,k=2,\lambda\ge5,13\le|E|\le18:
	ext{ no quotient-disconnection in completed box.}
}
\]

但 run 曾在 \(M=18\) 剩4 tasks时退出，后 checkpoint resume 完成；若发表级使用，建议另做 task-accounting completeness audit。

## n=6 150-minute exact quotient search
目标：
\[
n=6,\ k=2,\ \lambda\ge5.
\]

完整 negative layers：
\[
oxed{M=15,16,17,18,19.}
\]

\(M=20\)：
\[
oxed{212/560	ext{ deterministic tasks complete}.}
\]

因此 \(M=20\) 只能记 PARTIAL。

若继续 CPU：优先 resume M=20，不重写 engine。

注意始终保持：
\[
	ext{quotient disconnected}\Rightarrow	ext{ genuine counterexample},
\]
但
\[
	ext{quotient connected}
ot\Rightarrow	ext{ full labelled connectivity theorem}.
\]

# E. 当前优先级

1. 模型三：explicit 18-edge positive seed full-state BFS。
2. 模型一：two forced common companions；service or external-blocker cage。
3. 模型七：complete \(n=5,m\le4\) all-cycle finite closure。
4. 模型二：\(\sigma=7\) first genuinely new dynamic mechanism。
5. 模型四：EDP side-shield recursion。
6. 模型五/六：serialization / width2 positive route。

# F. 严格评价规则

用户要求降低对结构性猜测的评价。

\[
oxed{
	ext{LOCKED ADVANCE}
>
	ext{PARTIAL ADVANCE}
>
	ext{STRUCTURAL REFORMULATION}
>
	ext{NO REAL ADVANCE}.
}
\]

真实推进通常必须是：
- fully proved theorem/lemma 且 materially narrows gap；
- exact branch closure；
- exact counterexample killing conjecture；
- complete finite exhaustive classification；
- exhaustive computation ruling out precise finite region；
- genuine component/counterexample certificate；
- rigorous reduction to strictly smaller core。

不算：
- terminology；
- heuristic；
- sampled negative；
- possible cage；
- giant case table 无 branch closure；
- 用新 conjecture替旧 conjecture；
- 仅扩大搜索规模。

Prompt 风格：
\[
oxed{	ext{PROVE IT / KILL IT / PRODUCE A CERTIFICATE}.}
\]

# G. 协调工作流

数字模型 1–7 持续迭代；字母 A–E one-shot/frozen。

新数字模型输出到来时：
1. 识别 tag；
2. 对照上次 prompt；
3. 严格评分；
4. 简短解释新 LOCK / FALSE / OPEN；
5. 发下一 prompt；
6. prompt 只能在一个 fenced `text` code block；
7. 第一行必须 exact model tag；
8. 不重发已发送 prompt；
9. duplicate output 只指出 duplicate；
10. 用户偏好 audit 短、prompt aggressive。

截至本文件生成，1–7 均有 active prompt，任何模型在新输出前都不要重发。

# H. 最新新增 FALSE / DEAD

1. “所有 minimal 18-edge length-4 loops 都不兼容 OLD-E1 endpoint” FALSE。
2. universal blocker-size gap
   \[
   |A_p|\le1	ext{ or }|C_p|\le1
   \]
   FALSE；actual 有 \((3,0,4)\)。
3. “OLD-E1-compatible slack loop 必须 \(|E|\ge19\)”在 endpoint/static compatibility 意义下 FALSE。
4. ENTER-W \(eta=1\) DEAD；必须 \(eta\ge2\)。
5. ENTER-W \(f:O	o O\) DEAD；只剩 \(f:Q_0	o Q_0\)。
6. ENTER-W K BORN / MIXED DEAD。
7. 模型七 multiplicity-5 DEAD；edge-minimal n=5 aw3 只需 \(m\le4\)。

# I. 当前经验判断

不要当 theorem，但项目经验仍偏向原命题 TRUE：
- local/static cages反复出现 dynamic exits；
- degree-vector layer强烈表现 connected；
- small exact quotient searches持续 negative；
- service / filtration 往往能处理 blockers。

但风险仍大：
- 很多 stronger intermediates 被反例打掉；
- temporary support complexity 可高；
- actual length-4 loop + genuine OLD-E1 endpoint 已经同时存在；
- 尚无 global potential / global serialization theorem。

因此不要在对用户的评价中写“快证明了”。

# J. 旧项目档案原文（2026-09-27）

以下保留用户提供的上一版完整项目档案作为历史背景。若与上文冲突，以上文最新更新为准。

---

# 图定向单边翻转重配置研究记录
## 项目总档案（截至 2026-09-27）

> 这是一份研究资料，不是 prompt。目标是尽可能完整地保存此前多模型协作中已经出现的定义、路线、定理、反例、有限枚举、失败 conjecture、模型分工、文献启发与当前开放问题。
>
> 记号约定：**LOCKED** 表示项目内部已经反复复核、后续模型原则上不再重做；**OPEN** 表示仍未解决；**COMPUTATIONAL EVIDENCE** 表示只在明确有限域或样本中成立，不能擅自升级成一般定理。
>
> 少量最早期内容只以图片或中间 prompt 形式出现，当前并非逐字保存。因此本文尽量重建“已经被项目吸收的结论”，对未保留的细节不作伪补全。

---

# 1. 原始研究问题

设 \(G=(V,E)\) 是有限 loopless undirected multigraph，允许平行边。给 \(G\) 一个 orientation \(D\)。对非空真子集 \(X\subset V\)，记

\[
d_D^+(X)
\]

为从 \(X\) 指向 \(V\setminus X\) 的弧数。称 \(D\) 为 \(k\)-arc-strong，当且仅当

\[
d_D^+(X)\ge k
\qquad
\forall\emptyset\neq X\subsetneq V.
\]

一次 **legal single-edge flip** 是反转一条 physical edge，同时要求反转后的 orientation 仍然 \(k\)-arc-strong。

项目核心问题是：

\[
\boxed{
\lambda(G)\ge 2k+1,\quad k\ge2
}
\]

时，所有 \(k\)-arc-strong orientations 是否在 legal single-edge flips 下连通？

已知在更强阈值

\[
\lambda(G)\ge2k+2
\]

下连通性成立。真正困难的是临界层

\[
\boxed{\lambda(G)=2k+1.}
\]

整个项目的最终目标就是：证明这个临界阈值仍保证 flip connectivity，或者找到 genuine counterexample。

---

# 2. 基本记号与状态语言

## 2.1 mismatch set

固定当前 orientation \(D\) 和目标 orientation \(D^\star\)。定义

\[
S=S(D,D^\star)
=
\{e\in E:\ D(e)\neq D^\star(e)\}.
\]

- \(e\in S\)：mismatch；
- \(e\notin S\)：common edge。

重要 bookkeeping：

- 翻一条 mismatch 到 target 方向：
  \[
  |S|\downarrow1;
  \]
- 翻一条 common edge：
  \[
  |S|\uparrow1.
  \]

因此为了“服务 blocker”暂时翻 common edge，通常是在制造 temporary mismatch debt，而不是直接减少 mismatch 数。

## 2.2 blocked mismatch 与 blocker family

若 mismatch

\[
e=u\to v
\]

当前不能合法 flip，则必存在 tight shore

\[
u\in X,\qquad v\notin X,\qquad d_D^+(X)=k.
\]

定义

\[
\mathcal B(e)
=
\{X:u\in X,\ v\notin X,\ d_D^+(X)=k\}.
\]

进一步定义

\[
A_e=\bigcap\mathcal B(e),
\qquad
U_e=\bigcup\mathcal B(e),
\]

\[
M_e=U_e\setminus A_e,
\qquad
C_e=V\setminus U_e.
\]

直觉：

- \(A_e\)：所有 blockers 的公共核心；
- \(M_e\)：blocker family 的 middle band；
- \(C_e\)：所有 blockers 都排除的外部区域。

后续很多动态结果都是围绕

\[
A\uparrow,\quad M\downarrow,\quad C\text{ fixed}
\]

展开。

## 2.3 full mismatch compensators

对 blocked mismatch \(e\)，定义

\[
F_e
=
S\cap E_D(C_e,A_e).
\]

这是从 blocker 外侧 \(C_e\) 直接进入核心 \(A_e\) 的 mismatch arcs。

早期对 full-compensator digraph 的研究得到 terminal-SCC reduction、pair-balanced core 的代数剥离等结构，从而把 residual mismatch core 压到很小。

## 2.4 quotient state

对每个 parallel class \(C\)，记某一固定方向上的边数为 \(x_C\)。一个 orientation 由整数向量

\[
x=(x_C)
\]

的 quotient state 表示。

一个关键 LOCKED 结论是：

\[
\boxed{
k\text{-arc-strong legality只依赖 quotient counts，}
}
\]

不依赖同一 parallel class 内 physical labels 的具体排列。

于是定义 quotient graph \(Q(G,k)\)：

- vertices：所有 legal quotient states；
- edges：一个坐标 \(\pm1\)，对应翻一条 physical edge，且结果仍 legal。

quotient disconnected 立即给 genuine orientation reconfiguration counterexample。

## 2.5 quotient \(L^1\) 与 barrier

定义 ambient quotient \(L^1\)：

\[
d_{\rm amb}(x,y)=\sum_C|x_C-y_C|.
\]

legal quotient graph shortest-path metric 另记
\[
d_{\rm flip}(x,y)=\operatorname{dist}_{Q(G,k)}(x,y).
\]
以下 barrier 使用 \(d_{\rm amb}\)；历史 \(d_1\) 与 Slack-Token 旧 \(d_Q\) 的 ambient 含义统一到此记号。

定义

\[
\beta_Q(x,y)
=
\min_P
\left[
\max_{z\in P}d_{\rm amb}(z,y)-d_{\rm amb}(x,y)
\right].
\]

它测量 legal path 被迫“暂时离目标更远多少”。项目已经明确：

\[
\boxed{
\text{high barrier}\neq\text{disconnectedness}.
}
\]

所以 barrier 可以很高甚至无界，但仍不能单独证明反例。

## 2.6 degree-vector formulation

对 orientation \(D\)：

\[
p_D(v)=d_D^+(v).
\]

有恒等式

\[
d_D^+(X)=p_D(X)-|E(X)|.
\]

因此 legality 等价于

\[
\boxed{
p(X)\ge |E(X)|+k
\qquad
\forall\emptyset\neq X\subsetneq V.
}
\]

考虑 abstract transfer

\[
p\mapsto p-e_u+e_v.
\]

它 legal 当且仅当每个 \(p\)-tight shore 若包含 \(u\)，也包含 \(v\)。

定义 tight preorder

\[
u\preceq_p v
\iff
p-e_u+e_v\text{ legal}.
\]

这个 preorder 后来成为模型五、六研究 path realization / macro serialization 的基本语言。

---

# 3. 早期全局结构 reduction

## 3.1 cut-neutral mismatch core

若 mismatch 子集 \(C\subseteq S\) 对所有 cuts 的净贡献都为 0，则其 directed discrepancy core 是 Eulerian。项目得到：

\[
\boxed{
\text{cut-neutral}
\iff
\text{mismatch core directed Eulerian}.
}
\]

若

\[
S=C\sqcup T
\]

且 \(C\) cut-neutral，则 target legality 的 cut algebra 只依赖 residual \(T\)。

但必须一直保留警告：

\[
\boxed{
\text{cut-neutral reduction不是 legal-path reduction。}
}
\]

也就是说，可以代数上忽略 \(C\)，但不能自动把 \(C\) 先单独翻掉。

## 3.2 residual size 1 / 2

若 residual mismatch size

\[
|T|=1,
\]

则“target legal + 当前 mismatch blocked”不可能同时成立。

若

\[
|T|=2,
\]

且两条都 blocked，则它们必须互为 full compensators。

所以真正非平凡 residual 进入

\[
|T|=3.
\]

## 3.3 Residual Triple Normal Form

设

\[
T=\{f,g,h\},
\]

三条都 blocked，target legal，并处于 pure-partial：

\[
F_f\cap T
=
F_g\cap T
=
F_h\cap T
=
\varnothing.
\]

经过 relabel，可以写成唯一 canonical triangle relay：

\[
g:C_f\to M_f,\qquad h:M_f\to A_f,
\]

\[
h:C_g\to M_g,\qquad f:M_g\to A_g,
\]

\[
f:C_h\to M_h,\qquad g:M_h\to A_h.
\]

定义

\[
V_0=A_f\cap M_g\cap C_h,
\]

\[
V_1=C_f\cap A_g\cap M_h,
\]

\[
V_2=M_f\cap C_g\cap A_h.
\]

则

\[
f:V_0\to V_1,\qquad
g:V_1\to V_2,\qquad
h:V_2\to V_0.
\]

这就是 **Residual Triple Normal Form**。它主要来自 blocker/target legality algebra，本身不依赖 \(\lambda=2k+1\)。

---

# 4. Core-Entrant Filtration

这是模型一、三长期使用的核心动态工具。

设 waiting mismatch \(e\) blocked，old canonical core 为 \(A_e\)。翻一条 legal common entrant \(g=x\to y\)。

如果 tail \(x\) 在不同区域：

### 4.1 \(x\in A_e\)

没有真正的 filtration 改变。

### 4.2 \(x\in M_e\)

则

\[
A_{\rm new}\supsetneq A_{\rm old},
\]

\[
M_{\rm new}\subsetneq M_{\rm old},
\]

\[
C_{\rm new}=C_{\rm old}.
\]

即

\[
\boxed{
A\uparrow,\quad M\downarrow,\quad C\text{ fixed}.
}
\]

### 4.3 \(x\in C_e\)

所有 current blockers 被打掉：

\[
\mathcal B_{\rm new}(e)=\varnothing.
\]

waiting mismatch 立即 legal。

这后来成为模型三 Tight-Q entrant route 的核心 operational mechanism。


---

# 5. 模型一｜MIXED-FRAME：动态 blocker birth/death

模型一长期任务是研究：

\[
\boxed{
\text{safe service flips 在帮助当前 blocker 时，
是否会伤害 remote ancestor？}
}
\]

最初曾希望存在强 monotonicity：safe entrant 只会让 blocker geometry变好。这个希望后来被 genuine counterexample pattern 击破。

## 5.1 Exact Birth Criterion

设 waiting mismatch

\[
a=x\to y
\]

在 \(D\) 中 blocked。

翻 safe common edge

\[
b=u\to v
\rightsquigarrow
v\to u.
\]

一个 shore \(X\) 在翻之前不是 blocker、翻之后成为新的 \(a\)-blocker，当且仅当

\[
x\in X,\qquad y\notin X,
\]

\[
d_D^+(X)=k+1,
\]

\[
u\in X,\qquad v\notin X.
\]

也就是说：

\[
\boxed{
\text{birth = old one-slack shore 被 leaving flip 压成 tight}.
}
\]

这把 dynamic blocker birth 从模糊现象变成了 exact cut event。

## 5.2 相对 canonical core 的分类

记 old core

\[
K=A_D(a).
\]

对 safe common flip \(b=u\to v\)：

### enters \(K\)

\[
u\notin K,\quad v\in K.
\]

则 birth-free。若 \(a\) 仍 blocked，core 扩大，或者 \(a\) 被打开。

### internal to \(K\)

\[
u,v\in K.
\]

这是唯一可能制造 **harmful birth** 的情况。

若 newborn blocker \(X\) 出现，则有：

\[
d_D^+(K\cap X)=k+1,
\]

\[
d_D^+(K\cup X)=k,
\]

\[
E(K-X,X-K)=\varnothing.
\]

并且

\[
A_{D'}(a)\subsetneq K,
\qquad
U_{D'}(a)=U_D(a).
\]

所以 harmful internal birth 的 effect 是

\[
\boxed{
A\downarrow,\quad U\text{ fixed}.
}
\]

### external to \(K\)

birth 可以出现，但 newborn blockers 都包含 old \(K\)，不会造成 core shrink。

### leaves \(K\)

不能是 legal flip。

## 5.3 generic ancestor monotonicity FALSE

模型一构造了 genuine

\[
k=2,\qquad G=K_6,\qquad\lambda=5
\]

remote harmful birth pattern。

存在 waiting chain

\[
e_0=1\to2,\quad
e_1=2\to3,\quad
e_2=3\to1,
\]

以及 safe common

\[
b=1\to0.
\]

翻 \(b\)：

- 对 child \(e_2\) 是有利 entrant；
- 对 ancestor \(e_0\) 却制造 newborn blocker
  \[
  X=\{1\}.
  \]

ancestor core 从

\[
V-\{2\}
\]

shrink 到

\[
\{1\}.
\]

因此

\[
\boxed{
\text{“safe service 不伤 ancestor”是 FALSE。}
}
\]

这同时杀掉了 generic signed/co-cover laminar dynamic stability 等过强想法。

## 5.4 harmful birth 可能是 transient debt

在上面的 \(K_6\) 例子中，birth 后 child \(e_2\) 变 safe。

随后翻 child

\[
3\to1
\rightsquigarrow
1\to3
\]

会进入 newborn blocker \(X=\{1\}\)，使

\[
d^+(X):2\to3.
\]

于是 newborn blocker立即死亡。

所以 observed mechanism 更像

\[
\boxed{
\text{service flip 制造 blocker debt，
child correction 再偿还 blocker debt。}
}
\]

因此模型一的研究重点从“证明不会 birth”转成：

- blocker lifetime；
- immediate pairing；
- finite descendant pairing；
- birth stack / LIFO；
- service swap。

## 5.5 Blocker Lifetime Lemma

若当前 \(X\) tight：

\[
d^+(X)=k,
\]

则任何 legal flip：

- leaves \(X\)：不可能，因为会 \(k\to k-1\)；
- internal / external：保持 tight；
- enters \(X\)：使 \(k\to k+1\)，杀死 \(X\)。

因此 newborn blocker 一旦出生，在死亡前：

\[
\boxed{
\text{future legal flips不能 leave 它；
只能 survive 或被 entrant kill。}
}
\]

## 5.6 当前 OPEN

模型一现在真正的问题是：

\[
\boxed{
\text{harmful birth 是否最终必被 descendant correction 偿还？}
}
\]

尤其在 genuine pure-partial residual triangle 中：

- Immediate Pairing 是否成立？
- child correction 不 kill newborn blocker 时，later descendant 是否一定 kill？
- newborn blockers 是否形成严格 containment stack？
- 是否存在 service swap
  \[
  b,\ c,\ b^{-1}
  \]
  这样的 local primitive？

如果 FALSE，需要第一个 persistent pure-triple birth witness；这可能是非常重要的 dynamic obstruction。

---

# 6. 模型三｜SEPARATED-FLOW：tight-Q entrant 与 extremal hard-stop elimination

模型三长期负责：

\[
\boxed{
\text{在 }n=7,\ |E|=18,\ \lambda=5
\text{ extremal residual setting 中，
能否把 mandatory entrants 全部 blocked？}
}
\]

它的主要工具是 exact cut/degree ledger、shield classification 与 degree starvation。

## 6.1 extremal degree sequence

在

\[
n=7,\qquad |E|=18,\qquad \lambda\ge5
\]

下，degree sum 是 36，而每点 degree 至少 5。

因此 degree multiset 必为

\[
\boxed{
(6,5,5,5,5,5,5).
}
\]

全图只有一个 degree-excess unit。

这条事实是模型三大量 contradiction 的核心资源。

## 6.2 middle-band blocker impossible

对 promoted tight chunk \(Q\) 的 blocked mandatory entrant，经过 side-separation 后 blocker 只能是：

- lower shield；
- upper shield。

middle-band blocker 被一般 theorem 排除。

因此 hard-stop test 可以穷尽到 lower / upper 两类。

## 6.3 \(t=2, |Q|=2\)

早期已经严格得到

\[
\boxed{
|Q|=2,\quad t=2
\Longrightarrow
\text{safe mandatory entrant exists}.
}
\]

## 6.4 \(t=2, |Q|=3\) 完整 closure

这一步曾分很多 case：

- shared lower；
- shared upper；
- LU；
- LL；
- UU；
- lower-shield rigidity。

最终得到 general lower-shield rigidity：

\[
\boxed{
\text{every lower shield }L=\{a\}.
}
\]

upper side则通过 capacity/tax + degree starvation 全部排除。

典型 upper 机制：

- upper complement \(K\subsetneq Q\) 满足
  \[
  d^-(K)=2;
  \]
- \(\lambda=5\) 强迫
  \[
  |E(K,Q-K)|\ge3;
  \]
- forced orientations 很快使某个 degree-5 vertex 满足
  \[
  d^+\le1
  \quad\text{或}\quad
  d^-\le1,
  \]
  与 2-arc-strong 冲突。

最终：

\[
\boxed{
|Q|=3,\quad t=2
\Longrightarrow
\text{safe mandatory entrant exists}.
}
\]

## 6.5 \(t=2, |Q|=4\) 完整 closure

这是模型三最新的一次大推进。

在 \(q=4\)：

\[
V=Q\dot\cup\{c\}\dot\cup R,
\qquad
|R|=2.
\]

而

\[
a,m\in C_p\subseteq R.
\]

所以：

\[
\boxed{
R=C_p=\{a,m\},
}
\]

并且

\[
\boxed{
M_1=\varnothing.
}
\]

即第一次 filtration 后 middle band 已经完全清空，是 terminal filtration layer。

exact ledger：

\[
|\delta(Q)|=6,
\]

\[
e_Q=7,
\]

\[
e_{V-Q}=5,
\]

\[
\deg(Q)=\{5,5,5,5\},
\]

\[
d(c)=d(a)=5,
\qquad
d(m)=6.
\]

两条 mandatory entrants 的 tail pattern只能是

\[
(m,m)
\]

或

\[
(a,m).
\]

所以至少有一条 tail 是 \(m\)。

lower shield 完全分类：

\[
\boxed{
L=\{a\}
}
\]

是唯一可能 lower shield。

因此 \(m\)-tail entrant 不可能 lower-blocked。

更强的是 q=4 upper side建立 canonical tight subshore：

\[
J=B^+\cap Q.
\]

通过 \(B^+\) 与 promoted shore \(A_1\) 的 union/cut identity，得到：

\[
d^+(J)=2,
\]

并把所有 \(Q-R\) incidences 强迫进入 \(J\)。

之后对 upper complement \(K\subsetneq Q\) 的 size \(1,2,3\) 全部分类，全部 contradiction。

得到：

\[
\boxed{
\textbf{q=4 UPPER-SHIELD NONEXISTENCE}.
}
\]

所以每条 \(m\)-tail mandatory entrant 都 safe。

最终：

\[
\boxed{
|Q|=4,\quad t=2
\Longrightarrow
\text{safe mandatory entrant exists}.
}
\]

## 6.6 feasible \(q\)-range exhaustive

route-level audit：

\[
V=Q\dot\cup\{c\}\dot\cup R,
\qquad
|V|=7,
\]

所以

\[
|R|=6-|Q|.
\]

又有 distinct

\[
a,m\in R,
\]

故

\[
|Q|\le4.
\]

另一方面 filtration 后

\[
x,s\in Q,\qquad x\neq s,
\]

所以

\[
|Q|\ge2.
\]

因此：

\[
\boxed{
|Q|\in\{2,3,4\}
}
\]

是 exhaustive range。

于是此前 q=2,3,4 三个 closure 可以正式包装成：

\[
\boxed{
\textbf{COMPLETE \(t=2\) TIGHT-Q ENTRANT LEMMA}
}
\]

即

\[
\boxed{
t=2
\Longrightarrow
\exists\text{ safe mandatory entrant}.
}
\]

因此整个 \(t=2\) local hard-stop layer 已经死亡。

## 6.7 但整个 E1 route 尚未关闭

一般 ledger：

\[
|\delta(Q)|=t+4,
\]

\[
d^+(Q)=2,
\]

所以

\[
d^-(Q)=t+2.
\]

同时：

\[
|\delta(R)|=t+3,
\]

\[
d^+(R)=t+1.
\]

结合 degree sum、parity、outdegree capacity，得到 arithmetic survivors：

\[
t\in\{2,3,4\}.
\]

删除已经关闭的 \(t=2\) 后，剩：

\[
\boxed{
t=3:
(q,\varepsilon)
=
(2,1),(3,0),(4,1)
}
\]

和

\[
\boxed{
t=4:
(q,\varepsilon)
=
(3,1),(4,0).
}
\]

所以真正 next hard layer 是：

\[
\boxed{t=3.}
\]

## 6.8 被修正的 progress-measure bookkeeping

模型三曾提出：

\[
\Phi=(|S|,|M_p|)
\]

作为 \(t=2\) operation 的 strict progress measure。

这有一个重要错误。

若 safe entrant 是 common edge，则翻它后：

\[
|S|\uparrow1.
\]

所以：

- common M-tail filtration：
  \[
  |S|\uparrow1,\quad |M_p|\downarrow;
  \]
- common C-tail entrant后再 correction waiting mismatch：
  \[
  |S|\uparrow1\to |S|,
  \]
  net mismatch count不变。

因此不能说 \((|S|,|M_p|)\) lexicographically strict decrease。

正确解释是：

\[
\boxed{
\text{t=2 lemma消灭 local hard stop，
但 common entrant往往是在搬运 mismatch/slack debt。}
}
\]

这与模型一 blocker debt、模型七 auxiliary debt 的语言高度一致。

## 6.9 模型三当前任务

下一层：

\[
\boxed{
t=3\text{ exact layer}.
}
\]

三种 arithmetic cases：

\[
(q,\varepsilon)
=
(2,1),(3,0),(4,1).
\]

优先做 exact ledger，再研究：

- 是否某 layer 直接 degree/cut impossible；
- 三条 mandatory entrants 是否能同时被 shields service；
- 是否出现“单 entrant 全 blocked，但 two-source operation可行”的 critical phenomenon。


---

# 7. 模型五｜PARALLEL-QUOTIENT：degree transfer、Type-I 与 macro-path serialization

模型五最初研究 quotient dynamics、parallel labels、degree transfer realization，后来逐渐汇聚到：

\[
\boxed{
\text{一个 abstract legal transfer 如何由 physical edge flips serialise？}
}
\]

这已经成为当前最重要的正向路线之一。

## 7.1 quotient legality / path lifting

已经证明：

\[
\boxed{
k\text{-arc-strong legality只依赖 quotient state。}
}
\]

同时，任意 legal quotient path 可以从任意 labelled orientation lift。

因此 quotient connectivity是真实 orientation connectivity 的核心对象；parallel labels 只会影响 path lifting / endpoint realization，而不会改变 legality 本身。

## 7.2 degree transfer graph

定义 legal degree-vector transfer graph

\[
\mathcal R(G,k)
\]

其 vertices 为 legal outdegree vectors，若存在 underlying edge \(uv\) 使

\[
p\mapsto p-e_u+e_v
\]

仍 legal，则连边。

曾主攻 DSPS 型 conjecture：

\[
d_{\mathcal R}(p,p-e_a+e_b)=d_G(a,b).
\]

endpoint shrinking 被证伪，所以允许 shortest path 上任意 multi-interval transfer order。

虽然一般 DSPS 尚未证明，但一次性模型 B 的大量 exact 结果强烈支持 threshold \(2k+1\) 下 degree layer connected；因此项目逐渐判断真正困难更可能出在 physical serialization，而不是 degree algebra。

## 7.3 General Type-I

Type-I 是一个特殊 two-tight-shore geometry：

\[
V=B\sqcup H\sqcup\{a,c\},
\]

其中 \(B,H\) 是 disjoint tight minimum shores，并满足 Two-Shore Balance：

\[
m_{ac}=e(B,H).
\]

研究 exchange：

\[
q=p-e_a+e_b.
\]

早期希望 General Type-I 总 width1。

这个 conjecture 已经 FALSE。

## 7.4 Type-I width1 FALSE，width2 sharp

存在

\[
k=2,\quad n=10,\quad G\text{ 5-regular},\quad\lambda=5
\]

General Type-I instance，满足

\[
\boxed{\omega(p,q)=2.}
\]

其 source HIGH component 与 target LOW component之间没有 physical frontier，因此任何 \(HIGH^*LOW^*\) width1 path 都不可能。

但有 shortest path

\[
8-3-5-0
\]

type：

\[
H-L-H-L.
\]

执行：

\[
8\to3,
\]

\[
5\to0,
\]

\[
3\to5.
\]

interval count：

\[
1\to2\to1.
\]

这形成

\[
\boxed{
\textbf{ALTERNATING TWO-SEED SPLICE}.
}
\]

所以若 universal bound 是 2，则该 bound sharp。

## 7.5 direct length-3 splice 也 FALSE

进一步找到：

\[
k=2,\quad n=12,\quad
5\text{-regular},\quad\lambda=5
\]

General Type-I instance：

\[
\omega=2
\]

但不存在任何 direct

\[
a-L-H-b
\]

三边 splice。

必须走：

\[
\boxed{
10-0-2-9-1
}
\]

并执行

\[
10\to0,
\]

\[
0\to2,
\]

\[
9\to1,
\]

\[
2\to9.
\]

type：

\[
H-L-L-H-L.
\]

这说明真正的 width2 mechanism 必须允许先在同色 corridor / component 内移动 macro endpoint。

## 7.6 Dynamic Macro-Splice

固定 original donor \(a\)。

若当前一个 selected interval 已从 \(a\) 延伸到 \(\ell\)，则 degree state 为

\[
p^\ell=p-e_a+e_\ell.
\]

若 fresh \(h,\ell'\) 满足 physical：

\[
\ell h\in E,\qquad h\ell'\in E,
\]

并且

\[
p^\ell-e_h+e_{\ell'}
\]

legal，同时

\[
p^{\ell'}
=
p-e_a+e_{\ell'}
\]

legal，则可以：

1. 用
   \[
   h\to\ell'
   \]
   打开第二 interval；
2. 用
   \[
   \ell\to h
   \]
   merge。

于是得到 transition：

\[
\boxed{
(a,\ell)\rightsquigarrow(a,\ell').
}
\]

全过程 width \(\le2\)。

## 7.7 Macro-Splice Chain Theorem

若存在：

\[
a=\ell_0
\rightsquigarrow
\ell_1
\rightsquigarrow
\cdots
\rightsquigarrow
\ell_r=b,
\]

且每一步都有上述 legal second seed + merge，则

\[
\boxed{
\omega(p,p-e_a+e_b)\le2.
}
\]

这个结果改变了研究重点：

\[
\boxed{
\text{“两个 intervals 如何反复调度”已经不再是难点。}
}
\]

只要每一步能找到下一条 dynamic seed，两个 intervals 可以无限复用，链再长也不会自动需要第三段。

## 7.8 Dynamic Tightening Lemma

对

\[
p^\ell=p-e_a+e_\ell
\]

和任意 shore \(X\)：

\[
\boxed{
\sigma_{p^\ell}(X)
=
\sigma_p(X)
-\mathbf1_{a\in X}
+\mathbf1_{\ell\in X}.
}
\]

如果一个 candidate continuation 在 current state 被 blocker \(X\) 阻塞，那么相对原始 \(p\)：

- 要么 \(X\) 本来 tight；
- 要么 \(X\) 本来 one-slack，且
  \[
  a\in X,\quad \ell\notin X.
  \]

特别，后者在 current macro state 中已经变成 ordinary tight blocker。

因此：

\[
\boxed{
\text{不需要永久维护一套 static one-slack theory；
每次 macro endpoint移动后，
可以回到 current tight-cut uncrossing。}
}
\]

这和后来的 literature-driven Ito safe-source 思路高度一致。

## 7.9 targeted \(n=12\) search

做了 targeted randomized Type-I search：

- 300,000 constrained skeleton candidates；
- 30,837 个通过 exact：
  \[
  \lambda=5,\quad p\text{ legal},\quad q\text{ legal}
  \]
  filter；
- 其中 74 个 genuine width1 failures；
- 对这 74 个运行 exact global cap-2 state search：
  \[
  74/74
  \]
  都 width \(\le2\)；
- width3 witness：
  \[
  0.
  \]

这是强 computational evidence，但不是 exhaustive Type-I theorem。

## 7.10 global cap2 state representation

模型五构造了一个 exact/near-exact search representation：

width \(\le2\) 的 selected support编码成：

- 一条 directed simple path segment；
- 或两条 vertex-disjoint directed simple path segments。

每条 segment 用

\[
(S,s,t)
\]

记录 used mask 和 endpoints，degree effect 只有

\[
-e_s+e_t.
\]

允许：

1. open segment；
2. prepend；
3. append；
4. merge。

它适合搜索所有 simple \(a-b\) reroutings 下的 two-segment shell。

但必须持续注意定义边界：如果项目中 \(\omega\) 允许 support reuse、branching、off-path temporary moves，则这个状态图只能认证相应 two-segment subclass，不能擅自称整个 reconfiguration 的 full exact characterization。

## 7.11 当前方向升级：critical macro-path serialization

结合 literature 后，模型五已从“Type-I width2 closure”升级为：

\[
\boxed{
\textbf{CRITICAL MACRO-PATH SERIALIZATION AT }2k+1.
}
\]

核心问题：

文献已给许多 macro path reversal 的合法性结果；项目真正缺的是：

\[
\boxed{
\text{如何把一个整体合法的 directed path reversal
serialise 成 legal single-edge flips？}
}
\]

最重要 conjectural replacement：

\[
\boxed{
\text{single safe continuation failure}
\Longrightarrow
\text{legal two-interval macro continuation}.
}
\]

Type-I 继续作为 sharp testbed，但不再是唯一 universe。

---

# 8. 模型六｜ASTRA：global 2-IDPS 与 low-slack quota coupling

模型六长期研究：

\[
\boxed{
\text{legal transfer }p\to p-e_s+e_t
\text{ 是否总能用至多两个 intervals实现？}
}
\]

它与模型五互补：模型五偏 dynamic macro splice，模型六偏 global regular small-\(n\) 与 low-slack quota classification。

## 8.1 endpoint tight families

曾定义：

\[
\mathcal I_s
=
\{\text{inclusion-maximal in-tight shores avoiding }s\},
\]

\[
\mathcal O_t
=
\{\text{inclusion-maximal out-tight shores avoiding }t\}.
\]

并定义

\[
K_s
=
V\setminus\bigcup\mathcal I_s,
\]

\[
L_t
=
V\setminus\bigcup\mathcal O_t.
\]

证明：

\[
K_s=\{v:s\preceq_p v\},
\qquad
L_t=\{v:v\preceq_p t\}.
\]

source-first / target-first 可由 induced directed reachability刻画。

但“总能从两端推进”后来被反例击破。

## 8.2 six-vertex one-interval counterexample family

构造一族：

\[
(2k+1)\text{-regular},
\qquad
|V|=6,
\qquad
\lambda=2k+1,
\]

具有 legal transfer \(s\to t\)，但：

\[
\boxed{
\text{every initial directed simple }s\to t\text{ path
fails one-pass interval realization}.
}
\]

因此 global one-interval theorem FALSE。

但同一 transfer 可以 width2 修复，因此重点转为 2-IDPS。

## 8.3 box-only width2 theorem

在 threshold-regular legality只由 vertex boxes：

\[
k\le p(v)\le k+1
\]

控制时，任意 initial directed simple HIGH→LOW path，无论 HIGH/LOW alternation 多复杂，都有：

\[
\boxed{
\omega_P\le2.
}
\]

width1 当且仅当 color word 是

\[
H^+L^+.
\]

两个 intervals 可以通过不断 open / merge 吸收任意 alternation。

## 8.4 exact two-interval cut formula

若当前 selected edges 是两个 intervals，degree deviation可写：

\[
p_F
=
p-e_{v_i}+e_{v_j}-e_{v_r}+e_{v_\ell}.
\]

记 donors

\[
A=\{v_i,v_r\},
\]

receivers

\[
B=\{v_j,v_\ell\}.
\]

对 cut \(X\)：

\[
\Delta_X
=
|B\cap X|-|A\cap X|.
\]

legality：

- slack 0 cuts：
  \[
  \Delta_X\ge0;
  \]
- slack 1 cuts：
  \[
  \Delta_X\ge-1;
  \]
- slack \(\ge2\)：自动安全。

因此 two-interval obstruction 本质上是：

\[
\boxed{
\text{tight cuts + one-slack double-donor cuts}.
}
\]

## 8.5 six-vertex regular theorem

模型六证明：

\[
\boxed{
G\ (2k+1)\text{-regular},\
\lambda\ge2k+1,\
|V|\le6
\Longrightarrow
\text{every legal transfer has global width}\le2.
}
\]

## 8.6 \(n=8,k=2\) regular reduction

当前：

\[
|V|=8,\quad k=2,\quad
G\text{ 5-regular},\quad\lambda=5.
\]

HIGH 总数为 4。

额外 effective constraints 只有：

### triple

\[
|X|=3,\qquad |\delta(X)|=5,
\]

给

\[
1\le h(X)\le2.
\]

### quad

\[
|X|=4,\qquad |\delta(X)|=6,
\]

给

\[
1\le h(X)\le3.
\]

经过 mincut crossing / parity reduction，剩余：

- **Residual Q**：boxes + one \(4|4\) quota；
- **Residual T**：boxes + one/two disjoint triple quotas。

对 multi-quad rigid four-block ring，\(k=2\) 已 exact enumeration：

\[
388032
\]

ordered legal transfers，其中：

\[
374894
\]

width1，

\[
13138
\]

width2，

\[
0
\]

width\(\ge3\)。

模型六当前任务是关闭 Residual Q / Residual T，从而得到 \(n=8\) regular global 2-IDPS，或找到 first width3 witness。

---

# 9. 模型七｜PHASE-FORK：cycle serialization 与 auxiliary width

模型七研究：

\[
\boxed{
\text{same-outdegree discrepancy cycle
需要多少 off-cycle temporary support 才能 repair？}
}
\]

它建立了当前最重要的新 complexity parameter：**auxiliary width**。

## 9.1 first-move cycle-support wall

固定 legal quotient state \(x\)，目标：

\[
y=x+\chi_C,
\]

其中 \(C\) 是 sign-conformal directed simple discrepancy cycle。

若 \(C\) 的所有 target discrepancy edges 在 \(x\) 都不能作为 first move，项目早期称 \(C\) 为 cycle-support wall。

后来术语需要谨慎：因为即使 target first moves全部 illegal，也可能通过 cycle coordinates 上的非目标 detour取得 \(aw=0\)。所以更准确是“first-move discrepancy wall”。

## 9.2 n=4 wall：one auxiliary 足够

模型七先找到：

\[
k=2,\quad \lambda=5,\quad n=4
\]

first-move wall：

- cycle 三条 target moves全不能 first move；
- whole quotient connected；
- 一枚 off-cycle temporary token 可以打开、完成 cycle、归还。

因此 strict level

\[
\boxed{aw=1}
\]

真实存在。

这击破“cycle support总能 free-order serialize”。

## 9.3 one-auxiliary first-edge criterion

对 auxiliary transfer

\[
a=(r,s)
\]

和 cycle move

\[
c=(u,v),
\]

若先 aux 再 cycle，两步合法需要：

### service all 2-tight blockers

对每个

\[
d^+(S)=2,\quad u\in S,\ v\notin S,
\]

必须

\[
r\notin S,\qquad s\in S.
\]

即 aux 先把：

\[
2\to3.
\]

### no joint 3-cut collision

不能有：

\[
d^+(S)=3
\]

且 aux 与 cycle都 leave \(S\)，否则：

\[
3\to2\to1.
\]

所以 exact criterion 包含：

- auxiliary 自身 legal；
- service所有 2-tight blockers；
- 排除 joint 3-cut collision。

## 9.4 full-cycle subset criterion 与 return lemma

在 borrowed state \(x'\) 中定义 cycle-subset graph：

vertices 是

\[
F\subseteq E(C)
\]

使相应 degree vector legal。

从

\[
\emptyset
\]

到

\[
E(C)
\]

可达，当且仅当只用 cycle discrepancy coordinates 可以完成整个 cycle。

另外：

若 auxiliary coordinate 不属于 \(C\)，并且

\[
x\to x'
\]

legal，之后完整执行 cycle 到 \(y'\)，则 inverse auxiliary

\[
y'\to y
\]

自动 legal。

所以 return 本身不是额外 obstruction。

## 9.5 one auxiliary FALSE，auxiliary width 2

在：

\[
k=2,\quad\lambda=5,\quad n=5
\]

找到 exact witness：

- first-move cycle wall；
- 所有 single legal auxiliary first moves都不足以完成 cycle；
- 甚至所有全过程 outstanding auxiliary load \(\le1\) 的 paths都不可达；
- 但 width2 可达。

定义：

\[
A_C(z)
=
\sum_{f\notin E(C)}
|z_f-x_f|.
\]

定义：

\[
\boxed{
\operatorname{aw}_x(C)
=
\min_{P:x\leadsto y}
\max_{z\in P}A_C(z).
}
\]

这个定义允许：

- cycle / auxiliary moves任意 interleave；
- 借、还、再借；
- arbitrary quotient detour；
- cycle coordinates发生非目标 detour。

witness 满足：

\[
\boxed{
\operatorname{aw}_x(C)=2.
}
\]

explicit path：

\[
02^+,
\quad
13^+,
\quad
24^+,
\quad
14^-,
\quad
12^+,
\quad
13^-,
\quad
02^-.
\]

因此严格 hierarchy：

\[
\boxed{
0<1<2.
}
\]

## 9.6 width2 mechanism：multi-stage blocker service

在这个 witness 中：

- 单独 \(02^+\) 只服务早期 stage；
- 单独 \(13^+\) 甚至没有 legal cycle singleton start；
- 同时持有两枚 debts 后：
  \[
  \emptyset
  \to
  \{B\}
  \to
  \{A,B\}
  \to
  \{A,B,D\}.
  \]

因此：

\[
\boxed{
\textbf{multi-stage blocker service}
}
\]

是真正的 width2 mechanism，而不是“一枚 token绕 cycle传播”。

## 9.7 完整 \(n=5,m\le3\) first-move-wall census

最近模型七完整 exhaustive：

\[
n=5,\qquad
0\le m_{uv}\le3,\qquad
\lambda(G)=5.
\]

总 multiplicity vectors：

\[
4^{10}=1,048,576.
\]

满足 \(\lambda=5\) 的 labelled graphs：

\[
176055.
\]

modulo \(S_5\)：

\[
1710
\]

个 graph isomorphism representatives。

对所有 first-move-wall instances：

总数：

\[
7,974,460.
\]

exact auxiliary-width distribution：

\[
aw=0:\ 168,240,
\]

\[
aw=1:\ 7,802,860,
\]

\[
aw=2:\ 3,360,
\]

\[
aw\ge3:\ 0.
\]

所有 \(aw=2\)：

- 全部是 discrepancy triangles；
- 只来自 4 个 underlying unlabeled graph types；
- 只出现在：
  \[
  |E|=14,15,16.
  \]

而在当前 finite box：

\[
|E|\ge17
\]

后所有 first-move walls甚至满足

\[
aw\le1.
\]

这是目前非常强的 exact finite evidence。

## 9.8 support-wall restriction 的逻辑缺口

必须严格区分：

模型七 exhaustive 的对象要求：

\[
\text{所有 target discrepancy first moves初始都 illegal}.
\]

它没有 exhaustive 所有 feasible discrepancy cycles。

理论上可能存在：

- 初始有某 target move legal；
- 先走它；
- 之后进入更复杂 phase；
- 最终仍需要 \(aw\ge3\)。

所以当前真正 LOCK 的 finite theorem是：

\[
\boxed{
n=5,\ m_{uv}\le3,\ \lambda=5,\ 
C\text{ first-move wall}
\Longrightarrow
aw(C)\le2.
}
\]

不能直接说整个 \(n=5,m\le3\) feasible-cycle universe 都 \(aw\le2\)。

模型七下一轮先补这个逻辑桥：

- 要么证明 minimal \(aw\ge3\) counterexample 可以 WLOG 取 first-move wall；
- 要么 exhaustive 所有 feasible cycles。

只有完成这一点，才进入 \(n=6\)。

---

# 10. 模型四｜BARRIER-GLOBAL：barrier、serial-lock 与 auxiliary-width amplification

模型四最早主攻 global barrier / serial-lock counterexample。

## 10.1 barrier 结果

曾得到：

\[
\boxed{
k=2:\ \text{all-mixed }\beta_Q=0.
}
\]

而更高 \(k\) 可以得到 unbounded barrier。

后来统一 Slack-Token family 给：

\[
\boxed{
k\ge3,\quad t\ge2,\quad
\lambda=2k+1,\quad
d_{\rm amb}=3,\quad
\beta_Q=t.
}
\]

因此：

\[
\boxed{
\text{critical threshold 下 detour barrier 可以无界。}
}
\]

但这些 quotient 仍可能 connected，所以：

\[
\boxed{
\text{high barrier }\neq\text{ disconnectedness}.
}
\]

这是整个项目非常重要的路线修正。

## 10.2 serial-lock family 的 gap

历史上曾尝试 serial-lock unbounded family、all-\(k\) lift、多个 lock modules。

后来发现 old construction 对同一 tail 上多个 modules 的 ordering / prefix barrier theorem 存在 gap，不能当作严谨 theorem。

因此 old serial-lock branch 被冻结，不再作为主要 counterexample route。

## 10.3 Tight-Ball Expansion

得到 singleton-tight ball expansion：

\[
|B_R(C)|
\ge
(|C|+2k)
\left(1+\frac1{2k}\right)^R
-2k.
\]

这排除了某些 small \(O(t)\)-size remote-singleton-slack architectures：如果要在大 radius 保持这种 tightness，底图必须指数膨胀。

但这不能排除 genuinely global / large counterexamples。

## 10.4 当前重启方向：auxiliary-width amplification

在模型七建立

\[
aw=0,1,2
\]

strict hierarchy 后，模型四重新激活，但不再研究 old \(\beta_Q\) serial-lock。

当前目标：

\[
\boxed{
\textbf{AUXILIARY-WIDTH AMPLIFICATION}.
}
\]

核心问题：

\[
\boxed{
aw=2\text{ gadget能否组合成 }aw=3,4,\ldots?
}
\]

简单把多个 independent width2 modules并列通常只给：

\[
\max(2,2)=2,
\]

而不是相加。

因此需要 non-reusable auxiliary demand：

- module 1 的 debt 在 module 2 开始前不能归还；
- module 2 opening 会阻止 module 1 return；
- 多个 debt intervals 必须 overlap。

模型四正在尝试把 \(aw\) 解释成某种：

- interval overlap number；
- pathwidth；
- cutwidth；
- register pressure；
- blocker-service dependency width。

最高价值目标：

构造

\[
(G_t,x_t,C_t)
\]

满足

\[
k=2,\quad\lambda=5,\quad aw(C_t)\ge t.
\]

即使 whole quotient仍 connected，这也会说明 temporary-support complexity 真正可以 unbounded。

---

# 11. 模型二｜COUNTEREXAMPLE：从 local cage 转向 dynamic phase-basin

模型二一直负责 genuine counterexample construction / falsification。

它的主教训是：

\[
\boxed{
\text{静态堵住 visible exits 不等于动态 phase closed。}
}
\]

## 11.1 one-defect Local-Box / reservoir phases

一个重要 architecture 中，minimum-slack layer：

\[
S=1
\]

分成多个 phase components，用 reservoir triple

\[
(y_a,y_b,y_c)
\]

标记。

minimum layer 内可以 disconnected，但 whole quotient仍 connected，因为 temporary extra slack

\[
S=1\to2
\]

会重新连接 phases。

因此：

\[
\boxed{
\text{minimum layer disconnected}
\not\Rightarrow
\text{whole quotient disconnected}.
}
\]

## 11.2 minimum surgery budget

为封住三条 reservoir borrowing directions，定义：

\[
\sigma
=
\text{破坏/替换 old reservoir physical copies数}.
\]

cut-deficit conservation 给：

\[
\boxed{\sigma\ge4.}
\]

equality：

\[
\sigma=4
\]

时 rigid：

\[
\boxed{
(n_a,n_b,n_c)=(1,2,1).
}
\]

blocker old traces 唯一：

\[
X_a=V_{\rm old}-\{u_a\},
\]

\[
X_b=V_{\rm old}-\{u_b\},
\]

\[
X_c=V_{\rm old}-\{u_c\}.
\]

这是 minimum-budget static blocking 的重要刚性。

## 11.3 one-hidden splitter 8-pattern classification

加入一个 hidden interface vertex \(z\)。

定义：

\[
\epsilon
=
(\epsilon_a,\epsilon_b,\epsilon_c)
\in\{0,1\}^3.
\]

zero-outgoing equality rule 给：

\[
zv\text{ 可存在}
\iff
\epsilon,\chi(v)
\text{ coordinatewise comparable}.
\]

完整 8-pattern classification：

只有

\[
\boxed{\epsilon=111}
\]

静态可行。

其余 7 个 pattern 因：

- 无法给 \(u_b,u_c\) 修复 degree；
- 或 \(d^-(z)=0\) 与 3-arc-strong 冲突；

全部死亡。

## 11.4 one-hidden NO-GO：old-edge redistribution–borrow bypass

即使 \(\epsilon=111\) survives，仍存在与 hidden storage 无关的两步 escape：

先翻 old core-leaf：

\[
u_b\to b
\rightsquigarrow
b\to u_b.
\]

这一步只是 internal redistribution，不改变 reservoir phase。

模型二严格证明它必 legal。

然后 flip surviving reservoir edge：

\[
r\to u_b
\rightsquigarrow
u_b\to r.
\]

这一步也必 legal，并把

\[
(y_a,y_b,y_c)
\]

从

\[
(3,0,0)
\]

改成

\[
(3,1,0).
\]

因此 fixed-phase basin 必有 boundary。

正式得到：

\[
\boxed{
\textbf{\(\sigma=4\) ONE-HIDDEN SPLITTER NO-GO}.
}
\]

真正 construction-level reason 是：

\[
\boxed{
\textbf{OLD-EDGE REDISTRIBUTION–BORROW BYPASS}.
}
\]

即便三条 original borrow moves被静态 blocker封住，系统仍可先在 old edge 上搬 slack，再从 reservoir借出。

## 11.5 当前模型二问题

下一步不是立即增加

\[
\sigma=5.
\]

而是先问：

\[
\boxed{
\text{\(\sigma=4\) arbitrary-hidden interface 是否也 no-go？}
}
\]

如果 arbitrary many hidden vertices仍不能救 minimum budget，则说明：

\[
\boxed{
\text{增加 topology 不够，必须真正增加 cut-deficit budget。}
}
\]

如果 FALSE，则最小新 candidate 应是：

\[
|Z|=2
\]

two-hidden splitter。

当前重点：

- hidden membership Boolean-lattice type DAG；
- split degree repair；
- old b-branch bypass是否普遍；
- exit migration theorem；
- phase-basin closure，而不是 singleton-state closure。


---

# 12. 一次性反例搜索 A–E

用户后来明确规定：

\[
\boxed{
\text{数字模型可持续迭代；
字母编号 A–E 只做一次性搜索，不继续发 follow-up prompt。}
}
\]

这些一次性模型的作用是：用 architecture-free 或专门 finite exhaustive search，检验我们是否只是被某种“证明偏见”困住。

## 12.1 A

曾安排 exact quotient enumeration / counterexample scan。

当前项目记录中没有一份已经可靠审计并被吸收的 A 最终报告，因此这里不伪造结论。

状态只记为：

\[
\boxed{
\text{A 已委派，但当前汇总资料中没有可安全引用的最终结果。}
}
\]

## 12.2 B｜DEGREE-GRAPH

目标：寻找 legal degree-vector transfer graph

\[
\mathcal R(G,k)
\]

disconnected 的例子。

如果在 threshold \(2k+1\) 下找到 separated legal degree vectors \(p,q\)，并且都可由 orientations实现，则会是极强 counterexample seed。

### \(k=2\), 5-regular

- n=8 simple 5-regular：全部 complement 2-factor types exact connected；
- random regular n=8..14：connected；
- explicit repeated 5-edge-sum \(K_6\) blocks n=10,14,18：connected。

### irregular degree 5/6/7 multigraph samples

n=4..12 大量 exact/sampled instances，所有 accepted \(\lambda\ge5\) 都 connected。

### complete n=4 multiplicity box

每个 unordered pair multiplicity \(0..5\)：

\[
6^6=46656
\]

个 assignments全部检查。

其中

\[
25673
\]

个满足 \(\lambda\ge5\) 且 legal degree set非空。

结果：

\[
\boxed{
\mathcal R\text{ 全部 connected}.
}
\]

### \(k=3\)

7-regular simple：

- \(K_8\)；
- n=10 complement 2-factor types；
- random n12,n14；
- explicit 7-edge-sum \(K_8\) pair；

全部 connected。

### sharp near-counterexample at threshold \(2k\)

取：

\[
k=2,\qquad G=2K_{2,3}.
\]

有：

\[
\lambda=4=2k.
\]

legal degree set只有：

\[
(2,4,2,2,2),
\]

\[
(3,3,2,2,2),
\]

\[
(4,2,2,2,2),
\]

但：

\[
\boxed{
\mathcal R=3K_1.
}
\]

这是非常干净的 threshold-below counterexample。

然而给底图恰好增加一单位 cut slack 后，反复 reconnect：

- \(2K_{2,3}\)+ 每棵 spanning tree；
- exhaustive 125 labeled trees；
- 更一般地，对所有 6-vertex simple \(\lambda=2\) disconnected-\(\mathcal R\) graphs \(H\)，构造
  \[
  2H+T,\qquad 3H+T
  \]
  的大量 exact lift；

全部在对应 \(2k+1\) threshold 下 connected。

### B 的战略结论

强烈支持：

\[
\boxed{
\lambda(G)\ge2k+1
\Longrightarrow
\mathcal R(G,k)\text{ connected}
}
\]

这一 conjecture，但没有一般证明。

更重要的项目判断：

\[
\boxed{
\text{如果主 QC false，
障碍更可能在 physical serialization，
而不是 abstract degree-vector layer。}
}
\]

---

## 12.3 C｜CLOSED-REGION-SAT

目标：直接找 quotient 中 closed legal subset

\[
\emptyset\neq U\subsetneq Q,
\qquad
\partial_Q(U)=\varnothing.
\]

重点 \(k=2,n=6\)。

### exact graph-class enumeration

限制 multiplicity \(\le3\)、\(\lambda\ge5\)、total edges \(S\le17\)。

degree lower bound给：

\[
S\ge15.
\]

完整 graph isomorphism classes：

- \(S=15\)：12；
- \(S=16\)：212；
- \(S=17\)：1669；

总计：

\[
1893.
\]

对每个 graph：

- complete quotient box；
- exact all 62 shores；
- legal unit moves；
- whole-Q BFS。

结果：

\[
\boxed{
Q\text{ 全部 connected}.
}
\]

因此这里不是“没找到小 \(U\le32\)”而已，而是 exact whole quotient connected。

simple graph side：

- n=6：只有 \(K_6\)，connected；
- n=7：\(K_7\) minus matching \(r=0,1,2,3\)，全部 connected。

### C 的结论

若 \(k=2,n=6,m_{uv}\le3\) counterexample存在，则：

\[
|E|\ge18.
\]

更重要：

\[
\boxed{
\text{tiny closed cage / isolated small basin
越来越不像真正 counterexample 的形状。}
}
\]

---

## 12.4 D｜PURE-CR

目标：找 same-outdegree states \(x,y\) 在 whole quotient 中 disconnected。

这直接针对 cycle-reachability / pure-circulation obstruction。

### exact domains

#### k=2, n=3, multiplicity \(\le4\)

23 qualified graphs；

1,608 box states；

570 legal；

全部 Q/R connected。

#### k=2, n=4, multiplicity \(\le4\)

5,666 qualified graphs；

9,113,043 box states；

4,134,619 legal；

全部 connected。

#### k=2, n=5, multiplicity \(\le3\), complete modulo isomorphism

全部：

\[
4^{10}=1,048,576
\]

multiplicity vectors considered；

330,355 个 \(\lambda\ge5\) labelled graphs；

3,436 iso reps；

99,990,067 box states；

47,550,871 legal states；

max same-\(p\) fiber：

\[
1136.
\]

全部 Q/R connected。

#### k=2, n=6 exact family

\(K_6\) support、至多 8 doubled edge classes：

22,819 labeled patterns；

102 iso classes；

47,438,336 box states；

17,393,632 legal；

max same-\(p\) fiber 1,134；

全部 connected。

#### k=2, n=7 exact family

\(K_7\) minus size-3 matching support，至多 3 doubled edges：

43 automorphism classes；

全部 connected。

#### k=3 fallback

n=4 complete m≤4、n=5 complete modulo iso m≤3，全部 connected。

### 主 exact 总量

k=2 主 search：

- 9,270 graph representatives；
- 190,326,862 quotient-box states；
- 73,192,692 legal states；
- whole quotient component count 始终 1。

### D 的战略结论

\[
\boxed{
\text{small pure circulation + parallel/cycle gadget
没有产生 whole-Q separation。}
}
\]

same-\(p\) fibers可以很大，所以 negative 结果并不是“没有 cycle freedom”。

---

## 12.5 E｜LARGE-UGLY

目标：不要预设 architecture，在较大 n 上 random/evolutionary 搜 genuine counterexample。

搜索规模：

- broad random regular \(k=2\), n=10,12,14,16,18；
- \(k=3\), n=8,10,12,14；
- threshold-focused / irregular；
- 总 graph evaluations：
  \[
  3410;
  \]
- exact-\(\lambda\)-qualified：
  \[
  3109;
  \]
- sampled legal states：
  \[
  25068.
  \]

大 n 通常不是 complete-Q exhaustive，所以不能夸成全局 theorem。

### exact k=2 candidate

n=10，5-regular，\(\lambda=5\)：

- box：
  \[
  5,971,968;
  \]
- legal states：
  \[
  36,286;
  \]
- one component；
- min q-degree 4；
- Q edges：
  \[
  140,610;
  \]
- bridges：
  \[
  0.
  \]

### closest k=3 candidate

n=8，7-regular，\(\lambda=7\)。

whole quotient exact：

- legal states：
  \[
  3488;
  \]
- one component；
- min q-degree：
  \[
  3;
  \]
- Q edges：
  \[
  10098;
  \]
- bridges：
  \[
  0.
  \]

minimum-degree state只有三个 legal exits。

对 exits 做 exact mutation，尝试逐个堵死，结果 exits 会迁移到别的 coordinates，而不是消失。

这形成一个很重要的经验：

\[
\boxed{
\textbf{EXIT MIGRATION}.
}
\]

### E 的战略结论

local narrowness、minimum q-degree、monotone failure 都不是 disconnection certificate。

当前最危险但仍没搜透的形状是：

\[
\boxed{
\text{两个巨大、内部高度 connected 的 phase，
局部没有窄点，
但全局没有 connecting edge。}
}
\]

也就是 macro phase separation，而不是 tiny cage。

---

# 13. 文献搜索带来的路线重构

后来专门查找相关 papers。没有发现一个已经公开解决

\[
\lambda(G)\ge2k+1
\]

single-edge flip connectivity 的现成 theorem。

但文献给出了一个非常重要的统一视角：**macro connectivity 很早就有，真正缺的是 serialization**。

## 13.1 Ito–Iwamasa–Kakimura 等

他们证明：

\[
\lambda(G)\ge2k+2
\]

时 single-edge flip graph connected。

其 proof 使用：

- tight sets；
- dangerous / one-slack sets；
- safe source；
- coverage contradiction。

关键 counting 明确使用底图 cut lower bound

\[
2k+2.
\]

降到

\[
2k+1
\]

时，那一步 strict contradiction 很可能正好变成 equality。

这与项目里反复出现的现象高度吻合：

- tight cut；
- one-slack cut；
- width1失败；
- width2成功。

因此新的高优先级问题是：

\[
\boxed{
\textbf{ITO SAFE-SOURCE PROOF 在 }2k+1\textbf{ 的 equality defect是什么？}
}
\]

一个极有吸引力的候选 replacement：

\[
\boxed{
\text{single safe source fails}
\Longrightarrow
\text{two-source / two-interval move exists}.
}
\]

## 13.2 Frank 1982

Frank 早期结果表明：在 \(2k\)-edge-connected graph 上，\(k\)-strong orientations 可以通过一系列 **directed path / directed circuit reversals** 在 macro level 相互转换，并保持 macro intermediate \(k\)-strong。

这说明：

\[
\boxed{
\text{macro connectivity在更低的 }2k\text{ threshold 已存在。}
}
\]

所以临界 \(2k+1\) 的真正问题可以重写成：

\[
\boxed{
\text{多出来的唯一一单位 cut slack，
是否足够把 macro reversals
serialise 成 single-edge flips？}
}
\]

## 13.3 Blind–Knauer–Valicov

他们研究 \(k\)-arc-connected orientations 的枚举/flip。

关键结构：

pair \((u,v)\) flippable 当且仅当

\[
\lambda_D(u,v)>k.
\]

一旦 pair flippable，任意 directed \(u\to v\) path整体 reverse后仍保持 \(k\)-arc-connected。

这给 target-directed macro degree correction：

若某点 outdegree 比 target多、另一个点比 target少，可以通过合法 macro path reversals逐步修正 degree vector。

当 degree vector与 target一致后，discrepancy 可以分解成 directed cycles，再做 macro cycle reversals。

于是主问题获得一个非常清晰的统一分解：

\[
\boxed{
\textbf{MACRO PATH SERIALIZATION}
+
\textbf{MACRO CYCLE SERIALIZATION}.
}
\]

对应当前模型：

- 模型五、六：path serialization；
- 模型四、七：cycle serialization；
- 模型一：serialization 中 blocker birth/death；
- 模型三：critical tight-cut local geometry。

## 13.4 Frank–Király–Király

在 \(2k+1\)-edge-connected graph 中，对任意 ordered pair \(s,t\)，存在 \(k\)-connected orientation，使 \(s\to t\) 有 \(k+1\) 条 edge-disjoint directed paths。

概念上说明：

\[
\boxed{
2k+1\text{ 不提供 global }(k+1)\text{ buffer，
但可对指定 pair 提供 local +1 buffer。}
}
\]

这非常像项目中反复看到的：

\[
\boxed{
\text{slack 不是全局固定存在，
而是可以移动、借用、归还。}
}
\]

## 13.5 Frank–Murota / discrete convexity

\(k\)-connected orientation 的 degree-vector问题与 integral base polyhedra / M-convex sets 有紧密关系。

这支持：

\[
\boxed{
\text{abstract degree layer 很可能不是主要敌人。}
}
\]

但必须注意：M-convex exchange 不要求 \(u,v\) 在 underlying graph 相邻，因此不能直接把离散凸 exchange theorem 当作 \(\mathcal R(G,k)\) connectivity proof。

## 13.6 submodular flow / recent arc-reversal work

一些较新的工作研究：

- simultaneous arc reversals 与 crossing-submodular constraints；
- hypergraph 版本的 tight/dangerous/safe-source 技术；
- “整体 flip set 可行，但是否总有一条能先翻”的 arc-reversal 问题。

这些 papers 未直接解决主问题，但非常适合提供：

- critical equality analysis；
- safe-source coverage proof 技巧；
- first-move obstruction 的构造模板。

---

# 14. 研究重点的总体变化

最初项目更倾向寻找：

\[
\boxed{
\text{local static deadlock / tiny cage / no-exit shell}.
}
\]

现在大量理论和计算都反复显示：

\[
\boxed{
\text{堵住一种局部 repair 后，
系统往往通过另一种 temporary slack route重新打开。}
}
\]

具体反复出现：

\[
\text{width1 fails}
\to
\text{width2 succeeds};
\]

\[
\text{cycle support fails}
\to
\text{one auxiliary succeeds};
\]

\[
\text{one auxiliary fails}
\to
\text{two auxiliaries succeed};
\]

\[
\text{old borrow blocked}
\to
\text{redistribute then borrow};
\]

\[
\text{ancestor monotonicity fails}
\to
\text{birth then kill};
\]

\[
\text{direct splice fails}
\to
\text{corridor + dynamic splice};
\]

\[
\text{visible exits blocked}
\to
\text{exits migrate}.
\]

因此研究重点已经从：

\[
\boxed{
\text{“有没有一个局部静态死锁？”}
}
\]

转成：

\[
\boxed{
\textbf{temporary slack / debt
是否总能被重新路由、调度并最终归还？}
}
\]

现在最核心的对象是：

\[
\boxed{
\textbf{dynamic serialization complexity}.
}
\]

---

# 15. 已经击破、停止或冻结的 conjectures / 路线

下面是项目中已经明确不能继续当目标的过强命题：

1. high barrier \(\Rightarrow\) disconnected：FALSE。
2. fixed path shelling universal：FALSE。
3. fixed-path 2-IDPS：FALSE。
4. global one-interval / width1：FALSE。
5. source-first or target-first endpoint strategy always succeeds：FALSE。
6. addition-only phase fork 可以 tear slice：FALSE。
7. old \(|T|=3\) full-compensator picture：被 Residual Triple Normal Form取代。
8. generic remote ancestor blocker monotonicity：FALSE。
9. generic signed/co-cover laminar dynamic stability：FALSE。
10. external cycle root universal：FALSE。
11. fixed cyclic-order serialization：FALSE。
12. two-front cycle serialization：FALSE。
13. one-auxiliary cycle repair universal：FALSE。
14. single safe-receiver core connectivity：FALSE。
15. Type-I shifted width1：FALSE。
16. General Type-I original width1：FALSE。
17. direct \(H-L-H-L\) splice universal：FALSE。
18. old serial-lock all-\(k\) unbounded proof：存在 gap，冻结。
19. minimum layer disconnected \(\Rightarrow\) whole quotient disconnected：FALSE。
20. singleton/local exit blocked即可形成 phase cage：FALSE。
21. \((|S|,|M_p|)\) 是 t=2 strict progress measure：bookkeeping 错误，撤销。
22. first-move cycle wall \(\Rightarrow aw>0\)：FALSE。
23. static safe-seed graph \(\mathcal C_p\) 足以描述 arbitrary long chain：FALSE。
24. “support-wall exhaustive”自动等价“all feasible cycles exhaustive”：未证明，当前明确不能这样说。

---

# 16. 当前最可能正确的结构图景

虽然总 theorem 仍 OPEN，但现有证据越来越支持下面的 picture。

## 16.1 degree layer

在

\[
\lambda\ge2k+1
\]

下 legal degree-vector graph 很可能 connected。

threshold \(2k\) 可以完全冻结；增加恰好一单位 slack 后，大量 adversarial lifts 都 reconnect。

## 16.2 path macro

一个合法 transfer

\[
p\to p-e_a+e_b
\]

可能不支持 width1，但很可能总能 width2。

two-interval scheduling algebra已经基本解决；真正困难是：

\[
\boxed{
\text{current tight blockers能否封死所有 dynamic macro continuations？}
}
\]

这可能正对应 Ito \(2k+1\) equality defect。

## 16.3 cycle macro

cycle-support-only 与 one-auxiliary 都可能失败。

目前已知 strict hierarchy：

\[
0<1<2.
\]

但尚未发现：

\[
aw\ge3.
\]

small exact finite evidence强烈支持 \(aw\le2\)，但 general theorem未证明。

## 16.4 blocker dynamics

safe service flip 可以制造 remote harmful birth，但 observed birth可以被 descendant entrant kill。

所以可能存在：

\[
\boxed{
\text{blocker debt conservation / birth-death pairing}.
}
\]

若证明所有 harmful birth 都只是 transient debt，模型一可能提供 dynamic serialization 的关键安全机制。

## 16.5 genuine counterexample 可能长什么样

如果反例存在，它越来越不像：

- tiny cage；
- isolated state；
- one special cut；
- simple cycle wall；
- one-shot phase blocker。

更可能是：

\[
\boxed{
\text{两个或多个宏观高度 connected phases，
局部每一步都健康，
但 global serialization 不能跨 phase。}
}
\]

---

# 17. 当前数字模型分工

## 模型一｜MIXED-FRAME

当前任务：

\[
\boxed{
\text{dynamic blocker birth/death accounting}
}
\]

重点：

- pure-triple immediate pairing；
- finite descendant pairing；
- persistent birth witness；
- birth-stack / LIFO；
- service swap。

## 模型二｜COUNTEREXAMPLE

当前任务：

\[
\boxed{
\text{genuine phase cage / counterexample construction}
}
\]

具体：

\[
\boxed{
\sigma=4\text{ arbitrary-hidden interface no-go?}
}
\]

先判断 minimum surgery budget 是否在 arbitrary topology 下仍逃不出 redistribution–borrow bypass。

## 模型三｜SEPARATED-FLOW

当前任务：

\[
\boxed{
n=7,\ |E|=18\text{ extremal E1 hard-stop elimination}
}
\]

已关闭 entire \(t=2\) layer。

下一层：

\[
\boxed{
t=3\text{ exact ledger / three-entrant service capacity}.
}
\]

## 模型四｜BARRIER-GLOBAL

当前任务：

\[
\boxed{
\text{auxiliary-width amplification}
}
\]

重点：

- service matrix；
- debt interval overlap；
- non-reuse mechanism；
- aw\(\ge3\) / unbounded family；
- 或证明 simple serial composition只取 max width。

## 模型五｜PARALLEL-QUOTIENT

当前任务已升级为：

\[
\boxed{
\text{critical macro-path serialization at }2k+1.
}
\]

重点：

- current-state tight blocker cover；
- Ito safe-source equality defect；
- single-safe-source failure \(\Rightarrow\) two-interval move？
- Type-I 作为 sharp testbed。

## 模型六｜ASTRA

当前任务：

\[
\boxed{
\text{global 2-IDPS / low-slack quota coupling}
}
\]

已关闭：

- box-only；
- n≤6 regular。

正在攻：

\[
k=2,\ n=8,\ 5\text{-regular}
\]

Residual Q / Residual T。

## 模型七｜PHASE-FORK

当前任务：

\[
\boxed{
\text{smallest exact auxiliary-width }\ge3\text{ witness search}
}
\]

已 exhaustive：

\[
n=5,m\le3,\lambda=5
\]

的 first-move walls，全部 \(aw\le2\)。

下一步先补：

- support-wall restriction是否 WLOG；
- 或 exhaustive all feasible cycles。

之后才进入 n=6。

---

# 18. 最值得统一的三个概念

## 18.1 temporary debt

现在多条路线其实都在研究同一种东西：

- 模型一：newborn blocker debt；
- 模型三：common entrant制造 temporary mismatch debt；
- 模型五/六：第二 interval；
- 模型七：off-cycle auxiliary debt；
- 模型二：reservoir slack 借出；
- 模型四：debt interval overlap。

统一问题：

\[
\boxed{
\text{debt 如何产生？能否叠加到无界？是否总能归还？}
}
\]

主 theorem 很可能等价于某种：

\[
\boxed{
\text{temporary debt globally bounded and repayable}.
}
\]

## 18.2 current-state tight geometry

固定初始 \(p\) 的 static blocker family 通常不够。

正确对象是：

\[
p
\to
p^{\ell_1}
\to
p^{\ell_2}
\to\cdots
\]

并在每个 current state重新计算 tight shores。

这在：

- 模型五 Dynamic Tightening；
- 模型一 blocker birth；
- 模型三 filtration；
- Ito safe-source framework；

中完全一致。

## 18.3 critical +1 slack

threshold

\[
2k
\]

可以完全冻结。

threshold

\[
2k+2
\]

已有 connectivity theorem。

我们处在

\[
2k+1.
\]

所以所有困难都围绕：

\[
\boxed{
\text{只有一单位额外 slack，
但这单位 slack可以移动。}
}
\]

它不够让所有 moves独立安全，却似乎经常足够支持：

- two intervals；
- two auxiliary tokens；
- redistribute then borrow；
- one-slack \(\to\) current-tight；
- birth then kill。

这可能是最接近 general theorem 的概念核心。

---

# 19. 当前最高价值 OPEN QUESTIONS

## 19.1 Macro path serialization

\[
\boxed{
\lambda\ge2k+1
\Longrightarrow
\text{every legal macro degree transfer has width}\le2\ ?
}
\]

或者更局部：

\[
\boxed{
\text{single safe continuation failure}
\Rightarrow
\text{two-interval continuation exists}?
}
\]

这是目前最接近正向总证明的方向。

## 19.2 Macro cycle serialization

\[
\boxed{
\lambda\ge2k+1
\Longrightarrow
aw(C)\le2\ ?
}
\]

当前 aw 0/1/2 都真实存在，aw≥3 尚未出现。

## 19.3 Ito critical equality structure

把 \(2k+2\) safe-source proof降到 \(2k+1\)：

- 哪一步 strict inequality 变 equality？
- equality forcing 的 cut geometry是什么？
- 是否必然产生 compatible pair / two-front move？

## 19.4 Persistent blocker birth

\[
\boxed{
\text{harmful birth 是否总有 descendant kill？}
}
\]

YES 会给 blocker debt accounting；NO 会产生很重要的 dynamic obstruction。

## 19.5 Auxiliary-width amplification

\[
\boxed{
aw\text{ 是否无界？}
}
\]

如果无界，说明 temporary-support complexity 可以随 instance 增长。

## 19.6 Genuine global phase separation

如果继续 negative search，目标应转向：

\[
\boxed{
\text{large-component separation}
}
\]

而不是 minimum degree、isolated state、tiny closed set。

---

# 20. Soundness / 后续使用必须持续遵守的约束

1. high \(\beta_Q\) 不代表 disconnected。
2. \(\mathcal R\) connected 不代表 quotient \(Q\) connected。
3. same-\(p\) fiber disconnected 也不够；路径可以离开 fiber 再回来。
4. closed set \(U\) 必须对所有 ambient legal unit moves closed，不能只看 sampled exits。
5. finite multiplicity box exhaustive 不能升级成 arbitrary multiplicity theorem。
6. random search 不能叫 exhaustive。
7. minimum q-degree、no bridge、monotone failure 都只是 diagnostics。
8. common flip 会增加 mismatch count，不能把 temporary common flip当直接 target progress。
9. first-move cycle wall 不等于 \(aw>0\)。
10. support-wall exhaustive 不自动等于 all feasible cycles exhaustive。
11. Type-I n=12 search是 targeted randomized，不是 general theorem。
12. q=4,t=2 closure 只属于当前 E1 extremal setting。
13. blocker birth 可以伤 remote ancestor，所以不能使用 global blocker monotonicity。
14. old serial-lock unbounded construction有 proof gap。
15. M-convex degree exchange不要求 physical adjacency，不能直接推出 \(\mathcal R\) connectivity。
16. literature 中 macro path/cycle reversal 合法，不等于 single-edge serialization已经解决。
17. fixed-path、fixed-order、canonical-front 等过强 realization statements 多次被 falsify；以后优先使用 flexible existence statements。

---

# 21. 简短时间线

## 阶段一：local blocker / no-shell

最初集中在：

- blocker families；
- full compensators；
- no-shell；
- residual mismatch reduction；
- triangle residual；
- \(n=7,|E|=18\) extremal candidate。

这一阶段形成了：

- cut-neutral core；
- Residual Triple Normal Form；
- Core-Entrant Filtration。

## 阶段二：五模型并行

模型一到五分别从：

- mixed blockers；
- counterexample construction；
- separated-flow shields；
- barrier/global；
- parallel quotient；

展开。

随后增加模型六、七：

- 2-IDPS；
- cycle serialization。

## 阶段三：canonical conjectures连续被击破

依次出现：

- Type-I width1 FALSE；
- fixed/direct splice FALSE；
- cycle two-front FALSE；
- one auxiliary FALSE；
- harmful blocker birth真实；
- high barrier 与 disconnectedness 分离。

研究不再追求“唯一漂亮路径”。

## 阶段四：一次性 A–E 大规模搜索

B/C/D/E 全部没有找到 genuine counterexample。

共同结论：

\[
\boxed{
\text{local/static/small counterexample 越来越不像真正 obstruction。}
}
\]

## 阶段五：dynamic debt / macro serialization

最近：

- 模型三关闭 entire \(t=2\)；
- 模型五把 width2 scheduling压成 dynamic macro splice；
- 模型七 exhaustive n=5,m≤3 first-move walls，aw≤2；
- 模型二 one-hidden minimum-budget architecture no-go；
- literature search 将总问题重写为 macro serialization。

---

# 22. 当前整体判断

主问题仍然：

\[
\boxed{
\lambda(G)\ge2k+1
\stackrel{?}{\Longrightarrow}
\text{flip graph connected}
}
\]

仍 OPEN。

到目前没有找到 genuine：

\[
\boxed{
Q(G,k)\text{ disconnected}
}
\]

counterexample。

最强 negative complexity 现象：

\[
\boxed{
\beta_Q\text{ 可无界},
}
\]

以及：

\[
\boxed{
aw=2\text{ 有时必要}.
}
\]

但这两个都仍 compatible with global connectivity。

最强 positive / structural 结果包括：

- residual mismatch normal forms；
- Core-Entrant Filtration；
- Complete \(t=2\) Tight-Q Entrant Lemma；
- box-only width2；
- n≤6 regular width2；
- Dynamic Macro-Splice Chain Theorem；
- Dynamic Tightening Lemma；
- \(\sigma=4\) one-hidden splitter no-go；
- huge exact finite domains中的 degree-graph / quotient / pure-CR connectivity；
- n=5,m≤3 first-move cycle walls全部 aw≤2。

当前最有希望的统一路线是：

\[
\boxed{
\textbf{MACRO MOVES ARE KNOWN;
PROVE CRITICAL \(2k+1\) SERIALIZATION
WITH BOUNDED TEMPORARY DEBT.}
}
\]

可以把七个数字模型看成在解决这个统一命题的不同局部面：

\[
\boxed{
\begin{aligned}
\text{模型五、六} &:\ \text{path serialization},\\
\text{模型四、七} &:\ \text{cycle serialization},\\
\text{模型一} &:\ \text{dynamic blocker debt},\\
\text{模型三} &:\ \text{extremal local hard-stop geometry},\\
\text{模型二} &:\ \text{search for genuine global phase obstruction}.
\end{aligned}
}
\]

目前证据略偏向“临界 \(2k+1\) 仍然 connected”，但尚不足以作结论。

最值得继续追的证明图景不是：

\[
\text{找到一条单调、规范、永不借债的路径},
\]

而是：

\[
\boxed{
\text{允许少量 temporary debt，
证明这些 debt 总能被移动、合并、偿还，
从而把 macro moves serialise。}
}
\]

这就是当前整个项目最清晰的研究核心。


---

# 23. 附录 A：若干关键 explicit witnesses / finite data

这一节保存最值得以后直接拿来复算、SAT/MILP、mutation、对照新 lemma 的具体实例。

## A.1 General Type-I 首个 width2 sharp witness（模型五）

参数：

\[
k=2,\qquad n=10,\qquad
G\text{ 5-regular},\qquad
\lambda=5.
\]

nonzero edge multiplicities：

\[
05:1,\quad06:2,\quad07:2,
\]

\[
14:1,\quad15:1,\quad16:1,\quad17:1,\quad19:1,
\]

\[
23:1,\quad24:1,\quad26:1,\quad27:2,
\]

\[
35:2,\quad38:2,
\]

\[
48:1,\quad49:2,
\]

\[
56:1,\quad89:2.
\]

degree vector：

\[
p=(2,2,2,2,2,3,3,3,3,3).
\]

因此

\[
LOW=\{0,1,2,3,4\},
\]

\[
HIGH=\{5,6,7,8,9\}.
\]

Type-I roles：

\[
B=\{4\},
\]

\[
H=\{0,1,2,3,5,6,7\},
\]

\[
a=8,\qquad c=9,\qquad b=0.
\]

exchange：

\[
q=p-e_8+e_0.
\]

精确：

\[
\boxed{\omega(p,q)=2.}
\]

width1 impossible 的结构原因：

source HIGH component of 8 是

\[
\{8,9\},
\]

target LOW component of 0 是

\[
\{0\},
\]

且没有 80 / 90 edge。

width2 realization：

\[
8-3-5-0,
\]

schedule：

\[
8\to3,\quad
5\to0,\quad
3\to5.
\]

这是 “two safe seeds + merge bridge” 的第一只 sharp witness。

---

## A.2 n=12 Type-I no-direct-splice witness（模型五）

参数：

\[
k=2,\qquad n=12,\qquad
5\text{-regular},\qquad\lambda=5.
\]

非零 multiplicities：

\[
02:1,\quad03:1,\quad0\,10:2,\quad0\,11:1,
\]

\[
14:2,\quad18:2,\quad19:1,
\]

\[
23:1,\quad26:1,\quad29:1,\quad2\,11:1,
\]

\[
36:1,\quad37:1,\quad38:1,
\]

\[
46:1,\quad47:1,\quad48:1,
\]

\[
56:1,\quad57:2,\quad5\,10:1,\quad5\,11:1,
\]

\[
69:1,\quad79:1,\quad89:1,\quad10\,11:2.
\]

degree vector：

\[
p=(2,2,2,2,2,2,3,3,3,3,3,3).
\]

\[
LOW=\{0,1,2,3,4,5\},
\]

\[
HIGH=\{6,7,8,9,10,11\}.
\]

Type-I：

\[
B=\{0\},
\]

\[
H=\{1,2,3,4,5,6,7,8,9\},
\]

\[
a=10,\qquad c=11,\qquad b=1.
\]

两 tight minimum shores 满足：

\[
e(B,H)=2=m_{10,11}.
\]

exchange：

\[
q=p-e_{10}+e_1.
\]

width1 impossible：

\[
A_H=\{10,11\},
\]

\[
B_L=\{1,4\},
\]

\[
E(A_H,B_L)=\varnothing.
\]

此外不存在 direct

\[
10-L-H-1
\]

三边 splice。

但：

\[
10-0-2-9-1
\]

给 width2 schedule：

\[
10\to0,
\quad
0\to2,
\quad
9\to1,
\quad
2\to9.
\]

这个例子说明必须允许 macro endpoint 先沿 corridor 移动。

---

## A.3 模型七首个 exact auxiliary-width 2 witness

vertices：

\[
V=\{0,1,2,3,4\}.
\]

coordinate order：

\[
(01,02,03,04,12,13,14,23,24,34).
\]

multiplicities：

\[
\boxed{
m=(0,2,1,3,1,3,1,2,1,0).
}
\]

即：

\[
m_{01}=0,\quad m_{02}=2,\quad m_{03}=1,\quad m_{04}=3,
\]

\[
m_{12}=1,\quad m_{13}=3,\quad m_{14}=1,
\]

\[
m_{23}=2,\quad m_{24}=1,\quad m_{34}=0.
\]

总边数：

\[
|E|=14.
\]

weighted degrees：

\[
(6,5,6,6,5).
\]

\[
\lambda(G)=5.
\]

state：

\[
\boxed{
x=(0,0,1,1,0,1,1,0,0,0).
}
\]

outdegree vector：

\[
p_x=(2,2,3,4,3).
\]

全部 2-tight shores：

\[
\{0\},
\quad
\{1\},
\quad
\{0,4\},
\quad
\{0,2,4\},
\]

\[
V-\{4\},
\quad
V-\{3\}.
\]

discrepancy triangle：

\[
\boxed{
C:1\to4\to2\to1.
}
\]

三条 target reverse moves：

\[
A=14^-,
\qquad
B=24^+,
\qquad
D=12^+.
\]

它们初始都 illegal。

全部 legal auxiliary first moves只有：

\[
02^+,\quad04^+,\quad13^+,\quad23^+.
\]

但所有 one-auxiliary repair 都失败。

whole quotient：

\[
|Q|=200,
\]

\[
|E(Q)|=472,
\]

\[
\#\pi_0(Q)=1,
\]

\[
\operatorname{diam}(Q)=14.
\]

endpoints：

\[
d_{\rm flip}(x,y)=7.
\]

constrained BFS：

\[
A_C\le0:\ \text{不可达},
\]

\[
A_C\le1:\ \text{不可达},
\]

\[
A_C\le2:\ \text{可达}.
\]

所以：

\[
\boxed{
aw_x(C)=2.
}
\]

explicit optimal path：

\[
02^+,
\quad
13^+,
\quad
24^+,
\quad
14^-,
\quad
12^+,
\quad
13^-,
\quad
02^-.
\]

---

## A.4 \(n=5,m\le3\) 中全部 width2 graph types（模型七）

整个 finite box 中所有 \(aw=2\) first-move-wall instances 只来自 4 个 underlying unlabeled graph types。

coordinate order：

\[
(01,02,03,04,12,13,14,23,24,34).
\]

### Type A — \(|E|=14\)

\[
(0,1,1,3,2,3,1,1,2,0).
\]

labelled orbit size：

\[
60.
\]

每图 12 个 \(aw=2\) directed-wall instances。

总贡献：

\[
720.
\]

### Type B — \(|E|=15\)

\[
(0,0,3,3,3,0,3,1,1,1).
\]

orbit size：

\[
60.
\]

每图 8 个。

总贡献：

\[
480.
\]

### Type C — \(|E|=15\)

\[
(0,1,1,3,2,3,1,1,3,0).
\]

orbit size：

\[
120.
\]

每图 12 个。

总贡献：

\[
1440.
\]

### Type D — \(|E|=16\)

\[
(0,1,1,3,3,3,1,1,0,3).
\]

orbit size：

\[
60.
\]

每图 12 个。

总贡献：

\[
720.
\]

总计：

\[
720+480+1440+720=3360.
\]

全部为 discrepancy triangles。

---

## A.5 模型七 finite-box edge-layer census

在

\[
n=5,\quad m_{uv}\le3,\quad\lambda=5
\]

的 first-move-wall census 中：

\[
\begin{array}{c|r|r|r|r}
|E|&
\#G&
\#\text{legal states}&
\#\text{walls}&
aw=2
\\ \hline
13&510&91\,800&20\,640&0\\
14&6\,075&1\,646\,500&257\,560&720\\
15&19\,750&9\,889\,980&855\,440&1\,920\\
16&34\,940&31\,989\,140&1\,540\,620&720\\
17&40\,780&66\,590\,080&1\,843\,120&0\\
18&34\,640&97\,769\,780&1\,595\,760&0\\
19&22\,560&106\,094\,160&1\,045\,560&0\\
20&11\,200&85\,995\,320&530\,640&0\\
21&4\,200&51\,534\,720&212\,880&0\\
22&1\,200&21\,881\,400&61\,200&0\\
23&200&5\,133\,120&11\,040&0
\end{array}
\]

所以 \(aw=2\) 只出现在 14–16 edges。

---

## A.6 模型三 general \((q,t,\varepsilon)\) extremal ledger

在当前

\[
n=7,\quad |E|=18,\quad \lambda=5
\]

E1 post-filtration setting，设

\[
q=|Q|,
\]

\[
r=|R|=6-q,
\]

并令

\[
\varepsilon
=
\mathbf1_{\{z_\ast\in Q\}},
\]

其中 \(z_\ast\) 是唯一 degree-6 vertex。

已有：

\[
|\delta(Q)|=t+4,
\]

\[
|\delta(R)|=t+3.
\]

degree sums：

\[
\sum_{Q}d(v)=5q+\varepsilon,
\]

\[
\sum_R d(v)=5r+1-\varepsilon.
\]

所以：

\[
e_Q
=
\frac{5q+\varepsilon-4-t}{2},
\]

\[
e_R
=
\frac{5r-2-\varepsilon-t}{2}.
\]

parity：

\[
\boxed{
t\equiv q+\varepsilon\pmod2.
}
\]

outdegree capacity：

\[
t\le q+\varepsilon,
\]

\[
t\le r+2-\varepsilon.
\]

因此 exact coarse survivors：

\[
\begin{array}{c|c|c|c|c|c}
q&t&\varepsilon&|R|&e_Q&e_R\\ \hline
2&2&0&4&2&8\\
2&3&1&4&2&7\\
3&2&1&3&5&5\\
3&3&0&3&4&5\\
3&4&1&3&4&4\\
4&2&0&2&7&3\\
4&3&1&2&7&2\\
4&4&0&2&6&2
\end{array}
\]

其中 \(t=2\) 整层已经删除。

---

## A.7 模型二 minimum-budget one-hidden source data

固定 one-defect source \(x_a\)。

old orientations：

core：

\[
ab:\ 2\,b\to a,
\]

\[
bc:\ 2\,c\to b,
\]

\[
ca:\ 1\,c\to a,\ 1\,a\to c.
\]

core-leaf：

\[
a-u_a:\ 2\,a\to u_a,\ 1\,u_a\to a,
\]

\[
b-u_b:\ 1\,b\to u_b,\ 2\,u_b\to b,
\]

\[
c-u_c:\ 3\,u_c\to c.
\]

defect：

\[
u_b\to u_a.
\]

reservoir：

\[
u_a-r:\ 3\,u_a\to r,\ 1\,r\to u_a,
\]

\[
u_b-r:\ 4\,r\to u_b,
\]

\[
u_c-r:\ 4\,r\to u_c.
\]

minimum surgery：

\[
\sigma=4
\]

必须破坏：

\[
1\times(r\to u_a),
\]

\[
2\times(r\to u_b),
\]

\[
1\times(r\to u_c).
\]

surviving direct reservoir copies：

\[
u_a-r:\ 3\,u_a\to r,
\]

\[
u_b-r:\ 2\,r\to u_b,
\]

\[
u_c-r:\ 3\,r\to u_c.
\]

one-hidden equality splitter 的唯一 static membership 是：

\[
\epsilon=111.
\]

但仍有 forced two-step phase escape：

\[
u_b\to b
\rightsquigarrow
b\to u_b,
\]

然后：

\[
r\to u_b
\rightsquigarrow
u_b\to r.
\]

net reservoir composition：

\[
(3,0,0)\to(3,1,0).
\]

---

## A.8 LARGE-UGLY 最接近 counterexample 的 \(k=3,n=8\) graph

multiplicity matrix：

\[
\begin{pmatrix}
0&0&3&0&1&3&0&0\\
0&0&3&1&0&0&0&3\\
3&3&0&0&0&0&0&1\\
0&1&0&0&2&1&3&0\\
1&0&0&2&0&3&1&0\\
3&0&0&1&3&0&0&0\\
0&0&0&3&1&0&0&3\\
0&3&1&0&0&0&3&0
\end{pmatrix}.
\]

参数：

\[
k=3,\quad n=8,\quad 7\text{-regular},\quad\lambda=7.
\]

quotient box：

\[
1,572,864.
\]

legal states：

\[
3,488.
\]

whole quotient：

\[
\#\pi_0=1.
\]

min q-degree：

\[
3.
\]

Q edges：

\[
10,098.
\]

bridges：

\[
0.
\]

minimum-degree state：

\[
x=[2,0,2,0,0,3,0,0,1,1,0,0,0].
\]

恰好三个 exits：

\[
(1,2),\quad(4,5),\quad(6,7).
\]

对底图做 exit-driven mutation 后 exits迁移而非消失，这成为 exit migration phenomenon 的主要 exact evidence。

---

# 24. 附录 B：项目路线的“错误修正史”

这部分专门记录那些容易在未来重新犯的错误。

## B.1 把 barrier 当成 disconnectedness proxy

错误想法：

\[
\beta_Q\text{ 很大}
\Longrightarrow
Q\text{ 可能 disconnected}.
\]

事实：

\[
\beta_Q
\]

可无界，但 whole quotient仍 connected。

因此高 barrier只能说明 detour复杂，不是反例 certificate。

## B.2 把 abstract legal degree vector 当成 physical realization

错误想法：

\[
p\to p-e_a+e_b\text{ legal}
\]

就意味着 physical edge flips容易实现。

事实：

abstract exchange可以非常干净，但 physical serialization可能需要 two intervals / auxiliary tokens。

因此 degree layer 与 realization layer必须分开。

## B.3 把 first-move failure 当成 support-only failure

模型七发现：

所有 target discrepancy first moves都 illegal，

仍可能有

\[
aw=0
\]

因为可以在 cycle coordinates 中做非目标 detour。

所以“first-move wall”与“support-only impossible”不是同义词。

## B.4 把 common service flip 当成 mismatch progress

common edge翻转后会变成 mismatch：

\[
|S|\uparrow1.
\]

因此 common entrant + waiting mismatch correction常常只是 mismatch token迁移，不是 mismatch count下降。

## B.5 把 source singleton boundary 当 phase basin boundary

模型二早期看到 source state 有 legal neighbor，曾容易过早判 cage失败。

后续修正为：必须区分 internal redistribution 与真正 phase-changing escape。

最终 one-hidden no-go 的 certificate是：

\[
\text{internal redistribution}
\to
\text{provably legal reservoir borrow},
\]

而不是“source有邻居”。

## B.6 固定初始 blocker family研究 long process

模型五指出：macro endpoint移动后，base state已经变成

\[
p^\ell.
\]

原来 \(p\)-one-slack blocker可以在 current state变 tight。

因此 long-chain proof必须更新 current state，而不是永久在初始 \(p\) 上维护 static compatibility graph。

## B.7 过强 canonical path theorem

项目中多次失败：

- fixed path；
- fixed order；
- endpoint-first；
- one interval；
- direct splice；
- one auxiliary。

共同教训：

\[
\boxed{
\text{优先证明 flexible existence，
不要要求唯一 canonical serialization。}
}
\]

---

# 25. 附录 C：未来如果要写正式论文，可能的章节结构

这不是已经证明的论文目录，而是按当前成果最自然的组织方式。

## C.1 Preliminaries

- \(k\)-arc-strong orientations；
- quotient states；
- degree vector cut inequalities；
- tight preorder；
- legal flips。

## C.2 Residual mismatch structure

- cut-neutral Eulerian core；
- residual size 1/2；
- Residual Triple Normal Form。

## C.3 Dynamic blocker geometry

- blocker core \(A,M,C\)；
- Core-Entrant Filtration；
- Birth Criterion；
- Blocker Lifetime；
- harmful birth examples。

## C.4 Extremal \(n=7,|E|=18\) analysis

- degree sequence \((6,5^6)\)；
- side separation；
- \(t=2,q=2,3,4\)；
- Complete \(t=2\) Tight-Q Entrant Lemma；
- surviving \(t=3,4\) ledger。

## C.5 Degree transfers and path serialization

- tight preorder；
- Type-I sharp examples；
- box-only width2；
- Dynamic Macro-Splice；
- Dynamic Tightening；
- regular small-\(n\) 2-IDPS。

## C.6 Cycle serialization

- discrepancy cycles；
- first-move walls；
- one-auxiliary criterion；
- auxiliary width；
- \(aw=1,2\) witnesses；
- finite censuses。

## C.7 Counterexample searches

- degree graph B；
- closed region C；
- pure CR D；
- large ugly E；
- what these searches exclude and what they do not。

## C.8 Critical \(2k+1\) serialization conjecture

最终统一 conjecture：

\[
\boxed{
\text{macro path/cycle moves can be serialised
using bounded temporary debt at }2k+1.
}
\]

这个章节目前仍是 OPEN 核心。
